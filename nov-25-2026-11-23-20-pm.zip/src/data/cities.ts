import { CityPreset, CalculationMethodKey } from '../types';

export const CITY_PRESETS: CityPreset[] = [
  { id: 'makkah', nameAr: 'مكة المكرمة', countryAr: 'السعودية', lat: 21.4225, lng: 39.8262, method: 'UmmAlQura' },
  { id: 'madinah', nameAr: 'المدينة المنورة', countryAr: 'السعودية', lat: 24.4672, lng: 39.6111, method: 'UmmAlQura' },
  { id: 'riyadh', nameAr: 'الرياض', countryAr: 'السعودية', lat: 24.7136, lng: 46.6753, method: 'UmmAlQura' },
  { id: 'jeddah', nameAr: 'جدة', countryAr: 'السعودية', lat: 21.4858, lng: 39.1925, method: 'UmmAlQura' },
  { id: 'cairo', nameAr: 'القاهرة', countryAr: 'مصر', lat: 30.0444, lng: 31.2357, method: 'Egyptian' },
  { id: 'alexandria', nameAr: 'الإسكندرية', countryAr: 'مصر', lat: 31.2001, lng: 29.9187, method: 'Egyptian' },
  { id: 'dubai', nameAr: 'دبي', countryAr: 'الإمارات', lat: 25.2048, lng: 55.2708, method: 'Dubai' },
  { id: 'abudhabi', nameAr: 'أبو ظبي', countryAr: 'الإمارات', lat: 24.4539, lng: 54.3773, method: 'Dubai' },
  { id: 'doha', nameAr: 'الدوحة', countryAr: 'قطر', lat: 25.2854, lng: 51.531, method: 'Qatar' },
  { id: 'kuwait', nameAr: 'مدينة الكويت', countryAr: 'الكويت', lat: 29.3759, lng: 47.9774, method: 'Kuwait' },
  { id: 'amman', nameAr: 'عمّان', countryAr: 'الأردن', lat: 31.9454, lng: 35.9284, method: 'MuslimWorldLeague' },
  { id: 'jerusalem', nameAr: 'القدس', countryAr: 'فلسطين', lat: 31.7683, lng: 35.2137, method: 'Egyptian' },
  { id: 'beirut', nameAr: 'بيروت', countryAr: 'لبنان', lat: 33.8938, lng: 35.5018, method: 'Egyptian' },
  { id: 'baghdad', nameAr: 'بغداد', countryAr: 'العراق', lat: 33.3152, lng: 44.3661, method: 'MuslimWorldLeague' },
  { id: 'rabat', nameAr: 'الرباط', countryAr: 'المغرب', lat: 34.0209, lng: -6.8416, method: 'MuslimWorldLeague' },
  { id: 'tunis', nameAr: 'تونس', countryAr: 'تونس', lat: 36.8065, lng: 10.1815, method: 'MuslimWorldLeague' },
  { id: 'istanbul', nameAr: 'إسطنبول', countryAr: 'تركيا', lat: 41.0082, lng: 28.9784, method: 'MuslimWorldLeague' },
  { id: 'london', nameAr: 'لندن', countryAr: 'المملكة المتحدة', lat: 51.5074, lng: -0.1278, method: 'MuslimWorldLeague' },
  { id: 'newyork', nameAr: 'نيويورك', countryAr: 'الولايات المتحدة', lat: 40.7128, lng: -74.006, method: 'NorthAmerica' },
];

export const CALCULATION_METHODS: { key: CalculationMethodKey; labelAr: string }[] = [
  { key: 'UmmAlQura', labelAr: 'تقويم أم القرى (مكة المكرمة)' },
  { key: 'Egyptian', labelAr: 'الهيئة المصرية العامة للمساحة' },
  { key: 'MuslimWorldLeague', labelAr: 'رابطة العالم الإسلامي' },
  { key: 'Dubai', labelAr: 'دائرة الشؤون الإسلامية بدبي' },
  { key: 'Qatar', labelAr: 'التقويم القطري' },
  { key: 'Kuwait', labelAr: 'وزارة الأوقاف الكويتية' },
  { key: 'Karachi', labelAr: 'جامعة العلوم الإسلامية بكراتشي' },
  { key: 'NorthAmerica', labelAr: 'الجمعية الإسلامية لأمريكا الشمالية (ISNA)' },
];
