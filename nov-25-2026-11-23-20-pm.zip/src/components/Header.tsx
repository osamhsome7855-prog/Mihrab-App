import { Moon, Sun, Clock, BookOpen, Disc, Settings } from 'lucide-react';
import { ActiveTab } from '../types';

interface HeaderProps {
  activeTab: ActiveTab;
  onTabChange: (tab: ActiveTab) => void;
  theme: 'light' | 'dark';
  onToggleTheme: () => void;
}

const NAV_ITEMS: { id: ActiveTab; label: string }[] = [
  { id: 'prayers', label: 'المواقيت' },
  { id: 'adhkar', label: 'الأذكار' },
  { id: 'tasbih', label: 'المسبحة' },
  { id: 'settings', label: 'الإعدادات' },
];

export function Header({ activeTab, onTabChange, theme, onToggleTheme }: HeaderProps) {
  return (
    <>
      <header className="sticky top-0 z-30 border-b border-[#E5DEC9] bg-[#FAF7F2]/90 backdrop-blur-md dark:border-[#1B2C4A] dark:bg-[#081120]/90">
        <div className="mx-auto flex h-14 max-w-6xl items-center justify-between gap-8 px-4 sm:px-6 lg:px-8">
          {/* Zone 1: Single-line Wordmark */}
          <button
            type="button"
            onClick={() => onTabChange('prayers')}
            className="font-display text-2xl font-bold tracking-tight text-[#0B162C] transition-opacity hover:opacity-80 whitespace-nowrap shrink-0 dark:text-[#F3EFE6] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#B88B4A] rounded-md px-1"
          >
            مِحراب
          </button>

          {/* Zone 2: Clean Typography Navigation Links */}
          <nav className="hidden md:flex items-center gap-7" aria-label="التنقل الرئيسي">
            {NAV_ITEMS.map((item) => {
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => onTabChange(item.id)}
                  className={`relative py-2 text-sm font-medium transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#B88B4A] rounded-md px-1.5 ${
                    isActive
                      ? 'text-[#0F5143] dark:text-[#D4AF6A]'
                      : 'text-[#525E70] hover:text-[#0B162C] dark:text-[#98A6BD] dark:hover:text-[#F3EFE6]'
                  }`}
                >
                  {item.label}
                  {isActive && (
                    <span
                      aria-hidden="true"
                      className="absolute inset-x-1 -bottom-[11px] h-[2px] bg-[#0F5143] dark:bg-[#D4AF6A]"
                    />
                  )}
                </button>
              );
            })}
          </nav>

          {/* Zone 3: Single Primary Action */}
          <div className="flex items-center shrink-0">
            <button
              type="button"
              onClick={onToggleTheme}
              aria-label={theme === 'dark' ? 'التبديل إلى الوضع النهاري' : 'التبديل إلى الوضع الليلي'}
              className="inline-flex min-h-[40px] items-center gap-2 rounded-lg border border-[#DED5C1] bg-[#F3EDE2] px-3.5 py-2 text-xs font-medium text-[#0B162C] transition-colors hover:border-[#B88B4A] hover:bg-[#ECE3D3] whitespace-nowrap shrink-0 dark:border-[#23375A] dark:bg-[#0F1C33] dark:text-[#F3EFE6] dark:hover:border-[#D4AF6A] dark:hover:bg-[#152645] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#B88B4A]"
            >
              {theme === 'dark' ? (
                <>
                  <Sun className="h-4 w-4 text-[#D4AF6A]" aria-hidden="true" />
                  <span>الوضع النهاري</span>
                </>
              ) : (
                <>
                  <Moon className="h-4 w-4 text-[#0F5143]" aria-hidden="true" />
                  <span>الوضع الليلي</span>
                </>
              )}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Bottom Tab Bar (Thumb Zone) */}
      <nav
        aria-label="التنقل السريع"
        className="fixed bottom-0 left-0 right-0 z-40 border-t border-[#E5DEC9] bg-[#FAF7F2]/95 backdrop-blur-md md:hidden dark:border-[#1B2C4A] dark:bg-[#081120]/95"
      >
        <div className="grid h-14 grid-cols-4 items-center">
          {NAV_ITEMS.map((item) => {
            const isActive = activeTab === item.id;
            const Icon =
              item.id === 'prayers'
                ? Clock
                : item.id === 'adhkar'
                  ? BookOpen
                  : item.id === 'tasbih'
                    ? Disc
                    : Settings;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => onTabChange(item.id)}
                className={`flex min-h-[44px] flex-col items-center justify-center gap-0.5 text-[11px] font-medium transition-colors whitespace-nowrap shrink-0 ${
                  isActive
                    ? 'text-[#0F5143] dark:text-[#D4AF6A]'
                    : 'text-[#667387] dark:text-[#8A99B3]'
                }`}
              >
                <Icon className="h-5 w-5" strokeWidth={isActive ? 2.2 : 1.75} aria-hidden="true" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>
      </nav>
    </>
  );
}
