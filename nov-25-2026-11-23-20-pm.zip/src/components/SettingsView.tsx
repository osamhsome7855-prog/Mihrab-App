import { useState } from 'react';
import { BellRing, Compass, MapPin, Play, RotateCcw, User, Volume2 } from 'lucide-react';
import { CALCULATION_METHODS, CITY_PRESETS } from '../data/cities';
import { ActiveAlertBanner, AppSettings, CalculationMethodKey, MadhhabKey, PrayerKey, ToneId } from '../types';
import { playTone, TONES } from '../utils/audioEngine';
import { formatTimeArabic, PRAYER_NAMES_AR } from '../utils/prayerService';

interface SettingsViewProps {
  settings: AppSettings;
  onUpdateSettings: (patch: Partial<AppSettings>) => void;
  onTogglePrayerAlert: (key: Exclude<PrayerKey, 'sunrise'>) => void;
  onResetDefaults: () => void;
  onTestAlert: (alert: ActiveAlertBanner) => void;
}

export function SettingsView({
  settings,
  onUpdateSettings,
  onTogglePrayerAlert,
  onResetDefaults,
  onTestAlert,
}: SettingsViewProps) {
  const [gpsStatus, setGpsStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  const [gpsMessage, setGpsMessage] = useState('');
  const [notificationPermission, setNotificationPermission] = useState<string>(() => {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      return Notification.permission;
    }
    return 'unsupported';
  });

  const handleRequestGps = () => {
    if (typeof navigator === 'undefined' || !navigator.geolocation) {
      setGpsStatus('error');
      setGpsMessage('المتصفح لا يدعم تحديد الموقع الجغرافي.');
      return;
    }
    setGpsStatus('loading');
    setGpsMessage('جارٍ تحديد الإحداثيات...');
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        onUpdateSettings({
          locationMode: 'gps',
          customLat: Number(pos.coords.latitude.toFixed(4)),
          customLng: Number(pos.coords.longitude.toFixed(4)),
          customLocationName: `موقعي الحالي (${pos.coords.latitude.toFixed(2)}°، ${pos.coords.longitude.toFixed(2)}°)`,
        });
        setGpsStatus('success');
        setGpsMessage('تم تحديث الإحداثيات بنجاح وحساب المواقيت بدقة.');
      },
      () => {
        setGpsStatus('error');
        setGpsMessage('تعذر الوصول للموقع. يمكنك اختيار أقرب مدينة من القائمة.');
      },
      { enableHighAccuracy: false, timeout: 8000 }
    );
  };

  const handleRequestNotificationPermission = async () => {
    if (typeof window === 'undefined' || !('Notification' in window)) {
      setNotificationPermission('unsupported');
      return;
    }
    try {
      const result = await Notification.requestPermission();
      setNotificationPermission(result);
      if (result === 'granted') {
        onUpdateSettings({ notificationsEnabled: true });
      }
    } catch {
      setNotificationPermission('denied');
    }
  };

  const handleTestNotification = () => {
    playTone(settings.adhanTone, settings.volume);
    onTestAlert({
      id: `test-${Date.now()}`,
      title: 'تجربة تنبيه مِحراب',
      message: 'نغمة التنبيه المخصصة تعمل بنجاح وبجودة صوت نقية.',
      type: 'adhan',
      timestamp: formatTimeArabic(new Date()),
    });
    if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted') {
      try {
        new Notification('تجربة تنبيه مِحراب', {
          body: 'نغمة التنبيه المخصصة تعمل بنجاح.',
          dir: 'rtl',
          lang: 'ar',
        });
      } catch {
        // ignore sandbox error
      }
    }
  };

  const adhanTones = TONES.filter((t) => t.category === 'adhan');
  const adhkarTones = TONES.filter((t) => t.category === 'adhkar');
  const prePrayerTones = TONES.filter((t) => t.category === 'prePrayer' || t.category === 'adhkar');

  return (
    <div className="space-y-8">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl font-bold text-[#0B162C] dark:text-[#F3EFE6]">
            لوحة تحكم المستخدم والإعدادات
          </h1>
          <p className="mt-1 text-sm text-[#525E70] dark:text-[#98A6BD]">
            خصّص الموقع الجغرافي، طريقة الحساب الفلكي، النغمات الصوتية، وجدول التنبيهات.
          </p>
        </div>

        <button
          type="button"
          onClick={handleTestNotification}
          className="inline-flex min-h-[44px] items-center gap-2 rounded-xl bg-[#0F5143] px-5 py-2.5 text-xs font-medium text-[#FAF7F2] transition-colors hover:bg-[#0B3F34] whitespace-nowrap shrink-0 dark:bg-[#D4AF6A] dark:text-[#081120]"
        >
          <BellRing className="h-4 w-4" aria-hidden="true" />
          <span>اختبار التنبيه الآن</span>
        </button>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        {/* 1. Profile & Theme */}
        <section className="space-y-5 rounded-2xl border border-[#E5DEC9] bg-[#F3EDE2]/70 p-6 dark:border-[#1B2C4A] dark:bg-[#0F1C33]/80">
          <div className="flex items-center gap-2.5">
            <User className="h-5 w-5 text-[#9A7034] dark:text-[#D4AF6A]" aria-hidden="true" />
            <h2 className="font-display text-xl font-bold text-[#0B162C] dark:text-[#F3EFE6]">
              الملف الشخصي والمظهر
            </h2>
          </div>

          <div className="space-y-4">
            <div>
              <label
                htmlFor="user-name-input"
                className="mb-1.5 block text-xs font-medium text-[#525E70] dark:text-[#98A6BD]"
              >
                الاسم المعروض في الواجهة
              </label>
              <input
                id="user-name-input"
                type="text"
                maxLength={40}
                value={settings.userName}
                onChange={(e) => onUpdateSettings({ userName: e.target.value })}
                placeholder="مثال: عبد الله"
                className="min-h-[44px] w-full rounded-xl border border-[#DED5C1] bg-[#FAF7F2] px-4 text-sm text-[#0B162C] focus:border-[#0F5143] focus:outline-none dark:border-[#23375A] dark:bg-[#081120] dark:text-[#F3EFE6] dark:focus:border-[#D4AF6A]"
              />
            </div>

            <div className="space-y-2">
              <span className="block text-xs font-medium text-[#525E70] dark:text-[#98A6BD]">
                وضع الألوان
              </span>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => onUpdateSettings({ theme: 'light' })}
                  className={`min-h-[44px] rounded-xl border px-4 py-2.5 text-xs font-medium transition-colors ${
                    settings.theme === 'light'
                      ? 'border-[#0F5143] bg-[#0F5143] text-[#FAF7F2]'
                      : 'border-[#DED5C1] bg-[#FAF7F2] text-[#0B162C] dark:border-[#23375A] dark:bg-[#081120] dark:text-[#F3EFE6]'
                  }`}
                >
                  الوضع النهاري (الرملي الدافئ)
                </button>
                <button
                  type="button"
                  onClick={() => onUpdateSettings({ theme: 'dark' })}
                  className={`min-h-[44px] rounded-xl border px-4 py-2.5 text-xs font-medium transition-colors ${
                    settings.theme === 'dark'
                      ? 'border-[#D4AF6A] bg-[#D4AF6A] text-[#081120]'
                      : 'border-[#DED5C1] bg-[#FAF7F2] text-[#0B162C] dark:border-[#23375A] dark:bg-[#081120] dark:text-[#F3EFE6]'
                  }`}
                >
                  الوضع الليلي (الأزرق العميق)
                </button>
              </div>
            </div>
          </div>
        </section>

        {/* 2. Location & Astronomical Calculation */}
        <section className="space-y-5 rounded-2xl border border-[#E5DEC9] bg-[#F3EDE2]/70 p-6 dark:border-[#1B2C4A] dark:bg-[#0F1C33]/80">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2.5">
              <Compass className="h-5 w-5 text-[#9A7034] dark:text-[#D4AF6A]" aria-hidden="true" />
              <h2 className="font-display text-xl font-bold text-[#0B162C] dark:text-[#F3EFE6]">
                الموقع وحساب المواقيت
              </h2>
            </div>

            <button
              type="button"
              onClick={handleRequestGps}
              className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl border border-[#D4C9B0] bg-[#FAF7F2] px-3 py-1.5 text-xs font-medium text-[#0B162C] transition-colors hover:border-[#B88B4A] dark:border-[#23375A] dark:bg-[#081120] dark:text-[#F3EFE6]"
            >
              <MapPin className="h-3.5 w-3.5 text-[#0F5143] dark:text-[#D4AF6A]" aria-hidden="true" />
              <span>تحديد موقعي تلقائياً</span>
            </button>
          </div>

          {gpsMessage && (
            <p
              className={`text-xs ${
                gpsStatus === 'error'
                  ? 'text-red-700 dark:text-red-400'
                  : 'text-[#0F5143] dark:text-[#D4AF6A]'
              }`}
            >
              {gpsMessage}
            </p>
          )}

          <div className="space-y-4">
            <div>
              <label
                htmlFor="city-select"
                className="mb-1.5 block text-xs font-medium text-[#525E70] dark:text-[#98A6BD]"
              >
                المدينة المختارة
              </label>
              <select
                id="city-select"
                value={settings.locationMode === 'gps' ? 'gps' : settings.selectedCityId}
                onChange={(e) => {
                  const val = e.target.value;
                  if (val === 'gps') return;
                  const city = CITY_PRESETS.find((c) => c.id === val);
                  onUpdateSettings({
                    locationMode: 'preset',
                    selectedCityId: val,
                    calculationMethod: city ? city.method : settings.calculationMethod,
                  });
                }}
                className="min-h-[44px] w-full rounded-xl border border-[#DED5C1] bg-[#FAF7F2] px-3.5 text-sm text-[#0B162C] focus:border-[#0F5143] focus:outline-none dark:border-[#23375A] dark:bg-[#081120] dark:text-[#F3EFE6]"
              >
                {settings.locationMode === 'gps' && (
                  <option value="gps">{settings.customLocationName}</option>
                )}
                {CITY_PRESETS.map((city) => (
                  <option key={city.id} value={city.id}>
                    {city.nameAr} — {city.countryAr}
                  </option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div>
                <label
                  htmlFor="method-select"
                  className="mb-1.5 block text-xs font-medium text-[#525E70] dark:text-[#98A6BD]"
                >
                  طريقة الحساب الفلكي
                </label>
                <select
                  id="method-select"
                  value={settings.calculationMethod}
                  onChange={(e) =>
                    onUpdateSettings({ calculationMethod: e.target.value as CalculationMethodKey })
                  }
                  className="min-h-[44px] w-full rounded-xl border border-[#DED5C1] bg-[#FAF7F2] px-3 text-xs text-[#0B162C] focus:border-[#0F5143] focus:outline-none dark:border-[#23375A] dark:bg-[#081120] dark:text-[#F3EFE6]"
                >
                  {CALCULATION_METHODS.map((m) => (
                    <option key={m.key} value={m.key}>
                      {m.labelAr}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label
                  htmlFor="madhhab-select"
                  className="mb-1.5 block text-xs font-medium text-[#525E70] dark:text-[#98A6BD]"
                >
                  المذهب الفقهي (وقت العصر)
                </label>
                <select
                  id="madhhab-select"
                  value={settings.madhhab}
                  onChange={(e) => onUpdateSettings({ madhhab: e.target.value as MadhhabKey })}
                  className="min-h-[44px] w-full rounded-xl border border-[#DED5C1] bg-[#FAF7F2] px-3 text-xs text-[#0B162C] focus:border-[#0F5143] focus:outline-none dark:border-[#23375A] dark:bg-[#081120] dark:text-[#F3EFE6]"
                >
                  <option value="Shafi">الجمهور (الشافعي والمالكي والحنبلي)</option>
                  <option value="Hanafi">المذهب الحنفي</option>
                </select>
              </div>
            </div>
          </div>
        </section>

        {/* 3. Custom Tones & High-Fidelity Audio */}
        <section className="space-y-5 rounded-2xl border border-[#E5DEC9] bg-[#F3EDE2]/70 p-6 dark:border-[#1B2C4A] dark:bg-[#0F1C33]/80">
          <div className="flex items-center gap-2.5">
            <Volume2 className="h-5 w-5 text-[#9A7034] dark:text-[#D4AF6A]" aria-hidden="true" />
            <h2 className="font-display text-xl font-bold text-[#0B162C] dark:text-[#F3EFE6]">
              تخصيص النغمات الصوتية
            </h2>
          </div>

          <div className="space-y-4">
            <div>
              <div className="mb-1.5 flex items-center justify-between text-xs text-[#525E70] dark:text-[#98A6BD]">
                <span>مستوى الصوت العام</span>
                <span className="tabular-nums font-medium">{Math.round(settings.volume * 100)}%</span>
              </div>
              <input
                type="range"
                min={0}
                max={1}
                step={0.05}
                value={settings.volume}
                onChange={(e) => onUpdateSettings({ volume: Number(e.target.value) })}
                className="w-full accent-[#0F5143] dark:accent-[#D4AF6A]"
              />
            </div>

            {/* Adhan Tone */}
            <div className="space-y-1.5">
              <label className="block text-xs font-medium text-[#525E70] dark:text-[#98A6BD]">
                نغمة الأذان (دخول وقت الصلاة)
              </label>
              <div className="flex items-center gap-2">
                <select
                  value={settings.adhanTone}
                  onChange={(e) => onUpdateSettings({ adhanTone: e.target.value as ToneId })}
                  className="min-h-[44px] flex-1 rounded-xl border border-[#DED5C1] bg-[#FAF7F2] px-3 text-xs text-[#0B162C] dark:border-[#23375A] dark:bg-[#081120] dark:text-[#F3EFE6]"
                >
                  {adhanTones.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.nameAr} ({t.durationLabel})
                    </option>
                  ))}
                </select>
                <button
                  type="button"
                  onClick={() => playTone(settings.adhanTone, settings.volume)}
                  aria-label="معاينة نغمة الأذان"
                  className="inline-flex min-h-[44px] items-center gap-1.5 rounded-xl border border-[#DED5C1] bg-[#FAF7F2] px-3.5 text-xs font-medium text-[#0F5143] hover:border-[#B88B4A] dark:border-[#23375A] dark:bg-[#081120] dark:text-[#D4AF6A]"
                >
                  <Play className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>معاينة</span>
                </button>
              </div>
            </div>

            {/* Adhkar Tone */}
            <div className="space-y-1.5">
              <label className="block text-xs font-medium text-[#525E70] dark:text-[#98A6BD]">
                نغمة تذكير الأذكار (الصباح والمساء)
              </label>
              <div className="flex items-center gap-2">
                <select
                  value={settings.adhkarTone}
                  onChange={(e) => onUpdateSettings({ adhkarTone: e.target.value as ToneId })}
                  className="min-h-[44px] flex-1 rounded-xl border border-[#DED5C1] bg-[#FAF7F2] px-3 text-xs text-[#0B162C] dark:border-[#23375A] dark:bg-[#081120] dark:text-[#F3EFE6]"
                >
                  {adhkarTones.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.nameAr} ({t.durationLabel})
                    </option>
                  ))}
                </select>
                <button
                  type="button"
                  onClick={() => playTone(settings.adhkarTone, settings.volume)}
                  aria-label="معاينة نغمة الأذكار"
                  className="inline-flex min-h-[44px] items-center gap-1.5 rounded-xl border border-[#DED5C1] bg-[#FAF7F2] px-3.5 text-xs font-medium text-[#0F5143] hover:border-[#B88B4A] dark:border-[#23375A] dark:bg-[#081120] dark:text-[#D4AF6A]"
                >
                  <Play className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>معاينة</span>
                </button>
              </div>
            </div>

            {/* Pre-Prayer Tone */}
            <div className="space-y-1.5">
              <label className="block text-xs font-medium text-[#525E70] dark:text-[#98A6BD]">
                نغمة التنبيه قبل الصلاة
              </label>
              <div className="flex items-center gap-2">
                <select
                  value={settings.prePrayerTone}
                  onChange={(e) => onUpdateSettings({ prePrayerTone: e.target.value as ToneId })}
                  className="min-h-[44px] flex-1 rounded-xl border border-[#DED5C1] bg-[#FAF7F2] px-3 text-xs text-[#0B162C] dark:border-[#23375A] dark:bg-[#081120] dark:text-[#F3EFE6]"
                >
                  {prePrayerTones.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.nameAr} ({t.durationLabel})
                    </option>
                  ))}
                </select>
                <button
                  type="button"
                  onClick={() => playTone(settings.prePrayerTone, settings.volume)}
                  aria-label="معاينة نغمة ما قبل الصلاة"
                  className="inline-flex min-h-[44px] items-center gap-1.5 rounded-xl border border-[#DED5C1] bg-[#FAF7F2] px-3.5 text-xs font-medium text-[#0F5143] hover:border-[#B88B4A] dark:border-[#23375A] dark:bg-[#081120] dark:text-[#D4AF6A]"
                >
                  <Play className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>معاينة</span>
                </button>
              </div>
            </div>
          </div>
        </section>

        {/* 4. Notification Preferences */}
        <section className="space-y-5 rounded-2xl border border-[#E5DEC9] bg-[#F3EDE2]/70 p-6 dark:border-[#1B2C4A] dark:bg-[#0F1C33]/80">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2.5">
              <BellRing className="h-5 w-5 text-[#9A7034] dark:text-[#D4AF6A]" aria-hidden="true" />
              <h2 className="font-display text-xl font-bold text-[#0B162C] dark:text-[#F3EFE6]">
                إدارة التنبيهات والأذكار
              </h2>
            </div>

            {notificationPermission !== 'granted' && notificationPermission !== 'unsupported' && (
              <button
                type="button"
                onClick={handleRequestNotificationPermission}
                className="min-h-[38px] rounded-lg border border-[#0F5143] px-3 py-1.5 text-xs font-medium text-[#0F5143] hover:bg-[#0F5143] hover:text-[#FAF7F2] dark:border-[#D4AF6A] dark:text-[#D4AF6A] dark:hover:bg-[#D4AF6A] dark:hover:text-[#081120]"
              >
                السماح بإشعارات المتصفح
              </button>
            )}
          </div>

          <div className="space-y-4">
            <label className="flex cursor-pointer items-center justify-between rounded-xl border border-[#DED5C1] bg-[#FAF7F2] px-4 py-3 dark:border-[#23375A] dark:bg-[#081120]">
              <span className="text-sm font-medium text-[#0B162C] dark:text-[#F3EFE6]">
                تفعيل نظام التنبيهات العام
              </span>
              <input
                type="checkbox"
                checked={settings.notificationsEnabled}
                onChange={(e) => onUpdateSettings({ notificationsEnabled: e.target.checked })}
                className="h-4 w-4 accent-[#0F5143] dark:accent-[#D4AF6A]"
              />
            </label>

            {/* Per-prayer checkboxes */}
            <div className="space-y-2">
              <span className="block text-xs font-medium text-[#525E70] dark:text-[#98A6BD]">
                تنبيهات الصلوات الخمس
              </span>
              <div className="grid grid-cols-2 gap-2 sm:grid-cols-5">
                {(['fajr', 'dhuhr', 'asr', 'maghrib', 'isha'] as const).map((key) => {
                  const enabled = settings.prayerAlerts[key];
                  return (
                    <button
                      key={key}
                      type="button"
                      onClick={() => onTogglePrayerAlert(key)}
                      className={`min-h-[42px] rounded-xl border px-2 py-2 text-xs font-medium transition-colors ${
                        enabled
                          ? 'border-[#0F5143] bg-[#0F5143] text-[#FAF7F2] dark:border-[#D4AF6A] dark:bg-[#D4AF6A] dark:text-[#081120]'
                          : 'border-[#DED5C1] bg-[#FAF7F2] text-[#525E70] dark:border-[#23375A] dark:bg-[#081120] dark:text-[#8A99B3]'
                      }`}
                    >
                      {PRAYER_NAMES_AR[key]}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Pre-prayer offset */}
            <div>
              <label
                htmlFor="pre-prayer-select"
                className="mb-1.5 block text-xs font-medium text-[#525E70] dark:text-[#98A6BD]"
              >
                التنبيه الاستباقي قبل الصلاة
              </label>
              <select
                id="pre-prayer-select"
                value={settings.prePrayerMinutes}
                onChange={(e) =>
                  onUpdateSettings({
                    prePrayerMinutes: Number(e.target.value) as 0 | 10 | 15 | 20,
                  })
                }
                className="min-h-[44px] w-full rounded-xl border border-[#DED5C1] bg-[#FAF7F2] px-3 text-xs text-[#0B162C] dark:border-[#23375A] dark:bg-[#081120] dark:text-[#F3EFE6]"
              >
                <option value={0}>إيقاف التنبيه المسبق</option>
                <option value={10}>قبل الأذان بـ ١٠ دقائق</option>
                <option value={15}>قبل الأذان بـ ١٥ دقيقة</option>
                <option value={20}>قبل الأذان بـ ٢٠ دقيقة</option>
              </select>
            </div>

            {/* Morning & Evening Adhkar Reminder Times */}
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div className="space-y-1.5 rounded-xl border border-[#DED5C1] bg-[#FAF7F2] p-3 dark:border-[#23375A] dark:bg-[#081120]">
                <label className="flex cursor-pointer items-center justify-between text-xs font-medium text-[#0B162C] dark:text-[#F3EFE6]">
                  <span>تذكير أذكار الصباح</span>
                  <input
                    type="checkbox"
                    checked={settings.morningAdhkarEnabled}
                    onChange={(e) =>
                      onUpdateSettings({ morningAdhkarEnabled: e.target.checked })
                    }
                    className="h-4 w-4 accent-[#0F5143] dark:accent-[#D4AF6A]"
                  />
                </label>
                <input
                  type="time"
                  value={settings.morningAdhkarTime}
                  onChange={(e) => onUpdateSettings({ morningAdhkarTime: e.target.value })}
                  disabled={!settings.morningAdhkarEnabled}
                  className="mt-2 min-h-[38px] w-full rounded-lg border border-[#E5DEC9] bg-[#F3EDE2] px-2.5 text-xs tabular-nums text-[#0B162C] disabled:opacity-50 dark:border-[#1B2C4A] dark:bg-[#0F1C33] dark:text-[#F3EFE6]"
                />
              </div>

              <div className="space-y-1.5 rounded-xl border border-[#DED5C1] bg-[#FAF7F2] p-3 dark:border-[#23375A] dark:bg-[#081120]">
                <label className="flex cursor-pointer items-center justify-between text-xs font-medium text-[#0B162C] dark:text-[#F3EFE6]">
                  <span>تذكير أذكار المساء</span>
                  <input
                    type="checkbox"
                    checked={settings.eveningAdhkarEnabled}
                    onChange={(e) =>
                      onUpdateSettings({ eveningAdhkarEnabled: e.target.checked })
                    }
                    className="h-4 w-4 accent-[#0F5143] dark:accent-[#D4AF6A]"
                  />
                </label>
                <input
                  type="time"
                  value={settings.eveningAdhkarTime}
                  onChange={(e) => onUpdateSettings({ eveningAdhkarTime: e.target.value })}
                  disabled={!settings.eveningAdhkarEnabled}
                  className="mt-2 min-h-[38px] w-full rounded-lg border border-[#E5DEC9] bg-[#F3EDE2] px-2.5 text-xs tabular-nums text-[#0B162C] disabled:opacity-50 dark:border-[#1B2C4A] dark:bg-[#0F1C33] dark:text-[#F3EFE6]"
                />
              </div>
            </div>
          </div>
        </section>
      </div>

      {/* Footer Actions */}
      <div className="flex items-center justify-between border-t border-[#E5DEC9] pt-6 dark:border-[#1B2C4A]">
        <p className="text-xs text-[#525E70] dark:text-[#98A6BD]">
          تُحفظ تفضيلاتك تلقائياً في متصفحك لتعمل دون انقطاع.
        </p>
        <button
          type="button"
          onClick={onResetDefaults}
          className="inline-flex min-h-[42px] items-center gap-2 rounded-xl border border-[#DED5C1] px-4 py-2 text-xs font-medium text-[#525E70] transition-colors hover:border-[#B88B4A] hover:text-[#0B162C] dark:border-[#23375A] dark:text-[#98A6BD] dark:hover:text-[#F3EFE6]"
        >
          <RotateCcw className="h-3.5 w-3.5" aria-hidden="true" />
          <span>استعادة الإعدادات الافتراضية</span>
        </button>
      </div>
    </div>
  );
}
