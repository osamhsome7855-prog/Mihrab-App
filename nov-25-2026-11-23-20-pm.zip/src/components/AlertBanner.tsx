import { BellRing, X } from 'lucide-react';
import { ActiveAlertBanner } from '../types';

interface AlertBannerProps {
  alert: ActiveAlertBanner | null;
  onDismiss: () => void;
}

export function AlertBanner({ alert, onDismiss }: AlertBannerProps) {
  if (!alert) return null;

  return (
    <div
      role="status"
      aria-live="polite"
      className="mx-auto mt-4 max-w-6xl px-4 sm:px-6 lg:px-8"
    >
      <div className="flex items-center justify-between gap-4 rounded-xl border border-[#B88B4A]/40 bg-[#F3EDE2] px-4 py-3 text-[#0B162C] dark:border-[#D4AF6A]/40 dark:bg-[#0F1C33] dark:text-[#F3EFE6]">
        <div className="flex items-center gap-3 min-w-0">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-[#0F5143]/10 text-[#0F5143] dark:bg-[#D4AF6A]/15 dark:text-[#D4AF6A]">
            <BellRing className="h-5 w-5" aria-hidden="true" />
          </div>
          <div className="min-w-0">
            <p className="text-sm font-semibold truncate">{alert.title}</p>
            <p className="text-xs text-[#525E70] dark:text-[#98A6BD] truncate">
              {alert.message} · {alert.timestamp}
            </p>
          </div>
        </div>
        <button
          type="button"
          onClick={onDismiss}
          aria-label="إغلاق التنبيه"
          className="flex min-h-[40px] min-w-[40px] shrink-0 items-center justify-center rounded-lg text-[#525E70] transition-colors hover:bg-[#E5DEC9]/60 hover:text-[#0B162C] dark:text-[#98A6BD] dark:hover:bg-[#1B2C4A] dark:hover:text-[#F3EFE6]"
        >
          <X className="h-4 w-4" aria-hidden="true" />
        </button>
      </div>
    </div>
  );
}
