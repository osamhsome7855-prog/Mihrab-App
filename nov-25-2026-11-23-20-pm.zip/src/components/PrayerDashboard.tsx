import { useState } from 'react';
import { Bell, BellOff, Compass, MapPin, Volume2, ArrowLeft } from 'lucide-react';
import { ActiveTab, AppSettings, ComputedPrayerState, PrayerKey } from '../types';
import { playTone } from '../utils/audioEngine';

interface PrayerDashboardProps {
  prayerState: ComputedPrayerState;
  settings: AppSettings;
  onTogglePrayerAlert: (key: Exclude<PrayerKey, 'sunrise'>) => void;
  onNavigate: (tab: ActiveTab) => void;
  adhkarCompletedCount: number;
  adhkarTotalCount: number;
}

export function PrayerDashboard({
  prayerState,
  settings,
  onTogglePrayerAlert,
  onNavigate,
  adhkarCompletedCount,
  adhkarTotalCount,
}: PrayerDashboardProps) {
  const [heroImgFailed, setHeroImgFailed] = useState(false);

  const handlePreviewAdhan = () => {
    playTone(settings.adhanTone, settings.volume);
  };

  return (
    <div className="space-y-8">
      {/* Hero Sanctuary Split */}
      <section className="grid grid-cols-1 items-stretch gap-6 lg:grid-cols-12">
        {/* Primary Focal Anchor: Next Prayer & Countdown */}
        <div className="flex flex-col justify-between rounded-2xl border border-[#E5DEC9] bg-[#F3EDE2] p-6 sm:p-8 lg:col-span-7 dark:border-[#1B2C4A] dark:bg-[#0F1C33]">
          <div className="space-y-5">
            {/* Unboxed metadata row */}
            <div className="flex flex-wrap items-center gap-2 text-xs font-medium text-[#525E70] dark:text-[#98A6BD]">
              <span>مرحباً، {settings.userName || 'ضيف الكريم'}</span>
              <span aria-hidden="true">·</span>
              <span>{prayerState.hijriDate}</span>
              <span aria-hidden="true">·</span>
              <span>{prayerState.gregorianDate}</span>
            </div>

            <div className="space-y-2">
              <p className="text-sm font-medium text-[#0F5143] dark:text-[#D4AF6A]">
                الصلاة القادمة
              </p>
              <div className="flex flex-wrap items-baseline justify-between gap-4">
                <h1 className="font-display text-4xl font-bold tracking-tight text-[#0B162C] sm:text-5xl dark:text-[#F3EFE6]">
                  {prayerState.nextPrayer.nameAr}
                </h1>
                <span className="tabular-nums text-2xl font-semibold text-[#9A7034] sm:text-3xl dark:text-[#D4AF6A]">
                  {prayerState.nextPrayer.formattedTime}
                </span>
              </div>
            </div>

            {/* Live Tabular Countdown */}
            <div className="border-y border-[#E0D7C3] py-5 dark:border-[#1E3152]">
              <p className="mb-2 text-xs font-medium text-[#525E70] dark:text-[#98A6BD]">
                الوقت المتبقي على الأذان
              </p>
              <div
                dir="ltr"
                className="inline-flex items-baseline gap-2 tabular-nums text-4xl font-bold tracking-tight text-[#0B162C] sm:text-5xl dark:text-[#F3EFE6]"
              >
                <span>{prayerState.countdown.hours}</span>
                <span className="text-[#B88B4A] dark:text-[#D4AF6A]">:</span>
                <span>{prayerState.countdown.minutes}</span>
                <span className="text-[#B88B4A] dark:text-[#D4AF6A]">:</span>
                <span className="text-[#0F5143] dark:text-[#D4AF6A]">{prayerState.countdown.seconds}</span>
              </div>
            </div>
          </div>

          <div className="mt-6 flex flex-wrap items-center justify-between gap-4">
            <button
              type="button"
              onClick={() => onNavigate('settings')}
              className="inline-flex min-h-[44px] items-center gap-2 text-sm font-medium text-[#525E70] transition-colors hover:text-[#0B162C] dark:text-[#98A6BD] dark:hover:text-[#F3EFE6]"
            >
              <MapPin className="h-4 w-4 text-[#9A7034] dark:text-[#D4AF6A]" aria-hidden="true" />
              <span>{prayerState.locationLabel}</span>
            </button>

            <div className="flex flex-wrap items-center gap-3">
              <button
                type="button"
                onClick={handlePreviewAdhan}
                className="inline-flex min-h-[44px] items-center gap-2 rounded-xl border border-[#D4C9B0] bg-[#FAF7F2] px-4 py-2 text-sm font-medium text-[#0B162C] transition-colors hover:border-[#B88B4A] whitespace-nowrap shrink-0 dark:border-[#243B61] dark:bg-[#081120] dark:text-[#F3EFE6] dark:hover:border-[#D4AF6A]"
              >
                <Volume2 className="h-4 w-4 text-[#0F5143] dark:text-[#D4AF6A]" aria-hidden="true" />
                <span>سماع نغمة الأذان</span>
              </button>
              <button
                type="button"
                onClick={() => onNavigate('adhkar')}
                className="inline-flex min-h-[44px] items-center gap-2 rounded-xl bg-[#0F5143] px-5 py-2 text-sm font-medium text-[#FAF7F2] transition-colors hover:bg-[#0B3F34] whitespace-nowrap shrink-0 dark:bg-[#D4AF6A] dark:text-[#081120] dark:hover:bg-[#C29B54]"
              >
                <span>أذكار اليوم</span>
                <ArrowLeft className="h-4 w-4" aria-hidden="true" />
              </button>
            </div>
          </div>
        </div>

        {/* Architectural Sanctuary Visual */}
        <div className="relative min-h-[260px] overflow-hidden rounded-2xl border border-[#E5DEC9] lg:col-span-5 dark:border-[#1B2C4A]">
          {!heroImgFailed ? (
            <img
              src="/src/assets/images/hero_mihrab_arch_1795634213119.jpg"
              alt="فناء معماري إسلامي هادئ بأقواس حجرية وقت الغروب"
              referrerPolicy="no-referrer"
              onError={() => setHeroImgFailed(true)}
              className="h-full w-full object-cover lg:h-full"
            />
          ) : (
            <div className="flex h-full w-full flex-col items-center justify-center bg-gradient-to-br from-[#0F5143] via-[#0B162C] to-[#1A2942] p-8 text-center text-[#FAF7F2]">
              <Compass className="mb-3 h-10 w-10 text-[#D4AF6A]" aria-hidden="true" />
              <p className="font-display text-2xl">سَكينة وذِكر</p>
            </div>
          )}
          <div
            aria-hidden="true"
            className="absolute inset-0 bg-gradient-to-t from-[#081120]/85 via-[#081120]/30 to-transparent"
          />
          <div className="absolute inset-x-0 bottom-0 p-6 text-[#FAF7F2]">
            <p className="text-xs font-medium text-[#E5CFA3]">حديث شريف</p>
            <p className="mt-1 font-display text-lg leading-relaxed">
              «أَحَبُّ الأَعْمَالِ إِلَى اللَّهِ الصَّلاَةُ عَلَى وَقْتِهَا»
            </p>
            <p className="mt-1 text-xs text-[#D5DCE6]">متفق عليه</p>
          </div>
        </div>
      </section>

      {/* Full-Width 6-Prayer Daily Schedule Strip */}
      <section aria-labelledby="prayer-schedule-heading" className="space-y-4">
        <div className="flex flex-wrap items-baseline justify-between gap-2">
          <h2
            id="prayer-schedule-heading"
            className="font-display text-2xl font-bold text-[#0B162C] dark:text-[#F3EFE6]"
          >
            مواقيت الصلوات اليوم
          </h2>
          <p className="text-xs text-[#525E70] dark:text-[#98A6BD]">
            انقر على أيقونة الجرس لتفعيل أو إيقاف تنبيه كل صلاة
          </p>
        </div>

        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
          {prayerState.schedule.map((item) => {
            const alertEnabled =
              item.isAlertable &&
              settings.notificationsEnabled &&
              settings.prayerAlerts[item.key as Exclude<PrayerKey, 'sunrise'>];

            return (
              <div
                key={item.key}
                className={`flex flex-col justify-between rounded-2xl border p-4 transition-colors ${
                  item.isNext
                    ? 'border-[#0F5143] bg-[#0F5143] text-[#FAF7F2] dark:border-[#D4AF6A] dark:bg-[#132542] dark:text-[#F3EFE6]'
                    : 'border-[#E5DEC9] bg-[#F3EDE2]/70 text-[#0B162C] dark:border-[#1B2C4A] dark:bg-[#0F1C33]/80 dark:text-[#F3EFE6]'
                }`}
              >
                <div className="flex items-center justify-between gap-2">
                  <span
                    className={`text-sm font-semibold ${
                      item.isNext
                        ? 'text-[#FAF7F2] dark:text-[#D4AF6A]'
                        : 'text-[#0B162C] dark:text-[#F3EFE6]'
                    }`}
                  >
                    {item.nameAr}
                  </span>

                  {item.isAlertable ? (
                    <button
                      type="button"
                      onClick={() => onTogglePrayerAlert(item.key as Exclude<PrayerKey, 'sunrise'>)}
                      aria-label={
                        alertEnabled
                          ? `إيقاف تنبيه صلاة ${item.nameAr}`
                          : `تفعيل تنبيه صلاة ${item.nameAr}`
                      }
                      className={`flex min-h-[40px] min-w-[40px] items-center justify-center rounded-lg transition-colors ${
                        item.isNext
                          ? 'hover:bg-white/10 text-[#E5CFA3]'
                          : alertEnabled
                            ? 'text-[#0F5143] hover:bg-[#E5DEC9]/60 dark:text-[#D4AF6A] dark:hover:bg-[#1B2C4A]'
                            : 'text-[#8B95A5] hover:bg-[#E5DEC9]/60 dark:text-[#5F6F8A] dark:hover:bg-[#1B2C4A]'
                      }`}
                    >
                      {alertEnabled ? (
                        <Bell className="h-4 w-4" aria-hidden="true" />
                      ) : (
                        <BellOff className="h-4 w-4" aria-hidden="true" />
                      )}
                    </button>
                  ) : (
                    <span className="flex min-h-[40px] items-center text-[11px] text-[#6E7A8D] dark:text-[#8A99B3]">
                      شروق
                    </span>
                  )}
                </div>

                <div className="mt-4">
                  <p className="tabular-nums text-xl font-bold tracking-tight">
                    {item.formattedTime}
                  </p>
                  <p
                    className={`mt-1 text-[11px] ${
                      item.isNext
                        ? 'text-[#D6EAE3] dark:text-[#D4AF6A]'
                        : item.isCurrent
                          ? 'text-[#0F5143] dark:text-[#4EA892]'
                          : 'text-[#6E7A8D] dark:text-[#8A99B3]'
                    }`}
                  >
                    {item.isNext ? 'الصلاة القادمة' : item.isCurrent ? 'الوقت الحالي' : '—'}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Secondary Row: Qibla Compass & Daily Spiritual Rhythm */}
      <section className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        {/* Qibla Direction */}
        <div className="flex items-center justify-between gap-6 rounded-2xl border border-[#E5DEC9] bg-[#F3EDE2]/60 p-6 dark:border-[#1B2C4A] dark:bg-[#0F1C33]/70">
          <div className="space-y-2">
            <p className="text-xs font-medium text-[#9A7034] dark:text-[#D4AF6A]">
              اتجاه القبلة المشرفة
            </p>
            <h3 className="font-display text-2xl font-bold text-[#0B162C] dark:text-[#F3EFE6]">
              <span className="tabular-nums">{prayerState.qiblaAngle}°</span> من الشمال الحقيقي
            </h3>
            <p className="max-w-sm text-sm leading-relaxed text-[#525E70] dark:text-[#98A6BD]">
              محسوب بدقة فلكية بناءً على إحداثيات {prayerState.locationLabel}.
            </p>
          </div>

          <div
            aria-label={`بوصلة القبلة تشير إلى ${prayerState.qiblaAngle} درجة`}
            className="relative flex h-28 w-28 shrink-0 items-center justify-center rounded-full border border-[#D4C9B0] bg-[#FAF7F2] dark:border-[#243B61] dark:bg-[#081120]"
          >
            <span className="absolute top-1.5 text-[10px] font-semibold text-[#6E7A8D] dark:text-[#8A99B3]">
              ش
            </span>
            <span className="absolute bottom-1.5 text-[10px] font-semibold text-[#6E7A8D] dark:text-[#8A99B3]">
              ج
            </span>
            <span className="absolute right-2 text-[10px] font-semibold text-[#6E7A8D] dark:text-[#8A99B3]">
              ق
            </span>
            <span className="absolute left-2 text-[10px] font-semibold text-[#6E7A8D] dark:text-[#8A99B3]">
              غ
            </span>
            <svg
              viewBox="0 0 100 100"
              className="h-20 w-20 transition-transform duration-500"
              style={{ transform: `rotate(${prayerState.qiblaAngle}deg)` }}
            >
              <polygon points="50,10 58,50 50,43 42,50" fill="#0F5143" className="dark:fill-[#D4AF6A]" />
              <polygon points="50,90 56,50 50,56 44,50" fill="#C9BFA9" className="dark:fill-[#2B3E60]" />
              <circle cx="50" cy="50" r="5" fill="#B88B4A" />
            </svg>
          </div>
        </div>

        {/* Daily Adhkar & Alerts Overview */}
        <div className="flex flex-col justify-between gap-4 rounded-2xl border border-[#E5DEC9] bg-[#F3EDE2]/60 p-6 dark:border-[#1B2C4A] dark:bg-[#0F1C33]/70">
          <div className="flex items-start justify-between gap-4">
            <div className="space-y-1.5">
              <p className="text-xs font-medium text-[#0F5143] dark:text-[#D4AF6A]">
                ورد الأذكار اليومي
              </p>
              <h3 className="font-display text-2xl font-bold text-[#0B162C] dark:text-[#F3EFE6]">
                أتممت <span className="tabular-nums">{adhkarCompletedCount}</span> من{' '}
                <span className="tabular-nums">{adhkarTotalCount}</span> ذكر اليوم
              </h3>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('tasbih')}
              className="min-h-[44px] rounded-xl border border-[#D4C9B0] bg-[#FAF7F2] px-4 py-2 text-xs font-medium text-[#0B162C] transition-colors hover:border-[#B88B4A] whitespace-nowrap shrink-0 dark:border-[#243B61] dark:bg-[#081120] dark:text-[#F3EFE6]"
            >
              فتح المسبحة
            </button>
          </div>

          <div className="space-y-2">
            <div className="h-2 w-full overflow-hidden rounded-full bg-[#E5DEC9] dark:bg-[#1B2C4A]">
              <div
                className="h-full rounded-full bg-[#0F5143] transition-all duration-300 dark:bg-[#D4AF6A]"
                style={{
                  width: `${adhkarTotalCount > 0 ? Math.min(100, Math.round((adhkarCompletedCount / adhkarTotalCount) * 100)) : 0}%`,
                }}
              />
            </div>
            <div className="flex items-center justify-between text-xs text-[#525E70] dark:text-[#98A6BD]">
              <span>
                أذكار الصباح: {settings.morningAdhkarEnabled ? settings.morningAdhkarTime : 'متوقف'} · أذكار المساء:{' '}
                {settings.eveningAdhkarEnabled ? settings.eveningAdhkarTime : 'متوقف'}
              </span>
              <button
                type="button"
                onClick={() => onNavigate('adhkar')}
                className="font-medium text-[#0F5143] hover:underline dark:text-[#D4AF6A]"
              >
                متابعة القراءة
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
