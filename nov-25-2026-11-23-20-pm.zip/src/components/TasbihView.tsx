import { RotateCcw, Volume2, VolumeX } from 'lucide-react';
import { AppSettings } from '../types';
import { playTasbihClick } from '../utils/audioEngine';
import { TasbihStoredState } from '../utils/storage';

interface TasbihViewProps {
  tasbih: TasbihStoredState;
  settings: AppSettings;
  onUpdateTasbih: (updater: (prev: TasbihStoredState) => TasbihStoredState) => void;
  onToggleVolumeMute: () => void;
}

const PRESET_PHRASES = [
  'سُبْحَانَ اللَّهِ',
  'الْحَمْدُ لِلَّهِ',
  'اللَّهُ أَكْبَرُ',
  'لَا إِلَهَ إِلَّا اللَّهُ',
  'أَسْتَغْفِرُ اللَّهَ الْعَظِيمَ',
  'اللَّهُمَّ صَلِّ وَسَلِّمْ عَلَى نَبِيِّنَا مُحَمَّدٍ',
];

const TARGET_OPTIONS = [
  { value: 33, label: '٣٣' },
  { value: 99, label: '٩٩' },
  { value: 100, label: '١٠٠' },
  { value: 0, label: 'مفتوح' },
];

export function TasbihView({
  tasbih,
  settings,
  onUpdateTasbih,
  onToggleVolumeMute,
}: TasbihViewProps) {
  const activePhrase =
    tasbih.phraseIndex === -1 && tasbih.customPhrase.trim()
      ? tasbih.customPhrase
      : PRESET_PHRASES[tasbih.phraseIndex] || PRESET_PHRASES[0];

  const hasTarget = tasbih.target > 0;
  const progressRatio = hasTarget ? Math.min(1, tasbih.count / tasbih.target) : 0;
  const radius = 104;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference * (1 - progressRatio);

  const handleTap = () => {
    const nextCount = hasTarget && tasbih.count >= tasbih.target ? 1 : tasbih.count + 1;
    const reachedTarget = hasTarget && nextCount === tasbih.target;

    if (settings.volume > 0) {
      playTasbihClick(reachedTarget, settings.volume);
    }
    if (settings.hapticEnabled && typeof navigator !== 'undefined' && navigator.vibrate) {
      navigator.vibrate(reachedTarget ? [25, 45, 25] : 10);
    }

    onUpdateTasbih((prev) => ({
      ...prev,
      count: nextCount,
      lifetimeTotal: prev.lifetimeTotal + 1,
    }));
  };

  const handleReset = () => {
    onUpdateTasbih((prev) => ({
      ...prev,
      count: 0,
    }));
  };

  return (
    <div className="mx-auto max-w-4xl space-y-8">
      {/* Header & Phrase Selector */}
      <div className="rounded-2xl border border-[#E5DEC9] bg-[#F3EDE2]/70 p-6 dark:border-[#1B2C4A] dark:bg-[#0F1C33]/80">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="font-display text-3xl font-bold text-[#0B162C] dark:text-[#F3EFE6]">
              المسبحة الإلكترونية
            </h1>
            <p className="mt-1 text-xs text-[#525E70] dark:text-[#98A6BD]">
              اختر الذكر والهدف العددي ثم انقر على الدائرة المركزية للتسبيح
            </p>
          </div>

          <div className="text-left">
            <p className="text-xs text-[#525E70] dark:text-[#98A6BD]">إجمالي التسبيحات</p>
            <p className="tabular-nums text-xl font-bold text-[#0F5143] dark:text-[#D4AF6A]">
              {tasbih.lifetimeTotal.toLocaleString('ar-EG')}
            </p>
          </div>
        </div>

        {/* Phrase Buttons */}
        <div className="mt-5 flex flex-wrap gap-2">
          {PRESET_PHRASES.map((phrase, index) => {
            const isSelected = tasbih.phraseIndex === index;
            return (
              <button
                key={phrase}
                type="button"
                onClick={() =>
                  onUpdateTasbih((prev) => ({
                    ...prev,
                    phraseIndex: index,
                    count: 0,
                  }))
                }
                className={`min-h-[40px] rounded-xl border px-3.5 py-2 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                  isSelected
                    ? 'border-[#0F5143] bg-[#0F5143] text-[#FAF7F2] dark:border-[#D4AF6A] dark:bg-[#D4AF6A] dark:text-[#081120]'
                    : 'border-[#DED5C1] bg-[#FAF7F2] text-[#0B162C] hover:border-[#B88B4A] dark:border-[#23375A] dark:bg-[#081120] dark:text-[#F3EFE6]'
                }`}
              >
                {phrase}
              </button>
            );
          })}
        </div>

        {/* Custom Phrase & Target Controls */}
        <div className="mt-4 flex flex-wrap items-center justify-between gap-4 border-t border-[#E5DEC9] pt-4 dark:border-[#1B2C4A]">
          <div className="flex-1 min-w-[210px]">
            <input
              type="text"
              value={tasbih.customPhrase}
              onChange={(e) =>
                onUpdateTasbih((prev) => ({
                  ...prev,
                  customPhrase: e.target.value,
                  phraseIndex: e.target.value.trim() ? -1 : 0,
                }))
              }
              placeholder="أو اكتب ذكراً مخصصاً هنا..."
              className="min-h-[42px] w-full rounded-xl border border-[#DED5C1] bg-[#FAF7F2] px-3.5 text-xs text-[#0B162C] placeholder:text-[#7D8899] focus:border-[#0F5143] focus:outline-none dark:border-[#23375A] dark:bg-[#081120] dark:text-[#F3EFE6]"
            />
          </div>

          <div className="flex items-center gap-1.5 rounded-xl border border-[#DED5C1] bg-[#FAF7F2] p-1 dark:border-[#23375A] dark:bg-[#081120]">
            {TARGET_OPTIONS.map((opt) => {
              const isSelected = tasbih.target === opt.value;
              return (
                <button
                  key={opt.value}
                  type="button"
                  onClick={() =>
                    onUpdateTasbih((prev) => ({
                      ...prev,
                      target: opt.value,
                      count: 0,
                    }))
                  }
                  className={`min-h-[36px] rounded-lg px-3 py-1 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                    isSelected
                      ? 'bg-[#0F5143] text-[#FAF7F2] dark:bg-[#D4AF6A] dark:text-[#081120]'
                      : 'text-[#525E70] hover:text-[#0B162C] dark:text-[#98A6BD]'
                  }`}
                >
                  {opt.label}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Central Meditative Tap Ring */}
      <div className="flex flex-col items-center justify-center rounded-2xl border border-[#E5DEC9] bg-[#F3EDE2]/50 px-6 py-10 dark:border-[#1B2C4A] dark:bg-[#0F1C33]/60">
        <p className="mb-8 text-center font-display text-3xl font-bold text-[#0B162C] sm:text-4xl dark:text-[#F3EFE6]">
          {activePhrase}
        </p>

        <button
          type="button"
          onClick={handleTap}
          aria-label={`تسبيح: ${activePhrase}، العداد الحالي ${tasbih.count}`}
          className="group relative flex h-60 w-60 items-center justify-center rounded-full transition-transform duration-150 active:scale-[0.97] focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-[#B88B4A]/40"
        >
          <svg className="h-full w-full -rotate-90" viewBox="0 0 240 240">
            <circle
              cx="120"
              cy="120"
              r={radius}
              fill="none"
              stroke="currentColor"
              strokeWidth="8"
              className="text-[#E0D7C3] dark:text-[#1B2C4A]"
            />
            {hasTarget && (
              <circle
                cx="120"
                cy="120"
                r={radius}
                fill="none"
                stroke="currentColor"
                strokeWidth="8"
                strokeLinecap="round"
                strokeDasharray={circumference}
                strokeDashoffset={strokeDashoffset}
                className="text-[#0F5143] transition-[stroke-dashoffset] duration-150 dark:text-[#D4AF6A]"
              />
            )}
          </svg>

          <div className="absolute inset-5 flex flex-col items-center justify-center rounded-full border border-[#E5DEC9] bg-[#FAF7F2] dark:border-[#23375A] dark:bg-[#081120]">
            <span className="tabular-nums text-5xl font-bold tracking-tight text-[#0B162C] dark:text-[#F3EFE6]">
              {tasbih.count}
            </span>
            <span className="mt-2 text-xs font-medium text-[#525E70] dark:text-[#98A6BD]">
              {hasTarget ? `من ${tasbih.target}` : 'عدّ مفتوح'}
            </span>
          </div>
        </button>

        {/* Bottom Controls */}
        <div className="mt-8 flex items-center gap-4">
          <button
            type="button"
            onClick={handleReset}
            className="inline-flex min-h-[44px] items-center gap-2 rounded-xl border border-[#DED5C1] bg-[#FAF7F2] px-4 py-2 text-xs font-medium text-[#0B162C] transition-colors hover:border-[#B88B4A] dark:border-[#23375A] dark:bg-[#081120] dark:text-[#F3EFE6]"
          >
            <RotateCcw className="h-4 w-4 text-[#9A7034] dark:text-[#D4AF6A]" aria-hidden="true" />
            <span>تصفير العداد</span>
          </button>

          <button
            type="button"
            onClick={onToggleVolumeMute}
            className="inline-flex min-h-[44px] items-center gap-2 rounded-xl border border-[#DED5C1] bg-[#FAF7F2] px-4 py-2 text-xs font-medium text-[#0B162C] transition-colors hover:border-[#B88B4A] dark:border-[#23375A] dark:bg-[#081120] dark:text-[#F3EFE6]"
          >
            {settings.volume > 0 ? (
              <>
                <Volume2 className="h-4 w-4 text-[#0F5143] dark:text-[#D4AF6A]" aria-hidden="true" />
                <span>الصوت مفعّل</span>
              </>
            ) : (
              <>
                <VolumeX className="h-4 w-4 text-[#7D8899]" aria-hidden="true" />
                <span>الصوت مكتوم</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
