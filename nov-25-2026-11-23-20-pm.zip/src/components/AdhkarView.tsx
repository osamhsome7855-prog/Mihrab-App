import { useMemo, useState } from 'react';
import { Check, Plus, RotateCcw, Search, Trash2, Volume2 } from 'lucide-react';
import { ADHKAR_COLLECTION } from '../data/adhkar';
import { AppSettings, DhikrCategory, DhikrItem } from '../types';
import { playTasbihClick, playTone } from '../utils/audioEngine';

interface AdhkarViewProps {
  settings: AppSettings;
  counts: Record<string, number>;
  onIncrementDhikr: (id: string, targetCount: number) => void;
  onResetCategory: (ids: string[]) => void;
  customAdhkar: DhikrItem[];
  onAddCustomDhikr: (text: string, targetCount: number, virtue: string) => void;
  onDeleteCustomDhikr: (id: string) => void;
  onToggleAutoAdvance: () => void;
}

const CATEGORY_TABS: { id: DhikrCategory; label: string; subtitle: string }[] = [
  { id: 'morning', label: 'أذكار الصباح', subtitle: 'تُقال من بعد صلاة الفجر حتى طلوع الشمس أو الضحى' },
  { id: 'evening', label: 'أذكار المساء', subtitle: 'تُقال من بعد صلاة العصر حتى غروب الشمس وأول الليل' },
  { id: 'afterPrayer', label: 'بعد الصلاة', subtitle: 'الأذكار المشروعة دُبُر كل صلاة مكتوبة' },
  { id: 'sleep', label: 'أذكار النوم', subtitle: 'التحصين والسكينة عند الإيواء إلى الفراش' },
  { id: 'custom', label: 'أذكاري الخاصة', subtitle: 'أذكار وأدعية أضفتها لمتابعتها يومياً' },
];

export function AdhkarView({
  settings,
  counts,
  onIncrementDhikr,
  onResetCategory,
  customAdhkar,
  onAddCustomDhikr,
  onDeleteCustomDhikr,
  onToggleAutoAdvance,
}: AdhkarViewProps) {
  const [activeCategory, setActiveCategory] = useState<DhikrCategory>('morning');
  const [searchQuery, setSearchQuery] = useState('');
  const [bannerImgFailed, setBannerImgFailed] = useState(false);

  const [showAddForm, setShowAddForm] = useState(false);
  const [newText, setNewText] = useState('');
  const [newTarget, setNewTarget] = useState(3);
  const [newVirtue, setNewVirtue] = useState('');

  const allItems = useMemo(() => [...ADHKAR_COLLECTION, ...customAdhkar], [customAdhkar]);

  const categoryItems = useMemo(() => {
    const base = allItems.filter((item) => item.category === activeCategory);
    if (!searchQuery.trim()) return base;
    const q = searchQuery.trim();
    return base.filter(
      (item) =>
        item.text.includes(q) ||
        item.reference.includes(q) ||
        (item.virtue && item.virtue.includes(q))
    );
  }, [allItems, activeCategory, searchQuery]);

  const completedInCategory = useMemo(
    () => categoryItems.filter((item) => (counts[item.id] || 0) >= item.targetCount).length,
    [categoryItems, counts]
  );

  const activeTabMeta = CATEGORY_TABS.find((t) => t.id === activeCategory) || CATEGORY_TABS[0];
  const isEveningOrSleep = activeCategory === 'evening' || activeCategory === 'sleep';
  const bannerSrc = isEveningOrSleep
    ? '/src/assets/images/adhkar_evening_lantern_1795634214035.jpg'
    : '/src/assets/images/adhkar_morning_light_1795634214298.jpg';

  const handleTapDhikr = (item: DhikrItem) => {
    const current = counts[item.id] || 0;
    if (current >= item.targetCount) return;

    const nextVal = current + 1;
    const reachedTarget = nextVal === item.targetCount;
    playTasbihClick(reachedTarget, settings.volume);

    if (settings.hapticEnabled && typeof navigator !== 'undefined' && navigator.vibrate) {
      navigator.vibrate(reachedTarget ? [20, 40, 20] : 12);
    }

    onIncrementDhikr(item.id, item.targetCount);

    if (reachedTarget && settings.autoAdvanceDhikr) {
      const idx = categoryItems.findIndex((x) => x.id === item.id);
      const nextItem = categoryItems.slice(idx + 1).find((x) => (counts[x.id] || 0) < x.targetCount);
      if (nextItem) {
        window.setTimeout(() => {
          const el = document.getElementById(`dhikr-card-${nextItem.id}`);
          el?.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }, 180);
      }
    }
  };

  const handleCreateCustom = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newText.trim()) return;
    onAddCustomDhikr(newText.trim(), Math.max(1, Math.min(999, newTarget)), newVirtue.trim());
    setNewText('');
    setNewTarget(3);
    setNewVirtue('');
    setShowAddForm(false);
    setActiveCategory('custom');
  };

  return (
    <div className="space-y-6">
      {/* Category Segmented Tabs */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div
          role="tablist"
          aria-label="أقسام الأذكار"
          className="flex flex-wrap items-center gap-1.5 rounded-xl border border-[#E5DEC9] bg-[#F3EDE2] p-1 dark:border-[#1B2C4A] dark:bg-[#0F1C33]"
        >
          {CATEGORY_TABS.map((tab) => {
            const isActive = activeCategory === tab.id;
            return (
              <button
                key={tab.id}
                role="tab"
                aria-selected={isActive}
                type="button"
                onClick={() => {
                  setActiveCategory(tab.id);
                  setBannerImgFailed(false);
                }}
                className={`min-h-[40px] rounded-lg px-3.5 py-2 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                  isActive
                    ? 'bg-[#0F5143] text-[#FAF7F2] dark:bg-[#D4AF6A] dark:text-[#081120]'
                    : 'text-[#525E70] hover:text-[#0B162C] dark:text-[#98A6BD] dark:hover:text-[#F3EFE6]'
                }`}
              >
                {tab.label}
              </button>
            );
          })}
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => playTone(settings.adhkarTone, settings.volume)}
            className="inline-flex min-h-[42px] items-center gap-2 rounded-xl border border-[#DED5C1] bg-[#F3EDE2] px-3.5 py-2 text-xs font-medium text-[#0B162C] transition-colors hover:border-[#B88B4A] whitespace-nowrap shrink-0 dark:border-[#1B2C4A] dark:bg-[#0F1C33] dark:text-[#F3EFE6]"
          >
            <Volume2 className="h-4 w-4 text-[#0F5143] dark:text-[#D4AF6A]" aria-hidden="true" />
            <span>نغمة الأذكار</span>
          </button>

          <button
            type="button"
            onClick={() => setShowAddForm((v) => !v)}
            className="inline-flex min-h-[42px] items-center gap-2 rounded-xl bg-[#0F5143] px-4 py-2 text-xs font-medium text-[#FAF7F2] transition-colors hover:bg-[#0B3F34] whitespace-nowrap shrink-0 dark:bg-[#D4AF6A] dark:text-[#081120]"
          >
            <Plus className="h-4 w-4" aria-hidden="true" />
            <span>إضافة ذكر خاص</span>
          </button>
        </div>
      </div>

      {/* Category Editorial Banner */}
      <div className="relative overflow-hidden rounded-2xl border border-[#E5DEC9] dark:border-[#1B2C4A]">
        <div className="h-44 w-full sm:h-52">
          {!bannerImgFailed ? (
            <img
              src={bannerSrc}
              alt={activeTabMeta.label}
              referrerPolicy="no-referrer"
              onError={() => setBannerImgFailed(true)}
              className="h-full w-full object-cover"
            />
          ) : (
            <div className="h-full w-full bg-gradient-to-br from-[#0B162C] via-[#0F5143] to-[#1D3557]" />
          )}
          <div
            aria-hidden="true"
            className="absolute inset-0 bg-gradient-to-t from-[#081120]/90 via-[#081120]/45 to-transparent"
          />
        </div>

        <div className="absolute inset-x-0 bottom-0 flex flex-wrap items-end justify-between gap-4 p-6 text-[#FAF7F2]">
          <div className="space-y-1">
            <h1 className="font-display text-3xl font-bold">{activeTabMeta.label}</h1>
            <p className="text-xs text-[#DCE2EC] sm:text-sm">{activeTabMeta.subtitle}</p>
          </div>
          <div className="flex items-center gap-4 text-xs text-[#E5CFA3] tabular-nums">
            <span>
              المكتمل: {completedInCategory} / {categoryItems.length}
            </span>
          </div>
        </div>
      </div>

      {/* Add Custom Dhikr Form */}
      {showAddForm && (
        <form
          onSubmit={handleCreateCustom}
          className="space-y-4 rounded-2xl border border-[#D4C9B0] bg-[#F3EDE2] p-5 dark:border-[#243B61] dark:bg-[#0F1C33]"
        >
          <h2 className="font-display text-xl font-bold text-[#0B162C] dark:text-[#F3EFE6]">
            إضافة ذكر أو دعاء جديد
          </h2>
          <div className="space-y-3">
            <div>
              <label className="mb-1.5 block text-xs font-medium text-[#525E70] dark:text-[#98A6BD]">
                نص الذكر أو الدعاء
              </label>
              <textarea
                required
                rows={3}
                value={newText}
                onChange={(e) => setNewText(e.target.value)}
                placeholder="اكتب الذكر هنا..."
                className="w-full rounded-xl border border-[#DED5C1] bg-[#FAF7F2] px-4 py-3 text-sm text-[#0B162C] focus:border-[#0F5143] focus:outline-none dark:border-[#23375A] dark:bg-[#081120] dark:text-[#F3EFE6] dark:focus:border-[#D4AF6A]"
              />
            </div>

            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div>
                <label className="mb-1.5 block text-xs font-medium text-[#525E70] dark:text-[#98A6BD]">
                  عدد التكرار المطلوب
                </label>
                <input
                  type="number"
                  min={1}
                  max={999}
                  value={newTarget}
                  onChange={(e) => setNewTarget(Number(e.target.value) || 1)}
                  className="w-full rounded-xl border border-[#DED5C1] bg-[#FAF7F2] px-4 py-2.5 text-sm tabular-nums text-[#0B162C] focus:border-[#0F5143] focus:outline-none dark:border-[#23375A] dark:bg-[#081120] dark:text-[#F3EFE6]"
                />
              </div>
              <div>
                <label className="mb-1.5 block text-xs font-medium text-[#525E70] dark:text-[#98A6BD]">
                  ملاحظة أو فضل الذكر (اختياري)
                </label>
                <input
                  type="text"
                  value={newVirtue}
                  onChange={(e) => setNewVirtue(e.target.value)}
                  placeholder="مثال: دعاء مستحب في الصباح"
                  className="w-full rounded-xl border border-[#DED5C1] bg-[#FAF7F2] px-4 py-2.5 text-sm text-[#0B162C] focus:border-[#0F5143] focus:outline-none dark:border-[#23375A] dark:bg-[#081120] dark:text-[#F3EFE6]"
                />
              </div>
            </div>
          </div>
          <div className="flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={() => setShowAddForm(false)}
              className="min-h-[42px] rounded-xl px-4 py-2 text-xs font-medium text-[#525E70] hover:text-[#0B162C] dark:text-[#98A6BD]"
            >
              إلغاء
            </button>
            <button
              type="submit"
              className="min-h-[42px] rounded-xl bg-[#0F5143] px-5 py-2 text-xs font-medium text-[#FAF7F2] hover:bg-[#0B3F34] dark:bg-[#D4AF6A] dark:text-[#081120]"
            >
              حفظ الذكر
            </button>
          </div>
        </form>
      )}

      {/* Search & Controls Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="relative min-w-[240px] flex-1 sm:max-w-sm">
          <Search
            className="pointer-events-none absolute right-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-[#6E7A8D]"
            aria-hidden="true"
          />
          <input
            type="search"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="ابحث في الأذكار..."
            className="min-h-[42px] w-full rounded-xl border border-[#DED5C1] bg-[#FAF7F2] pr-10 pl-4 text-sm text-[#0B162C] placeholder:text-[#7D8899] focus:border-[#0F5143] focus:outline-none dark:border-[#1B2C4A] dark:bg-[#0F1C33] dark:text-[#F3EFE6] dark:focus:border-[#D4AF6A]"
          />
        </div>

        <div className="flex flex-wrap items-center gap-4">
          <label className="inline-flex cursor-pointer items-center gap-2 text-xs font-medium text-[#525E70] dark:text-[#98A6BD]">
            <input
              type="checkbox"
              checked={settings.autoAdvanceDhikr}
              onChange={onToggleAutoAdvance}
              className="h-4 w-4 accent-[#0F5143] dark:accent-[#D4AF6A]"
            />
            <span>الانتقال التلقائي للذكر التالي</span>
          </label>

          {categoryItems.length > 0 && (
            <button
              type="button"
              onClick={() => onResetCategory(categoryItems.map((i) => i.id))}
              className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-medium text-[#525E70] transition-colors hover:bg-[#F3EDE2] hover:text-[#0B162C] dark:text-[#98A6BD] dark:hover:bg-[#152645]"
            >
              <RotateCcw className="h-3.5 w-3.5" aria-hidden="true" />
              <span>إعادة ضبط العدادات</span>
            </button>
          )}
        </div>
      </div>

      {/* Adhkar List */}
      {categoryItems.length === 0 ? (
        <div className="rounded-2xl border border-[#E5DEC9] bg-[#F3EDE2]/60 p-10 text-center dark:border-[#1B2C4A] dark:bg-[#0F1C33]/60">
          <p className="font-display text-xl text-[#0B162C] dark:text-[#F3EFE6]">
            {activeCategory === 'custom'
              ? 'لم تُضف أذكاراً خاصة بعد'
              : 'لا توجد نتائج مطابقة لبحثك'}
          </p>
          <p className="mt-2 text-sm text-[#525E70] dark:text-[#98A6BD]">
            {activeCategory === 'custom'
              ? 'يمكنك إضافة أذكارك وأدعيتك الخاصة لمتابعة تكرارها يومياً.'
              : 'جرّب البحث بكلمة أخرى أو تصفح قسم الأذكار الكامل.'}
          </p>
          {activeCategory === 'custom' && (
            <button
              type="button"
              onClick={() => setShowAddForm(true)}
              className="mt-5 inline-flex min-h-[44px] items-center gap-2 rounded-xl bg-[#0F5143] px-5 py-2.5 text-xs font-medium text-[#FAF7F2] dark:bg-[#D4AF6A] dark:text-[#081120]"
            >
              <Plus className="h-4 w-4" aria-hidden="true" />
              <span>إضافة أول ذكر</span>
            </button>
          )}
        </div>
      ) : (
        <div className="space-y-4">
          {categoryItems.map((item, idx) => {
            const current = counts[item.id] || 0;
            const isDone = current >= item.targetCount;
            const remaining = Math.max(0, item.targetCount - current);
            const pct = Math.min(100, Math.round((current / item.targetCount) * 100));

            return (
              <article
                id={`dhikr-card-${item.id}`}
                key={item.id}
                className={`rounded-2xl border p-6 transition-colors ${
                  isDone
                    ? 'border-[#0F5143]/40 bg-[#EBF3F0]/70 dark:border-[#2E8B74]/40 dark:bg-[#0D2426]/60'
                    : 'border-[#E5DEC9] bg-[#F3EDE2]/70 dark:border-[#1B2C4A] dark:bg-[#0F1C33]/80'
                }`}
              >
                {/* Quiet Unboxed Metadata Header */}
                <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-[#525E70] dark:text-[#98A6BD]">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="tabular-nums font-medium">
                      {String(idx + 1).padStart(2, '0')}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span>{item.reference}</span>
                    <span aria-hidden="true">·</span>
                    <span className="tabular-nums">التكرار: {item.targetCount}</span>
                  </div>

                  {item.isCustom && (
                    <button
                      type="button"
                      onClick={() => onDeleteCustomDhikr(item.id)}
                      aria-label="حذف الذكر الخاص"
                      className="flex min-h-[36px] min-w-[36px] items-center justify-center rounded-lg text-[#7D8899] hover:text-red-600 dark:hover:text-red-400"
                    >
                      <Trash2 className="h-4 w-4" aria-hidden="true" />
                    </button>
                  )}
                </div>

                {/* Main Arabic Dhikr Text */}
                <p className="mt-4 font-display text-2xl leading-[2.1] text-[#0B162C] sm:text-[26px] dark:text-[#F3EFE6]">
                  {item.text}
                </p>

                {item.virtue && (
                  <p className="mt-3 text-xs leading-relaxed text-[#525E70] dark:text-[#98A6BD]">
                    الفضل: {item.virtue}
                  </p>
                )}

                {/* Progress & Tap Action */}
                <div className="mt-5 flex flex-wrap items-center justify-between gap-4 border-t border-[#E5DEC9]/80 pt-4 dark:border-[#1B2C4A]">
                  <div className="flex-1 min-w-[140px] space-y-1.5">
                    <div className="flex items-center justify-between text-xs tabular-nums text-[#525E70] dark:text-[#98A6BD]">
                      <span>{isDone ? 'اكتمل بحمد الله' : `المتبقي ${remaining}`}</span>
                      <span>
                        {current} / {item.targetCount}
                      </span>
                    </div>
                    <div className="h-1.5 w-full overflow-hidden rounded-full bg-[#DED5C1] dark:bg-[#1B2C4A]">
                      <div
                        className={`h-full rounded-full transition-all duration-200 ${
                          isDone
                            ? 'bg-[#0F5143] dark:bg-[#4EA892]'
                            : 'bg-[#B88B4A] dark:bg-[#D4AF6A]'
                        }`}
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => handleTapDhikr(item)}
                    disabled={isDone}
                    className={`inline-flex min-h-[46px] min-w-[136px] items-center justify-center gap-2 rounded-xl px-5 py-2.5 text-sm font-medium transition-transform active:scale-[0.98] whitespace-nowrap shrink-0 ${
                      isDone
                        ? 'cursor-default bg-[#0F5143]/15 text-[#0F5143] dark:bg-[#2E8B74]/20 dark:text-[#6AC7B0]'
                        : 'bg-[#0F5143] text-[#FAF7F2] hover:bg-[#0B3F34] dark:bg-[#D4AF6A] dark:text-[#081120] dark:hover:bg-[#C29B54]'
                    }`}
                  >
                    {isDone ? (
                      <>
                        <Check className="h-4 w-4" aria-hidden="true" />
                        <span>مكتمل</span>
                      </>
                    ) : (
                      <span className="tabular-nums">تسبيح ({remaining})</span>
                    )}
                  </button>
                </div>
              </article>
            );
          })}
        </div>
      )}
    </div>
  );
}
