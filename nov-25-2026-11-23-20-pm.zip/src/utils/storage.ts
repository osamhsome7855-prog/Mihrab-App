import { AppSettings, DhikrItem } from '../types';

export const DEFAULT_SETTINGS: AppSettings = {
  userName: 'ضيف الكريم',
  theme: 'light',
  locationMode: 'preset',
  selectedCityId: 'makkah',
  customLat: 21.4225,
  customLng: 39.8262,
  customLocationName: 'مكة المكرمة',
  calculationMethod: 'UmmAlQura',
  madhhab: 'Shafi',
  notificationsEnabled: true,
  prayerAlerts: {
    fajr: true,
    dhuhr: true,
    asr: true,
    maghrib: true,
    isha: true,
  },
  prePrayerMinutes: 10,
  morningAdhkarTime: '06:00',
  eveningAdhkarTime: '17:30',
  morningAdhkarEnabled: true,
  eveningAdhkarEnabled: true,
  adhanTone: 'makkah_chime',
  adhkarTone: 'morning_breeze',
  prePrayerTone: 'gentle_bell',
  volume: 0.75,
  autoAdvanceDhikr: true,
  hapticEnabled: true,
};

const SETTINGS_KEY = 'mihrab_settings_v1';
const DHIKR_PROGRESS_KEY = 'mihrab_dhikr_progress_v1';
const CUSTOM_ADHKAR_KEY = 'mihrab_custom_adhkar_v1';
const TASBIH_STATE_KEY = 'mihrab_tasbih_v1';

export function loadSettings(): AppSettings {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (!raw) return DEFAULT_SETTINGS;
    const parsed = JSON.parse(raw) as Partial<AppSettings>;
    return {
      ...DEFAULT_SETTINGS,
      ...parsed,
      prayerAlerts: {
        ...DEFAULT_SETTINGS.prayerAlerts,
        ...(parsed.prayerAlerts || {}),
      },
    };
  } catch {
    return DEFAULT_SETTINGS;
  }
}

export function saveSettings(settings: AppSettings): void {
  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  } catch {
    // ignore quota errors
  }
}

export interface DailyDhikrProgress {
  dateKey: string;
  counts: Record<string, number>;
}

export function getTodayKey(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

export function loadDailyDhikrProgress(): DailyDhikrProgress {
  const today = getTodayKey();
  try {
    const raw = localStorage.getItem(DHIKR_PROGRESS_KEY);
    if (!raw) return { dateKey: today, counts: {} };
    const parsed = JSON.parse(raw) as DailyDhikrProgress;
    if (parsed.dateKey !== today) {
      return { dateKey: today, counts: {} };
    }
    return parsed;
  } catch {
    return { dateKey: today, counts: {} };
  }
}

export function saveDailyDhikrProgress(progress: DailyDhikrProgress): void {
  try {
    localStorage.setItem(DHIKR_PROGRESS_KEY, JSON.stringify(progress));
  } catch {
    // ignore
  }
}

export function loadCustomAdhkar(): DhikrItem[] {
  try {
    const raw = localStorage.getItem(CUSTOM_ADHKAR_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function saveCustomAdhkar(items: DhikrItem[]): void {
  try {
    localStorage.setItem(CUSTOM_ADHKAR_KEY, JSON.stringify(items));
  } catch {
    // ignore
  }
}

export interface TasbihStoredState {
  phraseIndex: number;
  customPhrase: string;
  target: number;
  count: number;
  lifetimeTotal: number;
}

export function loadTasbihState(): TasbihStoredState {
  try {
    const raw = localStorage.getItem(TASBIH_STATE_KEY);
    if (!raw) {
      return {
        phraseIndex: 0,
        customPhrase: '',
        target: 33,
        count: 0,
        lifetimeTotal: 0,
      };
    }
    return JSON.parse(raw) as TasbihStoredState;
  } catch {
    return {
      phraseIndex: 0,
      customPhrase: '',
      target: 33,
      count: 0,
      lifetimeTotal: 0,
    };
  }
}

export function saveTasbihState(state: TasbihStoredState): void {
  try {
    localStorage.setItem(TASBIH_STATE_KEY, JSON.stringify(state));
  } catch {
    // ignore
  }
}
