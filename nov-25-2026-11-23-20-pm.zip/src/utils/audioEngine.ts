import { ToneDefinition, ToneId } from '../types';

export const TONES: ToneDefinition[] = [
  {
    id: 'makkah_chime',
    nameAr: 'نداء الحرم الهادي',
    descriptionAr: 'نغمة رنين دافئة مستوحاة من مقام الحجاز بتدرج ناعم ومريح للسمع.',
    category: 'adhan',
    durationLabel: '٦ ثوانٍ',
  },
  {
    id: 'fajr_calm',
    nameAr: 'إشراقة الفجر',
    descriptionAr: 'نغمة روحانية هادئة تبدأ بتدرج لطيف مثالي لوقت الفجر.',
    category: 'adhan',
    durationLabel: '٥ ثوانٍ',
  },
  {
    id: 'takbir_dew',
    nameAr: 'تكبيرة ندية',
    descriptionAr: 'نغمتان متناغمتان بصدى دافئ للتنبيه بدخول وقت الصلاة.',
    category: 'adhan',
    durationLabel: '٤ ثوانٍ',
  },
  {
    id: 'morning_breeze',
    nameAr: 'نسيم الصباح',
    descriptionAr: 'تآلف وتري خفيف ينبّه بلطف لموعد أذكار الصباح.',
    category: 'adhkar',
    durationLabel: '٤ ثوانٍ',
  },
  {
    id: 'evening_calm',
    nameAr: 'سكينة المساء',
    descriptionAr: 'نغمة عميقة دافئة تساعد على التأمل والهدوء المسائي.',
    category: 'adhkar',
    durationLabel: '٤ ثوانٍ',
  },
  {
    id: 'musk_bowl',
    nameAr: 'رنين المسك',
    descriptionAr: 'رنين بلوري نقي طويل الصدى للتنبيهات الروحانية.',
    category: 'adhkar',
    durationLabel: '٥ ثوانٍ',
  },
  {
    id: 'gentle_bell',
    nameAr: 'جرس الاستعداد اللطيف',
    descriptionAr: 'نقرة جرس ثنائية نقية للتذكير قبل دخول وقت الصلاة.',
    category: 'prePrayer',
    durationLabel: '٣ ثوانٍ',
  },
];

let sharedAudioCtx: AudioContext | null = null;

function getAudioContext(): AudioContext | null {
  if (typeof window === 'undefined') return null;
  const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
  if (!AudioCtx) return null;
  if (!sharedAudioCtx) {
    sharedAudioCtx = new AudioCtx();
  }
  if (sharedAudioCtx.state === 'suspended') {
    sharedAudioCtx.resume().catch(() => {});
  }
  return sharedAudioCtx;
}

interface NoteSpec {
  freq: number;
  start: number;
  duration: number;
  type?: OscillatorType;
  gain?: number;
}

function scheduleNotes(notes: NoteSpec[], volume: number): void {
  const ctx = getAudioContext();
  if (!ctx) return;

  const masterGain = ctx.createGain();
  masterGain.gain.setValueAtTime(Math.max(0.02, Math.min(1, volume)) * 0.45, ctx.currentTime);

  const filter = ctx.createBiquadFilter();
  filter.type = 'lowpass';
  filter.frequency.setValueAtTime(2400, ctx.currentTime);

  filter.connect(masterGain);
  masterGain.connect(ctx.destination);

  const now = ctx.currentTime;

  notes.forEach((n) => {
    const osc = ctx.createOscillator();
    const harmonic = ctx.createOscillator();
    const noteGain = ctx.createGain();

    osc.type = n.type || 'sine';
    osc.frequency.setValueAtTime(n.freq, now + n.start);

    harmonic.type = 'sine';
    harmonic.frequency.setValueAtTime(n.freq * 2, now + n.start);

    const harmonicGain = ctx.createGain();
    harmonicGain.gain.setValueAtTime(0.18, now + n.start);

    const peak = n.gain ?? 0.55;
    noteGain.gain.setValueAtTime(0.0001, now + n.start);
    noteGain.gain.exponentialRampToValueAtTime(peak, now + n.start + 0.08);
    noteGain.gain.exponentialRampToValueAtTime(0.0001, now + n.start + n.duration);

    osc.connect(noteGain);
    harmonic.connect(harmonicGain);
    harmonicGain.connect(noteGain);
    noteGain.connect(filter);

    osc.start(now + n.start);
    harmonic.start(now + n.start);
    osc.stop(now + n.start + n.duration + 0.05);
    harmonic.stop(now + n.start + n.duration + 0.05);
  });
}

export function playTone(toneId: ToneId, volume = 0.7): void {
  switch (toneId) {
    case 'makkah_chime':
      // Hijaz-inspired warm interval progression (D4 - Eb4 - F#4 - G4 - A4 - D5)
      scheduleNotes(
        [
          { freq: 293.66, start: 0, duration: 1.5, type: 'triangle', gain: 0.48 },
          { freq: 311.13, start: 0.65, duration: 1.4, type: 'sine', gain: 0.45 },
          { freq: 369.99, start: 1.3, duration: 1.8, type: 'triangle', gain: 0.52 },
          { freq: 392.0, start: 2.2, duration: 1.7, type: 'sine', gain: 0.5 },
          { freq: 440.0, start: 3.1, duration: 2.2, type: 'sine', gain: 0.55 },
          { freq: 293.66, start: 3.1, duration: 2.4, type: 'sine', gain: 0.35 },
        ],
        volume
      );
      break;
    case 'fajr_calm':
      // Gentle rising dawn fifths
      scheduleNotes(
        [
          { freq: 261.63, start: 0, duration: 1.8, type: 'sine', gain: 0.4 },
          { freq: 392.0, start: 0.85, duration: 1.8, type: 'sine', gain: 0.42 },
          { freq: 440.0, start: 1.7, duration: 2.0, type: 'triangle', gain: 0.45 },
          { freq: 523.25, start: 2.6, duration: 2.4, type: 'sine', gain: 0.48 },
        ],
        volume
      );
      break;
    case 'takbir_dew':
      scheduleNotes(
        [
          { freq: 329.63, start: 0, duration: 1.4, type: 'triangle', gain: 0.5 },
          { freq: 493.88, start: 0.45, duration: 1.8, type: 'sine', gain: 0.5 },
          { freq: 392.0, start: 1.5, duration: 1.8, type: 'triangle', gain: 0.48 },
          { freq: 587.33, start: 1.95, duration: 2.1, type: 'sine', gain: 0.46 },
        ],
        volume
      );
      break;
    case 'morning_breeze':
      scheduleNotes(
        [
          { freq: 440.0, start: 0, duration: 1.2, type: 'sine', gain: 0.45 },
          { freq: 554.37, start: 0.3, duration: 1.2, type: 'sine', gain: 0.45 },
          { freq: 659.25, start: 0.6, duration: 1.6, type: 'sine', gain: 0.48 },
          { freq: 880.0, start: 0.95, duration: 2.1, type: 'sine', gain: 0.38 },
        ],
        volume
      );
      break;
    case 'evening_calm':
      scheduleNotes(
        [
          { freq: 220.0, start: 0, duration: 2.0, type: 'sine', gain: 0.5 },
          { freq: 329.63, start: 0.6, duration: 2.0, type: 'sine', gain: 0.42 },
          { freq: 293.66, start: 1.5, duration: 2.4, type: 'triangle', gain: 0.45 },
        ],
        volume
      );
      break;
    case 'musk_bowl':
      scheduleNotes(
        [
          { freq: 432.0, start: 0, duration: 3.4, type: 'sine', gain: 0.55 },
          { freq: 648.0, start: 0.05, duration: 2.8, type: 'sine', gain: 0.25 },
          { freq: 432.0, start: 1.8, duration: 2.8, type: 'sine', gain: 0.42 },
        ],
        volume
      );
      break;
    case 'gentle_bell':
    default:
      scheduleNotes(
        [
          { freq: 587.33, start: 0, duration: 1.2, type: 'sine', gain: 0.45 },
          { freq: 783.99, start: 0.45, duration: 1.6, type: 'sine', gain: 0.42 },
        ],
        volume
      );
      break;
  }
}

export function playTasbihClick(isTargetReached = false, volume = 0.6): void {
  const ctx = getAudioContext();
  if (!ctx) return;
  const now = ctx.currentTime;
  const gain = ctx.createGain();
  const osc = ctx.createOscillator();

  if (isTargetReached) {
    osc.type = 'sine';
    osc.frequency.setValueAtTime(659.25, now);
    osc.frequency.exponentialRampToValueAtTime(880, now + 0.12);
    gain.gain.setValueAtTime(0.001, now);
    gain.gain.exponentialRampToValueAtTime(Math.max(0.05, volume) * 0.28, now + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.55);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.6);
  } else {
    osc.type = 'sine';
    osc.frequency.setValueAtTime(520, now);
    osc.frequency.exponentialRampToValueAtTime(280, now + 0.045);
    gain.gain.setValueAtTime(0.001, now);
    gain.gain.exponentialRampToValueAtTime(Math.max(0.05, volume) * 0.16, now + 0.008);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.06);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.07);
  }
}
