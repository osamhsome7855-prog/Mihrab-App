import {
  CalculationMethod,
  CalculationParameters,
  Coordinates,
  Madhab,
  Prayer,
  PrayerTimes,
  Qibla,
} from 'adhan';
import { CITY_PRESETS } from '../data/cities';
import {
  AppSettings,
  CalculationMethodKey,
  ComputedPrayerState,
  MadhhabKey,
  PrayerKey,
  PrayerScheduleItem,
} from '../types';

export const PRAYER_NAMES_AR: Record<PrayerKey, string> = {
  fajr: 'الفجر',
  sunrise: 'الشروق',
  dhuhr: 'الظهر',
  asr: 'العصر',
  maghrib: 'المغرب',
  isha: 'العشاء',
};

function getCalculationParams(method: CalculationMethodKey, madhhab: MadhhabKey): CalculationParameters {
  let params: CalculationParameters;
  switch (method) {
    case 'UmmAlQura':
      params = CalculationMethod.UmmAlQura();
      break;
    case 'Egyptian':
      params = CalculationMethod.Egyptian();
      break;
    case 'Karachi':
      params = CalculationMethod.Karachi();
      break;
    case 'NorthAmerica':
      params = CalculationMethod.NorthAmerica();
      break;
    case 'Dubai':
      params = CalculationMethod.Dubai();
      break;
    case 'Qatar':
      params = CalculationMethod.Qatar();
      break;
    case 'Kuwait':
      params = CalculationMethod.Kuwait();
      break;
    case 'MuslimWorldLeague':
    default:
      params = CalculationMethod.MuslimWorldLeague();
      break;
  }

  params.madhab = madhhab === 'Hanafi' ? Madhab.Hanafi : Madhab.Shafi;
  return params;
}

function mapAdhanPrayer(prayer: (typeof Prayer)[keyof typeof Prayer]): PrayerKey | null {
  switch (prayer) {
    case Prayer.Fajr:
      return 'fajr';
    case Prayer.Sunrise:
      return 'sunrise';
    case Prayer.Dhuhr:
      return 'dhuhr';
    case Prayer.Asr:
      return 'asr';
    case Prayer.Maghrib:
      return 'maghrib';
    case Prayer.Isha:
      return 'isha';
    default:
      return null;
  }
}

export function formatTimeArabic(date: Date): string {
  return new Intl.DateTimeFormat('ar-EG', {
    hour: '2-digit',
    minute: '2-digit',
    hour12: true,
  }).format(date);
}

export function formatHijriDate(date: Date): string {
  try {
    return new Intl.DateTimeFormat('ar-SA-u-ca-islamic-umalqura', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
    }).format(date);
  } catch {
    return new Intl.DateTimeFormat('ar-SA', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
    }).format(date);
  }
}

export function formatGregorianDate(date: Date): string {
  return new Intl.DateTimeFormat('ar-EG', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  }).format(date);
}

export function resolveCoordinates(settings: AppSettings): {
  lat: number;
  lng: number;
  label: string;
} {
  if (settings.locationMode === 'gps') {
    return {
      lat: settings.customLat,
      lng: settings.customLng,
      label: settings.customLocationName || 'الموقع الجغرافي الحالي',
    };
  }
  const city = CITY_PRESETS.find((c) => c.id === settings.selectedCityId) || CITY_PRESETS[0];
  return {
    lat: city.lat,
    lng: city.lng,
    label: `${city.nameAr}، ${city.countryAr}`,
  };
}

export function computePrayerState(settings: AppSettings, now = new Date()): ComputedPrayerState {
  const { lat, lng, label } = resolveCoordinates(settings);
  const coordinates = new Coordinates(lat, lng);
  const params = getCalculationParams(settings.calculationMethod, settings.madhhab);

  const todayTimes = new PrayerTimes(coordinates, now, params);
  const tomorrowDate = new Date(now);
  tomorrowDate.setDate(tomorrowDate.getDate() + 1);
  const tomorrowTimes = new PrayerTimes(coordinates, tomorrowDate, params);

  const currentPrayerEnum = todayTimes.currentPrayer(now);
  const currentPrayerKey = mapAdhanPrayer(currentPrayerEnum);

  const nextPrayerEnum = todayTimes.nextPrayer(now);
  let nextPrayerKey = mapAdhanPrayer(nextPrayerEnum);
  let nextPrayerTime: Date;

  if (!nextPrayerKey) {
    nextPrayerKey = 'fajr';
    nextPrayerTime = tomorrowTimes.fajr;
  } else {
    nextPrayerTime = todayTimes[nextPrayerKey];
  }

  const keys: PrayerKey[] = ['fajr', 'sunrise', 'dhuhr', 'asr', 'maghrib', 'isha'];
  const schedule: PrayerScheduleItem[] = keys.map((key) => {
    const time = todayTimes[key];
    return {
      key,
      nameAr: PRAYER_NAMES_AR[key],
      time,
      formattedTime: formatTimeArabic(time),
      isNext: nextPrayerEnum !== Prayer.None && nextPrayerKey === key,
      isCurrent: currentPrayerKey === key,
      isAlertable: key !== 'sunrise',
    };
  });

  const diffMs = Math.max(0, nextPrayerTime.getTime() - now.getTime());
  const totalSeconds = Math.floor(diffMs / 1000);
  const hrs = Math.floor(totalSeconds / 3600);
  const mins = Math.floor((totalSeconds % 3600) / 60);
  const secs = totalSeconds % 60;

  const pad = (n: number) => String(n).padStart(2, '0');

  return {
    schedule,
    nextPrayer: {
      key: nextPrayerKey,
      nameAr: PRAYER_NAMES_AR[nextPrayerKey],
      time: nextPrayerTime,
      formattedTime: formatTimeArabic(nextPrayerTime),
    },
    currentPrayerKey,
    countdown: {
      hours: pad(hrs),
      minutes: pad(mins),
      seconds: pad(secs),
      totalSeconds,
    },
    qiblaAngle: Math.round(Qibla(coordinates)),
    hijriDate: formatHijriDate(now),
    gregorianDate: formatGregorianDate(now),
    locationLabel: label,
  };
}
