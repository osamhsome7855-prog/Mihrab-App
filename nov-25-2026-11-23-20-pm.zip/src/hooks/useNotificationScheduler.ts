import { useEffect, useRef } from 'react';
import { ActiveAlertBanner, AppSettings, ComputedPrayerState } from '../types';
import { playTone } from '../utils/audioEngine';
import { formatTimeArabic } from '../utils/prayerService';

function sendBrowserNotification(title: string, body: string): void {
  if (typeof window === 'undefined' || !('Notification' in window)) return;
  if (Notification.permission === 'granted') {
    try {
      new Notification(title, {
        body,
        dir: 'rtl',
        lang: 'ar',
      });
    } catch {
      // ignore sandbox notification errors
    }
  }
}

export function useNotificationScheduler(
  settings: AppSettings,
  prayerState: ComputedPrayerState,
  onTriggerAlert: (alert: ActiveAlertBanner) => void
): void {
  const firedKeysRef = useRef<Set<string>>(new Set());

  useEffect(() => {
    if (!settings.notificationsEnabled) return;

    const checkSchedule = () => {
      const now = new Date();
      const dayKey = `${now.getFullYear()}-${now.getMonth() + 1}-${now.getDate()}`;
      const currentHHMM = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;

      // 1. Check exact prayer times & pre-prayer reminders
      for (const item of prayerState.schedule) {
        if (!item.isAlertable) continue;
        const alertKey = item.key as keyof AppSettings['prayerAlerts'];
        if (!settings.prayerAlerts[alertKey]) continue;

        const prayerHHMM = `${String(item.time.getHours()).padStart(2, '0')}:${String(item.time.getMinutes()).padStart(2, '0')}`;
        const exactKey = `${dayKey}-prayer-${item.key}-${prayerHHMM}`;

        if (currentHHMM === prayerHHMM && !firedKeysRef.current.has(exactKey)) {
          firedKeysRef.current.add(exactKey);
          const title = `حان الآن موعد صلاة ${item.nameAr}`;
          const message = `حسب التوقيت المحلي لـ ${prayerState.locationLabel} (${formatTimeArabic(item.time)})`;
          playTone(settings.adhanTone, settings.volume);
          sendBrowserNotification(title, message);
          onTriggerAlert({
            id: exactKey,
            title,
            message,
            type: 'adhan',
            timestamp: formatTimeArabic(now),
          });
        }

        if (settings.prePrayerMinutes > 0) {
          const preTime = new Date(item.time.getTime() - settings.prePrayerMinutes * 60 * 1000);
          const preHHMM = `${String(preTime.getHours()).padStart(2, '0')}:${String(preTime.getMinutes()).padStart(2, '0')}`;
          const preKey = `${dayKey}-pre-${item.key}-${preHHMM}`;

          if (currentHHMM === preHHMM && !firedKeysRef.current.has(preKey)) {
            firedKeysRef.current.add(preKey);
            const title = `اقترب موعد صلاة ${item.nameAr}`;
            const message = `متبقي ${settings.prePrayerMinutes} دقائق على الأذان`;
            playTone(settings.prePrayerTone, settings.volume);
            sendBrowserNotification(title, message);
            onTriggerAlert({
              id: preKey,
              title,
              message,
              type: 'prePrayer',
              timestamp: formatTimeArabic(now),
            });
          }
        }
      }

      // 2. Check Morning Adhkar reminder
      if (settings.morningAdhkarEnabled && currentHHMM === settings.morningAdhkarTime) {
        const morningKey = `${dayKey}-adhkar-morning-${currentHHMM}`;
        if (!firedKeysRef.current.has(morningKey)) {
          firedKeysRef.current.add(morningKey);
          const title = 'موعد أذكار الصباح';
          const message = 'ابدأ يومك بذكر الله وطمأنينة القلب.';
          playTone(settings.adhkarTone, settings.volume);
          sendBrowserNotification(title, message);
          onTriggerAlert({
            id: morningKey,
            title,
            message,
            type: 'adhkar',
            timestamp: formatTimeArabic(now),
          });
        }
      }

      // 3. Check Evening Adhkar reminder
      if (settings.eveningAdhkarEnabled && currentHHMM === settings.eveningAdhkarTime) {
        const eveningKey = `${dayKey}-adhkar-evening-${currentHHMM}`;
        if (!firedKeysRef.current.has(eveningKey)) {
          firedKeysRef.current.add(eveningKey);
          const title = 'موعد أذكار المساء';
          const message = 'حصّن مساءك بالذكر والدعاء والسكينة.';
          playTone(settings.adhkarTone, settings.volume);
          sendBrowserNotification(title, message);
          onTriggerAlert({
            id: eveningKey,
            title,
            message,
            type: 'adhkar',
            timestamp: formatTimeArabic(now),
          });
        }
      }
    };

    checkSchedule();
    const timer = window.setInterval(checkSchedule, 1000);
    return () => window.clearInterval(timer);
  }, [settings, prayerState, onTriggerAlert]);
}
