package com.mihrab.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mihrab.app.R
import com.mihrab.app.audio.MihrabAudioEngine
import com.mihrab.app.data.AdhkarData
import com.mihrab.app.model.AppSettings
import com.mihrab.app.model.DhikrCategory
import com.mihrab.app.model.DhikrItem
import com.mihrab.app.ui.theme.mihrabPalette
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun AdhkarScreen(
    settings: AppSettings,
    counts: Map<String, Int>,
    customAdhkar: List<DhikrItem>,
    onIncrementDhikr: (DhikrItem) -> Unit,
    onResetCategory: (List<String>) -> Unit,
    onAddCustomDhikr: (text: String, targetCount: Int, virtue: String) -> Unit,
    onDeleteCustomDhikr: (String) -> Unit,
    onToggleAutoAdvance: () -> Unit
) {
    val p = mihrabPalette(settings.isDarkTheme)
    var activeCategory by remember { mutableStateOf(DhikrCategory.MORNING) }
    var searchQuery by remember { mutableStateOf("") }
    var showAddDialog by remember { mutableStateOf(false) }

    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()

    val allItems = remember(customAdhkar) { AdhkarData.builtInAdhkar + customAdhkar }
    val categoryItems = remember(allItems, activeCategory, searchQuery) {
        val base = allItems.filter { it.category == activeCategory }
        val q = searchQuery.trim()
        if (q.isEmpty()) base
        else base.filter {
            it.text.contains(q) || it.reference.contains(q) || (it.virtue?.contains(q) == true)
        }
    }

    val completedCount = remember(categoryItems, counts) {
        categoryItems.count { (counts[it.id] ?: 0) >= it.targetCount }
    }

    val bannerDrawable = if (activeCategory == DhikrCategory.EVENING || activeCategory == DhikrCategory.SLEEP) {
        R.drawable.adhkar_evening_lantern
    } else {
        R.drawable.adhkar_morning_light
    }

    LazyColumn(
        state = listState,
        modifier = Modifier
            .fillMaxSize()
            .background(p.canvas),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Category Tabs
        item {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(DhikrCategory.entries) { category ->
                    val isSelected = activeCategory == category
                    Surface(
                        onClick = { activeCategory = category },
                        shape = RoundedCornerShape(12.dp),
                        color = if (isSelected) p.accentPrimary else p.surface,
                        border = BorderStroke(1.dp, if (isSelected) p.accentPrimary else p.border)
                    ) {
                        Text(
                            text = category.labelAr,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            color = if (isSelected) p.onAccentPrimary else p.ink,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
                        )
                    }
                }
            }
        }

        // Action Row: Play Tone & Add Custom Dhikr
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = { MihrabAudioEngine.playTone(settings.adhkarTone, settings.volume) },
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, p.borderStrong),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = p.surface,
                        contentColor = p.ink
                    ),
                    modifier = Modifier.weight(1f).height(44.dp)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.VolumeUp,
                        contentDescription = null,
                        tint = p.accentPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "نغمة الأذكار", fontSize = 12.sp, maxLines = 1)
                }

                Button(
                    onClick = { showAddDialog = true },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = p.accentPrimary,
                        contentColor = p.onAccentPrimary
                    ),
                    modifier = Modifier.weight(1f).height(44.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Add,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "إضافة ذكر خاص", fontSize = 12.sp, maxLines = 1)
                }
            }
        }

        // Editorial Banner
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(160.dp)
                    .clip(RoundedCornerShape(18.dp))
            ) {
                Image(
                    painter = painterResource(id = bannerDrawable),
                    contentDescription = activeCategory.labelAr,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color.Transparent, Color(0xFF081120).copy(alpha = 0.88f))
                            )
                        )
                )
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        Text(
                            text = activeCategory.labelAr,
                            style = MaterialTheme.typography.headlineMedium,
                            color = Color(0xFFFAF7F2)
                        )
                        Text(
                            text = "المكتمل: $completedCount / ${categoryItems.size}",
                            fontSize = 12.sp,
                            color = Color(0xFFE5CFA3)
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = activeCategory.subtitleAr,
                        fontSize = 12.sp,
                        color = Color(0xFFDCE2EC)
                    )
                }
            }
        }

        // Search & Auto-Advance Controls
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("ابحث في الأذكار...") },
                    leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(
                            checked = settings.autoAdvanceDhikr,
                            onCheckedChange = { onToggleAutoAdvance() },
                            colors = CheckboxDefaults.colors(checkedColor = p.accentPrimary)
                        )
                        Text(
                            text = "الانتقال التلقائي للذكر التالي",
                            fontSize = 13.sp,
                            color = p.mutedInk
                        )
                    }

                    if (categoryItems.isNotEmpty()) {
                        TextButton(
                            onClick = { onResetCategory(categoryItems.map { it.id }) }
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Refresh,
                                contentDescription = null,
                                tint = p.mutedInk,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = "إعادة ضبط", fontSize = 12.sp, color = p.mutedInk)
                        }
                    }
                }
            }
        }

        // Empty State or Adhkar List
        if (categoryItems.isEmpty()) {
            item {
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = p.surface,
                    border = BorderStroke(1.dp, p.border),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(28.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = if (activeCategory == DhikrCategory.CUSTOM) {
                                "لم تُضف أذكاراً خاصة بعد"
                            } else {
                                "لا توجد نتائج مطابقة لبحثك"
                            },
                            style = MaterialTheme.typography.titleLarge,
                            color = p.ink
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = if (activeCategory == DhikrCategory.CUSTOM) {
                                "يمكنك إضافة أذكارك وأدعيتك الخاصة لمتابعة تكرارها يومياً."
                            } else {
                                "جرّب البحث بكلمة أخرى أو تصفح القسم كاملاً."
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            color = p.mutedInk
                        )
                    }
                }
            }
        } else {
            itemsIndexed(categoryItems, key = { _, item -> item.id }) { idx, item ->
                val current = counts[item.id] ?: 0
                val isDone = current >= item.targetCount
                val remaining = (item.targetCount - current).coerceAtLeast(0)
                val progress = (current.toFloat() / item.targetCount.toFloat()).coerceIn(0f, 1f)

                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = if (isDone) p.doneSurface else p.surface,
                    border = BorderStroke(
                        1.dp,
                        if (isDone) p.accentPrimary.copy(alpha = 0.45f) else p.border
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${(idx + 1).toString().padStart(2, '0')} · ${item.reference} · التكرار: ${item.targetCount}",
                                fontSize = 12.sp,
                                color = p.mutedInk,
                                modifier = Modifier.weight(1f)
                            )
                            if (item.isCustom) {
                                IconButton(
                                    onClick = { onDeleteCustomDhikr(item.id) },
                                    modifier = Modifier.size(34.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.DeleteOutline,
                                        contentDescription = "حذف الذكر الخاص",
                                        tint = p.mutedInk,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = item.text,
                            fontSize = 21.sp,
                            lineHeight = 38.sp,
                            color = p.ink,
                            style = MaterialTheme.typography.titleLarge
                        )

                        if (!item.virtue.isNullOrBlank()) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "الفضل: ${item.virtue}",
                                fontSize = 12.sp,
                                lineHeight = 20.sp,
                                color = p.mutedInk
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))
                        HorizontalDivider(color = p.border)
                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = if (isDone) "اكتمل بحمد الله" else "المتبقي $remaining",
                                        fontSize = 12.sp,
                                        color = p.mutedInk
                                    )
                                    Text(
                                        text = "$current / ${item.targetCount}",
                                        fontSize = 12.sp,
                                        color = p.mutedInk
                                    )
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                LinearProgressIndicator(
                                    progress = { progress },
                                    color = if (isDone) p.doneInk else p.accentGold,
                                    trackColor = p.borderStrong,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(6.dp)
                                        .clip(RoundedCornerShape(3.dp))
                                )
                            }

                            Button(
                                onClick = {
                                    val willComplete = current + 1 >= item.targetCount
                                    onIncrementDhikr(item)
                                    if (willComplete && settings.autoAdvanceDhikr) {
                                        val nextIndex = idx + 1
                                        if (nextIndex < categoryItems.size) {
                                            scope.launch {
                                                delay(180)
                                                listState.animateScrollToItem(nextIndex + 4)
                                            }
                                        }
                                    }
                                },
                                enabled = !isDone,
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = p.accentPrimary,
                                    contentColor = p.onAccentPrimary,
                                    disabledContainerColor = p.accentPrimary.copy(alpha = 0.16f),
                                    disabledContentColor = p.doneInk
                                ),
                                modifier = Modifier.height(44.dp)
                            ) {
                                if (isDone) {
                                    Icon(
                                        imageVector = Icons.Rounded.Check,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(text = "مكتمل", fontSize = 13.sp)
                                } else {
                                    Text(text = "تسبيح ($remaining)", fontSize = 13.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        AddCustomDhikrDialog(
            onDismiss = { showAddDialog = false },
            onSave = { text, target, virtue ->
                onAddCustomDhikr(text, target, virtue)
                showAddDialog = false
                activeCategory = DhikrCategory.CUSTOM
            }
        )
    }
}

@Composable
private fun AddCustomDhikrDialog(
    onDismiss: () -> Unit,
    onSave: (text: String, target: Int, virtue: String) -> Unit
) {
    var text by remember { mutableStateOf("") }
    var targetStr by remember { mutableStateOf("3") }
    var virtue by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "إضافة ذكر أو دعاء جديد",
                style = MaterialTheme.typography.titleLarge
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    label = { Text("نص الذكر أو الدعاء") },
                    minLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = targetStr,
                    onValueChange = { targetStr = it.filter { ch -> ch.isDigit() } },
                    label = { Text("عدد التكرار المطلوب") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = virtue,
                    onValueChange = { virtue = it },
                    label = { Text("ملاحظة أو فضل الذكر (اختياري)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val count = targetStr.toIntOrNull()?.coerceIn(1, 999) ?: 3
                    onSave(text, count, virtue)
                },
                enabled = text.isNotBlank()
            ) {
                Text("حفظ الذكر")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        }
    )
}
