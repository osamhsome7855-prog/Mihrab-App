package com.mihrab.app.model

enum class PrayerKey(val labelAr: String, val isAlertable: Boolean) {
    FAJR("الفجر", true),
    SUNRISE("الشروق", false),
    DHUHR("الظهر", true),
    ASR("العصر", true),
    MAGHRIB("المغرب", true),
    ISHA("العشاء", true)
}

enum class CalculationMethodKey(val labelAr: String, val fajrAngle: Double, val ishaAngle: Double?, val ishaIntervalMinutes: Int?) {
    UMM_AL_QURA("تقويم أم القرى (مكة المكرمة)", 18.5, null, 90),
    EGYPTIAN("الهيئة المصرية العامة للمساحة", 19.5, 17.5, null),
    MUSLIM_WORLD_LEAGUE("رابطة العالم الإسلامي", 18.0, 17.0, null),
    DUBAI("دائرة الشؤون الإسلامية بدبي", 18.2, 18.2, null),
    QATAR("التقويم القطري", 18.0, null, 90),
    KUWAIT("وزارة الأوقاف الكويتية", 18.0, 17.5, null),
    KARACHI("جامعة العلوم الإسلامية بكراتشي", 18.0, 18.0, null),
    NORTH_AMERICA("الجمعية الإسلامية لأمريكا الشمالية (ISNA)", 15.0, 15.0, null)
}

enum class MadhhabKey(val labelAr: String, val shadowFactor: Int) {
    SHAFI("الجمهور (الشافعي والمالكي والحنبلي)", 1),
    HANAFI("المذهب الحنفي", 2)
}

enum class ToneCategory {
    ADHAN,
    ADHKAR,
    PRE_PRAYER
}

enum class ToneId(
    val nameAr: String,
    val descriptionAr: String,
    val category: ToneCategory,
    val durationLabel: String
) {
    MAKKAH_CHIME("نداء الحرم الهادي", "نغمة رنين دافئة مستوحاة من مقام الحجاز بتدرج ناعم ومريح للسمع.", ToneCategory.ADHAN, "٦ ثوانٍ"),
    FAJR_CALM("إشراقة الفجر", "نغمة روحانية هادئة تبدأ بتدرج لطيف مثالي لوقت الفجر.", ToneCategory.ADHAN, "٥ ثوانٍ"),
    TAKBIR_DEW("تكبيرة ندية", "نغمتان متناغمتان بصدى دافئ للتنبيه بدخول وقت الصلاة.", ToneCategory.ADHAN, "٤ ثوانٍ"),
    MORNING_BREEZE("نسيم الصباح", "تآلف وتري خفيف ينبّه بلطف لموعد أذكار الصباح.", ToneCategory.ADHKAR, "٤ ثوانٍ"),
    EVENING_CALM("سكينة المساء", "نغمة عميقة دافئة تساعد على التأمل والهدوء المسائي.", ToneCategory.ADHKAR, "٤ ثوانٍ"),
    MUSK_BOWL("رنين المسك", "رنين بلوري نقي طويل الصدى للتنبيهات الروحانية.", ToneCategory.ADHKAR, "٥ ثوانٍ"),
    GENTLE_BELL("جرس الاستعداد اللطيف", "نقرة جرس ثنائية نقية للتذكير قبل دخول وقت الصلاة.", ToneCategory.PRE_PRAYER, "٣ ثوانٍ")
}

data class CityPreset(
    val id: String,
    val nameAr: String,
    val countryAr: String,
    val lat: Double,
    val lng: Double,
    val method: CalculationMethodKey
)

enum class DhikrCategory(val labelAr: String, val subtitleAr: String) {
    MORNING("أذكار الصباح", "تُقال من بعد صلاة الفجر حتى طلوع الشمس أو الضحى"),
    EVENING("أذكار المساء", "تُقال من بعد صلاة العصر حتى غروب الشمس وأول الليل"),
    AFTER_PRAYER("بعد الصلاة", "الأذكار المشروعة دُبُر كل صلاة مكتوبة"),
    SLEEP("أذكار النوم", "التحصين والسكينة عند الإيواء إلى الفراش"),
    CUSTOM("أذكاري الخاصة", "أذكار وأدعية أضفتها لمتابعتها يومياً")
}

data class DhikrItem(
    val id: String,
    val category: DhikrCategory,
    val text: String,
    val targetCount: Int,
    val reference: String,
    val virtue: String? = null,
    val isCustom: Boolean = false
)

data class AppSettings(
    val userName: String = "ضيف الكريم",
    val isDarkTheme: Boolean = false,
    val useGpsLocation: Boolean = false,
    val selectedCityId: String = "makkah",
    val customLat: Double = 21.4225,
    val customLng: Double = 39.8262,
    val customLocationName: String = "مكة المكرمة",
    val calculationMethod: CalculationMethodKey = CalculationMethodKey.UMM_AL_QURA,
    val madhhab: MadhhabKey = MadhhabKey.SHAFI,
    val notificationsEnabled: Boolean = true,
    val fajrAlert: Boolean = true,
    val dhuhrAlert: Boolean = true,
    val asrAlert: Boolean = true,
    val maghribAlert: Boolean = true,
    val ishaAlert: Boolean = true,
    val prePrayerMinutes: Int = 10,
    val morningAdhkarHour: Int = 6,
    val morningAdhkarMinute: Int = 0,
    val eveningAdhkarHour: Int = 17,
    val eveningAdhkarMinute: Int = 30,
    val morningAdhkarEnabled: Boolean = true,
    val eveningAdhkarEnabled: Boolean = true,
    val adhanTone: ToneId = ToneId.MAKKAH_CHIME,
    val adhkarTone: ToneId = ToneId.MORNING_BREEZE,
    val prePrayerTone: ToneId = ToneId.GENTLE_BELL,
    val volume: Float = 0.75f,
    val autoAdvanceDhikr: Boolean = true,
    val hapticEnabled: Boolean = true
) {
    fun isPrayerAlertEnabled(key: PrayerKey): Boolean = when (key) {
        PrayerKey.FAJR -> fajrAlert
        PrayerKey.DHUHR -> dhuhrAlert
        PrayerKey.ASR -> asrAlert
        PrayerKey.MAGHRIB -> maghribAlert
        PrayerKey.ISHA -> ishaAlert
        PrayerKey.SUNRISE -> false
    }
}

data class PrayerScheduleItem(
    val key: PrayerKey,
    val nameAr: String,
    val timeMillis: Long,
    val formattedTime: String,
    val isNext: Boolean,
    val isCurrent: Boolean
)

data class ComputedPrayerState(
    val schedule: List<PrayerScheduleItem>,
    val nextPrayerKey: PrayerKey,
    val nextPrayerNameAr: String,
    val nextPrayerTimeMillis: Long,
    val nextPrayerFormatted: String,
    val countdownHours: String,
    val countdownMinutes: String,
    val countdownSeconds: String,
    val qiblaAngle: Int,
    val hijriDate: String,
    val gregorianDate: String,
    val locationLabel: String
)

data class TasbihState(
    val phraseIndex: Int = 0,
    val customPhrase: String = "",
    val target: Int = 33,
    val count: Int = 0,
    val lifetimeTotal: Long = 0L
)

data class ActiveAlertBanner(
    val id: String,
    val title: String,
    val message: String,
    val timestamp: String
)

enum class ActiveTab(val labelAr: String) {
    PRAYERS("المواقيت"),
    ADHKAR("الأذكار"),
    TASBIH("المسبحة"),
    SETTINGS("الإعدادات")
}
