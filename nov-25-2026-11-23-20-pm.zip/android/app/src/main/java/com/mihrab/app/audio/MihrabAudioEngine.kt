package com.mihrab.app.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import com.mihrab.app.model.ToneId
import kotlin.concurrent.thread
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

object MihrabAudioEngine {

    private data class NoteSpec(
        val freq: Double,
        val startSec: Double,
        val durationSec: Double,
        val gain: Double = 0.5
    )

    @Volatile
    private var activeTrack: AudioTrack? = null

    fun stop() {
        val track = activeTrack
        activeTrack = null
        try {
            track?.pause()
            track?.flush()
            track?.release()
        } catch (_: Throwable) {
        }
    }

    fun playTone(toneId: ToneId, volume: Float) {
        val clampedVol = volume.coerceIn(0f, 1f)
        if (clampedVol <= 0.01f) return

        val notes = when (toneId) {
            ToneId.MAKKAH_CHIME -> listOf(
                NoteSpec(293.66, 0.0, 1.5, 0.48),
                NoteSpec(311.13, 0.65, 1.4, 0.45),
                NoteSpec(369.99, 1.3, 1.8, 0.52),
                NoteSpec(392.00, 2.2, 1.7, 0.50),
                NoteSpec(440.00, 3.1, 2.2, 0.55),
                NoteSpec(293.66, 3.1, 2.4, 0.35)
            )
            ToneId.FAJR_CALM -> listOf(
                NoteSpec(261.63, 0.0, 1.8, 0.40),
                NoteSpec(392.00, 0.85, 1.8, 0.42),
                NoteSpec(440.00, 1.7, 2.0, 0.45),
                NoteSpec(523.25, 2.6, 2.4, 0.48)
            )
            ToneId.TAKBIR_DEW -> listOf(
                NoteSpec(329.63, 0.0, 1.4, 0.50),
                NoteSpec(493.88, 0.45, 1.8, 0.50),
                NoteSpec(392.00, 1.5, 1.8, 0.48),
                NoteSpec(587.33, 1.95, 2.1, 0.46)
            )
            ToneId.MORNING_BREEZE -> listOf(
                NoteSpec(440.00, 0.0, 1.2, 0.45),
                NoteSpec(554.37, 0.3, 1.2, 0.45),
                NoteSpec(659.25, 0.6, 1.6, 0.48),
                NoteSpec(880.00, 0.95, 2.1, 0.38)
            )
            ToneId.EVENING_CALM -> listOf(
                NoteSpec(220.00, 0.0, 2.0, 0.50),
                NoteSpec(329.63, 0.6, 2.0, 0.42),
                NoteSpec(293.66, 1.5, 2.4, 0.45)
            )
            ToneId.MUSK_BOWL -> listOf(
                NoteSpec(432.00, 0.0, 3.4, 0.55),
                NoteSpec(648.00, 0.05, 2.8, 0.25),
                NoteSpec(432.00, 1.8, 2.8, 0.42)
            )
            ToneId.GENTLE_BELL -> listOf(
                NoteSpec(587.33, 0.0, 1.2, 0.45),
                NoteSpec(783.99, 0.45, 1.6, 0.42)
            )
        }

        playNotesAsync(notes, clampedVol)
    }

    fun playTasbihClick(isTargetReached: Boolean, volume: Float) {
        val clampedVol = volume.coerceIn(0f, 1f)
        if (clampedVol <= 0.01f) return

        val notes = if (isTargetReached) {
            listOf(
                NoteSpec(659.25, 0.0, 0.22, 0.35),
                NoteSpec(880.00, 0.08, 0.42, 0.40)
            )
        } else {
            listOf(NoteSpec(480.0, 0.0, 0.055, 0.25))
        }
        playNotesAsync(notes, clampedVol)
    }

    private fun playNotesAsync(notes: List<NoteSpec>, volume: Float) {
        stop()
        thread(isDaemon = true) {
            try {
                val sampleRate = 22050
                val totalDurationSec = notes.maxOfOrNull { it.startSec + it.durationSec } ?: 1.0
                val totalSamples = (totalDurationSec * sampleRate).toInt().coerceAtLeast(1)
                val buffer = ShortArray(totalSamples)

                for (i in 0 until totalSamples) {
                    val t = i.toDouble() / sampleRate
                    var sampleSum = 0.0
                    for (note in notes) {
                        val localT = t - note.startSec
                        if (localT in 0.0..note.durationSec) {
                            val attack = (localT / 0.04).coerceIn(0.0, 1.0)
                            val decay = exp(-3.5 * localT / note.durationSec)
                            val env = attack * decay
                            val fundamental = sin(2.0 * PI * note.freq * localT)
                            val overtone = 0.18 * sin(2.0 * PI * (note.freq * 2.0) * localT)
                            sampleSum += (fundamental + overtone) * env * note.gain
                        }
                    }
                    val scaled = (sampleSum * volume * 0.55).coerceIn(-0.95, 0.95)
                    buffer[i] = (scaled * Short.MAX_VALUE).toInt().toShort()
                }

                val byteSize = buffer.size * 2
                val track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(byteSize)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()

                track.write(buffer, 0, buffer.size)
                activeTrack = track
                track.play()

                val waitMs = (totalDurationSec * 1000).toLong() + 120L
                Thread.sleep(waitMs)
                if (activeTrack === track) {
                    stop()
                }
            } catch (_: Throwable) {
            }
        }
    }
}
