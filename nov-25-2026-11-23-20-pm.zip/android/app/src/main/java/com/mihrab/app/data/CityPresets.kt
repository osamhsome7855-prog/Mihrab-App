package com.mihrab.app.data

import com.mihrab.app.model.CalculationMethodKey
import com.mihrab.app.model.CityPreset

object CityPresets {
    val list: List<CityPreset> = listOf(
        CityPreset("makkah", "مكة المكرمة", "السعودية", 21.4225, 39.8262, CalculationMethodKey.UMM_AL_QURA),
        CityPreset("madinah", "المدينة المنورة", "السعودية", 24.4672, 39.6111, CalculationMethodKey.UMM_AL_QURA),
        CityPreset("riyadh", "الرياض", "السعودية", 24.7136, 46.6753, CalculationMethodKey.UMM_AL_QURA),
        CityPreset("jeddah", "جدة", "السعودية", 21.4858, 39.1925, CalculationMethodKey.UMM_AL_QURA),
        CityPreset("cairo", "القاهرة", "مصر", 30.0444, 31.2357, CalculationMethodKey.EGYPTIAN),
        CityPreset("alexandria", "الإسكندرية", "مصر", 31.2001, 29.9187, CalculationMethodKey.EGYPTIAN),
        CityPreset("dubai", "دبي", "الإمارات", 25.2048, 55.2708, CalculationMethodKey.DUBAI),
        CityPreset("abudhabi", "أبو ظبي", "الإمارات", 24.4539, 54.3773, CalculationMethodKey.DUBAI),
        CityPreset("doha", "الدوحة", "قطر", 25.2854, 51.5310, CalculationMethodKey.QATAR),
        CityPreset("kuwait", "مدينة الكويت", "الكويت", 29.3759, 47.9774, CalculationMethodKey.KUWAIT),
        CityPreset("amman", "عمّان", "الأردن", 31.9454, 35.9284, CalculationMethodKey.MUSLIM_WORLD_LEAGUE),
        CityPreset("jerusalem", "القدس", "فلسطين", 31.7683, 35.2137, CalculationMethodKey.EGYPTIAN),
        CityPreset("beirut", "بيروت", "لبنان", 33.8938, 35.5018, CalculationMethodKey.EGYPTIAN),
        CityPreset("baghdad", "بغداد", "العراق", 33.3152, 44.3661, CalculationMethodKey.MUSLIM_WORLD_LEAGUE),
        CityPreset("rabat", "الرباط", "المغرب", 34.0209, -6.8416, CalculationMethodKey.MUSLIM_WORLD_LEAGUE),
        CityPreset("tunis", "تونس", "تونس", 36.8065, 10.1815, CalculationMethodKey.MUSLIM_WORLD_LEAGUE),
        CityPreset("istanbul", "إسطنبول", "تركيا", 41.0082, 28.9784, CalculationMethodKey.MUSLIM_WORLD_LEAGUE),
        CityPreset("london", "لندن", "المملكة المتحدة", 51.5074, -0.1278, CalculationMethodKey.MUSLIM_WORLD_LEAGUE),
        CityPreset("newyork", "نيويورك", "الولايات المتحدة", 40.7128, -74.0060, CalculationMethodKey.NORTH_AMERICA)
    )

    fun findById(id: String): CityPreset = list.firstOrNull { it.id == id } ?: list.first()
}
