package com.mihrab.app.ui.screens

import android.app.TimePickerDialog
import android.os.Build
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.ArrowDropDown
import androidx.compose.material.icons.rounded.Explore
import androidx.compose.material.icons.rounded.LocationOn
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mihrab.app.audio.MihrabAudioEngine
import com.mihrab.app.data.CityPresets
import com.mihrab.app.model.AppSettings
import com.mihrab.app.model.CalculationMethodKey
import com.mihrab.app.model.MadhhabKey
import com.mihrab.app.model.PrayerKey
import com.mihrab.app.model.ToneCategory
import com.mihrab.app.model.ToneId
import com.mihrab.app.ui.theme.mihrabPalette
import kotlin.math.roundToInt

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(
    settings: AppSettings,
    gpsMessage: String?,
    hasNotificationPermission: Boolean,
    onRequestLocation: () -> Unit,
    onRequestNotificationPermission: () -> Unit,
    onUpdateSettings: ((AppSettings) -> AppSettings) -> Unit,
    onTogglePrayerAlert: (PrayerKey) -> Unit,
    onTestNotification: () -> Unit,
    onResetDefaults: () -> Unit
) {
    val p = mihrabPalette(settings.isDarkTheme)
    val context = LocalContext.current

    val adhanTones = remember { ToneId.entries.filter { it.category == ToneCategory.ADHAN } }
    val adhkarTones = remember { ToneId.entries.filter { it.category == ToneCategory.ADHKAR } }
    val prePrayerTones = remember {
        ToneId.entries.filter { it.category == ToneCategory.PRE_PRAYER || it.category == ToneCategory.ADHKAR }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(p.canvas),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header + Test Alert CTA
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "لوحة التحكم والإعدادات",
                        style = MaterialTheme.typography.headlineMedium,
                        color = p.ink
                    )
                    Text(
                        text = "الموقع الجغرافي، الحساب الفلكي، النغمات، وجدول التنبيهات",
                        fontSize = 12.sp,
                        color = p.mutedInk
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Button(
                    onClick = onTestNotification,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = p.accentPrimary,
                        contentColor = p.onAccentPrimary
                    ),
                    modifier = Modifier.height(42.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.NotificationsActive,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "اختبار التنبيه", fontSize = 12.sp, maxLines = 1)
                }
            }
        }

        // 1. Profile & Theme
        item {
            SettingsCard(palette = p, title = "الملف الشخصي والمظهر", icon = {
                Icon(Icons.Rounded.Person, contentDescription = null, tint = p.accentGold)
            }) {
                OutlinedTextField(
                    value = settings.userName,
                    onValueChange = { name ->
                        onUpdateSettings { it.copy(userName = name.take(40)) }
                    },
                    label = { Text("الاسم المعروض في الواجهة") },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(12.dp))
                Text(text = "وضع الألوان", fontSize = 12.sp, color = p.mutedInk)
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Surface(
                        onClick = { onUpdateSettings { it.copy(isDarkTheme = false) } },
                        shape = RoundedCornerShape(12.dp),
                        color = if (!settings.isDarkTheme) p.accentPrimary else p.canvas,
                        border = BorderStroke(1.dp, if (!settings.isDarkTheme) p.accentPrimary else p.borderStrong),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = "الوضع النهاري الرملي",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = if (!settings.isDarkTheme) p.onAccentPrimary else p.ink,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 12.dp)
                        )
                    }

                    Surface(
                        onClick = { onUpdateSettings { it.copy(isDarkTheme = true) } },
                        shape = RoundedCornerShape(12.dp),
                        color = if (settings.isDarkTheme) p.accentPrimary else p.canvas,
                        border = BorderStroke(1.dp, if (settings.isDarkTheme) p.accentPrimary else p.borderStrong),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = "الوضع الليلي العميق",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = if (settings.isDarkTheme) p.onAccentPrimary else p.ink,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 12.dp)
                        )
                    }
                }
            }
        }

        // 2. Location & Calculation Method
        item {
            SettingsCard(palette = p, title = "الموقع وحساب المواقيت", icon = {
                Icon(Icons.Rounded.Explore, contentDescription = null, tint = p.accentGold)
            }) {
                OutlinedButton(
                    onClick = onRequestLocation,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, p.borderStrong),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = p.canvas,
                        contentColor = p.ink
                    ),
                    modifier = Modifier.fillMaxWidth().height(44.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.LocationOn,
                        contentDescription = null,
                        tint = p.accentPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "تحديد موقعي الجغرافي تلقائياً (GPS)", fontSize = 13.sp)
                }

                if (!gpsMessage.isNullOrBlank()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = gpsMessage,
                        fontSize = 12.sp,
                        color = p.accentPrimary
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                val selectedCity = CityPresets.findById(settings.selectedCityId)
                val cityLabel = if (settings.useGpsLocation) {
                    settings.customLocationName
                } else {
                    "${selectedCity.nameAr} — ${selectedCity.countryAr}"
                }

                DropdownSelector(
                    label = "المدينة المختارة",
                    selectedText = cityLabel,
                    palette = p
                ) { onDismiss ->
                    CityPresets.list.forEach { city ->
                        DropdownMenuItem(
                            text = { Text("${city.nameAr} — ${city.countryAr}") },
                            onClick = {
                                onUpdateSettings {
                                    it.copy(
                                        useGpsLocation = false,
                                        selectedCityId = city.id,
                                        calculationMethod = city.method
                                    )
                                }
                                onDismiss()
                            }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                DropdownSelector(
                    label = "طريقة الحساب الفلكي",
                    selectedText = settings.calculationMethod.labelAr,
                    palette = p
                ) { onDismiss ->
                    CalculationMethodKey.entries.forEach { method ->
                        DropdownMenuItem(
                            text = { Text(method.labelAr) },
                            onClick = {
                                onUpdateSettings { it.copy(calculationMethod = method) }
                                onDismiss()
                            }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                DropdownSelector(
                    label = "المذهب الفقهي (وقت العصر)",
                    selectedText = settings.madhhab.labelAr,
                    palette = p
                ) { onDismiss ->
                    MadhhabKey.entries.forEach { madhhab ->
                        DropdownMenuItem(
                            text = { Text(madhhab.labelAr) },
                            onClick = {
                                onUpdateSettings { it.copy(madhhab = madhhab) }
                                onDismiss()
                            }
                        )
                    }
                }
            }
        }

        // 3. Audio & Custom Tones
        item {
            SettingsCard(palette = p, title = "تخصيص النغمات الصوتية", icon = {
                Icon(Icons.AutoMirrored.Rounded.VolumeUp, contentDescription = null, tint = p.accentGold)
            }) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "مستوى الصوت العام", fontSize = 12.sp, color = p.mutedInk)
                    Text(
                        text = "${(settings.volume * 100).roundToInt()}%",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = p.ink
                    )
                }
                Slider(
                    value = settings.volume,
                    onValueChange = { vol -> onUpdateSettings { it.copy(volume = vol) } },
                    colors = SliderDefaults.colors(
                        thumbColor = p.accentPrimary,
                        activeTrackColor = p.accentPrimary
                    )
                )

                Spacer(modifier = Modifier.height(8.dp))

                ToneSelectorRow(
                    label = "نغمة الأذان (دخول وقت الصلاة)",
                    selectedTone = settings.adhanTone,
                    options = adhanTones,
                    palette = p,
                    onSelect = { tone -> onUpdateSettings { it.copy(adhanTone = tone) } },
                    onPreview = { MihrabAudioEngine.playTone(settings.adhanTone, settings.volume) }
                )

                Spacer(modifier = Modifier.height(12.dp))

                ToneSelectorRow(
                    label = "نغمة تذكير الأذكار (الصباح والمساء)",
                    selectedTone = settings.adhkarTone,
                    options = adhkarTones,
                    palette = p,
                    onSelect = { tone -> onUpdateSettings { it.copy(adhkarTone = tone) } },
                    onPreview = { MihrabAudioEngine.playTone(settings.adhkarTone, settings.volume) }
                )

                Spacer(modifier = Modifier.height(12.dp))

                ToneSelectorRow(
                    label = "نغمة التنبيه قبل الصلاة",
                    selectedTone = settings.prePrayerTone,
                    options = prePrayerTones,
                    palette = p,
                    onSelect = { tone -> onUpdateSettings { it.copy(prePrayerTone = tone) } },
                    onPreview = { MihrabAudioEngine.playTone(settings.prePrayerTone, settings.volume) }
                )
            }
        }

        // 4. Notifications Schedule
        item {
            SettingsCard(palette = p, title = "إدارة التنبيهات والأذكار", icon = {
                Icon(Icons.Rounded.NotificationsActive, contentDescription = null, tint = p.accentGold)
            }) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !hasNotificationPermission) {
                    OutlinedButton(
                        onClick = onRequestNotificationPermission,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, p.accentPrimary),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "منح صلاحية الإشعارات للنظام",
                            fontSize = 12.sp,
                            color = p.accentPrimary
                        )
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                }

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = p.canvas,
                    border = BorderStroke(1.dp, p.borderStrong),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "تفعيل نظام التنبيهات العام",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium,
                            color = p.ink
                        )
                        Switch(
                            checked = settings.notificationsEnabled,
                            onCheckedChange = { enabled ->
                                onUpdateSettings { it.copy(notificationsEnabled = enabled) }
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = p.onAccentPrimary,
                                checkedTrackColor = p.accentPrimary
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))
                Text(text = "تنبيهات الصلوات الخمس", fontSize = 12.sp, color = p.mutedInk)
                Spacer(modifier = Modifier.height(8.dp))

                val prayers = listOf(
                    PrayerKey.FAJR,
                    PrayerKey.DHUHR,
                    PrayerKey.ASR,
                    PrayerKey.MAGHRIB,
                    PrayerKey.ISHA
                )

                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    prayers.forEach { key ->
                        val enabled = settings.isPrayerAlertEnabled(key)
                        Surface(
                            onClick = { onTogglePrayerAlert(key) },
                            shape = RoundedCornerShape(10.dp),
                            color = if (enabled) p.accentPrimary else p.canvas,
                            border = BorderStroke(1.dp, if (enabled) p.accentPrimary else p.borderStrong)
                        ) {
                            Text(
                                text = key.labelAr,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                color = if (enabled) p.onAccentPrimary else p.mutedInk,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                val preOptions = listOf(
                    0 to "إيقاف التنبيه المسبق",
                    10 to "قبل الأذان بـ ١٠ دقائق",
                    15 to "قبل الأذان بـ ١٥ دقيقة",
                    20 to "قبل الأذان بـ ٢٠ دقيقة"
                )
                val currentPreLabel = preOptions.firstOrNull { it.first == settings.prePrayerMinutes }?.second
                    ?: "قبل الأذان بـ ١٠ دقائق"

                DropdownSelector(
                    label = "التنبيه الاستباقي قبل الصلاة",
                    selectedText = currentPreLabel,
                    palette = p
                ) { onDismiss ->
                    preOptions.forEach { (mins, label) ->
                        DropdownMenuItem(
                            text = { Text(label) },
                            onClick = {
                                onUpdateSettings { it.copy(prePrayerMinutes = mins) }
                                onDismiss()
                            }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    AdhkarTimeCard(
                        title = "تذكير أذكار الصباح",
                        enabled = settings.morningAdhkarEnabled,
                        hour = settings.morningAdhkarHour,
                        minute = settings.morningAdhkarMinute,
                        palette = p,
                        modifier = Modifier.weight(1f),
                        onToggle = { enabled ->
                            onUpdateSettings { it.copy(morningAdhkarEnabled = enabled) }
                        },
                        onPickTime = {
                            TimePickerDialog(
                                context,
                                { _, h, m ->
                                    onUpdateSettings {
                                        it.copy(morningAdhkarHour = h, morningAdhkarMinute = m)
                                    }
                                },
                                settings.morningAdhkarHour,
                                settings.morningAdhkarMinute,
                                false
                            ).show()
                        }
                    )

                    AdhkarTimeCard(
                        title = "تذكير أذكار المساء",
                        enabled = settings.eveningAdhkarEnabled,
                        hour = settings.eveningAdhkarHour,
                        minute = settings.eveningAdhkarMinute,
                        palette = p,
                        modifier = Modifier.weight(1f),
                        onToggle = { enabled ->
                            onUpdateSettings { it.copy(eveningAdhkarEnabled = enabled) }
                        },
                        onPickTime = {
                            TimePickerDialog(
                                context,
                                { _, h, m ->
                                    onUpdateSettings {
                                        it.copy(eveningAdhkarHour = h, eveningAdhkarMinute = m)
                                    }
                                },
                                settings.eveningAdhkarHour,
                                settings.eveningAdhkarMinute,
                                false
                            ).show()
                        }
                    )
                }
            }
        }

        // Footer Reset
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                HorizontalDivider(color = p.border)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "يعمل التطبيق محلياً دون إنترنت.",
                        fontSize = 12.sp,
                        color = p.mutedInk
                    )
                    OutlinedButton(
                        onClick = onResetDefaults,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, p.borderStrong)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Refresh,
                            contentDescription = null,
                            tint = p.mutedInk,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "استعادة الافتراضي",
                            fontSize = 12.sp,
                            color = p.mutedInk
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsCard(
    palette: com.mihrab.app.ui.theme.MihrabPalette,
    title: String,
    icon: @Composable () -> Unit,
    content: @Composable () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = palette.surface,
        border = BorderStroke(1.dp, palette.border),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                icon()
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleLarge,
                    color = palette.ink
                )
            }
            Spacer(modifier = Modifier.height(14.dp))
            content()
        }
    }
}

@Composable
private fun DropdownSelector(
    label: String,
    selectedText: String,
    palette: com.mihrab.app.ui.theme.MihrabPalette,
    menuContent: @Composable (onDismiss: () -> Unit) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    Column {
        Text(text = label, fontSize = 12.sp, color = palette.mutedInk)
        Spacer(modifier = Modifier.height(6.dp))
        Box(modifier = Modifier.fillMaxWidth()) {
            Surface(
                onClick = { expanded = true },
                shape = RoundedCornerShape(12.dp),
                color = palette.canvas,
                border = BorderStroke(1.dp, palette.borderStrong),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = selectedText,
                        fontSize = 13.sp,
                        color = palette.ink,
                        modifier = Modifier.weight(1f)
                    )
                    Icon(
                        imageVector = Icons.Rounded.ArrowDropDown,
                        contentDescription = null,
                        tint = palette.mutedInk
                    )
                }
            }

            DropdownMenu(
                expanded = expanded,
                onDismissRequest = { expanded = false }
            ) {
                menuContent { expanded = false }
            }
        }
    }
}

@Composable
private fun ToneSelectorRow(
    label: String,
    selectedTone: ToneId,
    options: List<ToneId>,
    palette: com.mihrab.app.ui.theme.MihrabPalette,
    onSelect: (ToneId) -> Unit,
    onPreview: () -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    Column {
        Text(text = label, fontSize = 12.sp, color = palette.mutedInk)
        Spacer(modifier = Modifier.height(6.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(modifier = Modifier.weight(1f)) {
                Surface(
                    onClick = { expanded = true },
                    shape = RoundedCornerShape(12.dp),
                    color = palette.canvas,
                    border = BorderStroke(1.dp, palette.borderStrong),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${selectedTone.nameAr} (${selectedTone.durationLabel})",
                            fontSize = 12.sp,
                            color = palette.ink,
                            modifier = Modifier.weight(1f)
                        )
                        Icon(
                            imageVector = Icons.Rounded.ArrowDropDown,
                            contentDescription = null,
                            tint = palette.mutedInk
                        )
                    }
                }
                DropdownMenu(
                    expanded = expanded,
                    onDismissRequest = { expanded = false }
                ) {
                    options.forEach { tone ->
                        DropdownMenuItem(
                            text = { Text("${tone.nameAr} (${tone.durationLabel})") },
                            onClick = {
                                onSelect(tone)
                                expanded = false
                            }
                        )
                    }
                }
            }

            OutlinedButton(
                onClick = onPreview,
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, palette.borderStrong),
                colors = ButtonDefaults.outlinedButtonColors(
                    containerColor = palette.canvas,
                    contentColor = palette.accentPrimary
                ),
                modifier = Modifier.height(44.dp)
            ) {
                Icon(
                    imageVector = Icons.Rounded.PlayArrow,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(text = "معاينة", fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun AdhkarTimeCard(
    title: String,
    enabled: Boolean,
    hour: Int,
    minute: Int,
    palette: com.mihrab.app.ui.theme.MihrabPalette,
    modifier: Modifier = Modifier,
    onToggle: (Boolean) -> Unit,
    onPickTime: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = palette.canvas,
        border = BorderStroke(1.dp, palette.borderStrong),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    color = palette.ink,
                    modifier = Modifier.weight(1f)
                )
                Checkbox(
                    checked = enabled,
                    onCheckedChange = onToggle,
                    colors = CheckboxDefaults.colors(checkedColor = palette.accentPrimary)
                )
            }
            OutlinedButton(
                onClick = onPickTime,
                enabled = enabled,
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, palette.border),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = String.format("%02d:%02d", hour, minute),
                    fontSize = 13.sp,
                    color = if (enabled) palette.ink else palette.mutedInk
                )
            }
        }
    }
}
