package com.mihrab.app.notifications

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.mihrab.app.data.PreferencesRepository

class BootCompletedReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        if (
            action == Intent.ACTION_BOOT_COMPLETED ||
            action == Intent.ACTION_TIME_CHANGED ||
            action == Intent.ACTION_TIMEZONE_CHANGED
        ) {
            val repo = PreferencesRepository(context)
            PrayerAlarmScheduler.rescheduleAll(context, repo.loadSettings())
        }
    }
}
