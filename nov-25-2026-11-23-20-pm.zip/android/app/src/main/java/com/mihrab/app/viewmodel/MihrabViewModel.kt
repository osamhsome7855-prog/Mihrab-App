package com.mihrab.app.viewmodel

import android.app.Application
import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mihrab.app.audio.MihrabAudioEngine
import com.mihrab.app.data.AdhkarData
import com.mihrab.app.data.PreferencesRepository
import com.mihrab.app.domain.AstronomicalPrayerCalculator
import com.mihrab.app.location.LocationHelper
import com.mihrab.app.model.ActiveAlertBanner
import com.mihrab.app.model.ActiveTab
import com.mihrab.app.model.AppSettings
import com.mihrab.app.model.ComputedPrayerState
import com.mihrab.app.model.DhikrCategory
import com.mihrab.app.model.DhikrItem
import com.mihrab.app.model.PrayerKey
import com.mihrab.app.model.TasbihState
import com.mihrab.app.notifications.PrayerAlarmScheduler
import com.mihrab.app.sensors.QiblaCompassManager
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class MihrabViewModel(application: Application) : AndroidViewModel(application) {

    private val repo = PreferencesRepository(application)
    private val compassManager = QiblaCompassManager(application)

    private val _activeTab = MutableStateFlow(ActiveTab.PRAYERS)
    val activeTab: StateFlow<ActiveTab> = _activeTab.asStateFlow()

    private val _settings = MutableStateFlow(repo.loadSettings())
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    private val _prayerState = MutableStateFlow(
        AstronomicalPrayerCalculator.computeState(_settings.value)
    )
    val prayerState: StateFlow<ComputedPrayerState> = _prayerState.asStateFlow()

    private val _dhikrCounts = MutableStateFlow(repo.loadDailyDhikrCounts())
    val dhikrCounts: StateFlow<Map<String, Int>> = _dhikrCounts.asStateFlow()

    private val _customAdhkar = MutableStateFlow(repo.loadCustomAdhkar())
    val customAdhkar: StateFlow<List<DhikrItem>> = _customAdhkar.asStateFlow()

    private val _tasbihState = MutableStateFlow(repo.loadTasbihState())
    val tasbihState: StateFlow<TasbihState> = _tasbihState.asStateFlow()

    private val _activeAlert = MutableStateFlow<ActiveAlertBanner?>(null)
    val activeAlert: StateFlow<ActiveAlertBanner?> = _activeAlert.asStateFlow()

    private val _gpsMessage = MutableStateFlow<String?>(null)
    val gpsMessage: StateFlow<String?> = _gpsMessage.asStateFlow()

    val compassAzimuth: StateFlow<Float> = compassManager.azimuthDegrees
    val hasCompassSensor: StateFlow<Boolean> = compassManager.hasCompassSensor

    init {
        PrayerAlarmScheduler.rescheduleAll(application, _settings.value)

        viewModelScope.launch {
            while (true) {
                _prayerState.value = AstronomicalPrayerCalculator.computeState(
                    _settings.value,
                    System.currentTimeMillis()
                )
                delay(1000L)
            }
        }
    }

    fun startCompass() {
        compassManager.start()
    }

    fun stopCompass() {
        compassManager.stop()
    }

    fun setActiveTab(tab: ActiveTab) {
        _activeTab.value = tab
    }

    fun updateSettings(transform: (AppSettings) -> AppSettings) {
        val updated = transform(_settings.value)
        _settings.value = updated
        repo.saveSettings(updated)
        _prayerState.value = AstronomicalPrayerCalculator.computeState(updated)
        PrayerAlarmScheduler.rescheduleAll(getApplication(), updated)
    }

    fun toggleTheme() {
        updateSettings { it.copy(isDarkTheme = !it.isDarkTheme) }
    }

    fun togglePrayerAlert(key: PrayerKey) {
        updateSettings { s ->
            when (key) {
                PrayerKey.FAJR -> s.copy(fajrAlert = !s.fajrAlert)
                PrayerKey.DHUHR -> s.copy(dhuhrAlert = !s.dhuhrAlert)
                PrayerKey.ASR -> s.copy(asrAlert = !s.asrAlert)
                PrayerKey.MAGHRIB -> s.copy(maghribAlert = !s.maghribAlert)
                PrayerKey.ISHA -> s.copy(ishaAlert = !s.ishaAlert)
                PrayerKey.SUNRISE -> s
            }
        }
    }

    fun fetchGpsLocation() {
        _gpsMessage.value = "جارٍ تحديد الإحداثيات..."
        LocationHelper.fetchCurrentCoordinates(
            context = getApplication(),
            onSuccess = { lat, lng, label ->
                updateSettings {
                    it.copy(
                        useGpsLocation = true,
                        customLat = lat,
                        customLng = lng,
                        customLocationName = label
                    )
                }
                _gpsMessage.value = "تم تحديث الإحداثيات بنجاح وحساب المواقيت بدقة."
            },
            onError = { err ->
                _gpsMessage.value = err
            }
        )
    }

    fun incrementDhikr(item: DhikrItem) {
        val current = _dhikrCounts.value[item.id] ?: 0
        if (current >= item.targetCount) return
        val next = (current + 1).coerceAtMost(item.targetCount)
        val reached = next == item.targetCount

        MihrabAudioEngine.playTasbihClick(reached, _settings.value.volume)
        if (_settings.value.hapticEnabled) {
            triggerHaptic(if (reached) 35L else 14L)
        }

        val updatedMap = _dhikrCounts.value.toMutableMap().apply {
            put(item.id, next)
        }
        _dhikrCounts.value = updatedMap
        repo.saveDailyDhikrCounts(updatedMap)
    }

    fun resetDhikrCategory(ids: List<String>) {
        val updatedMap = _dhikrCounts.value.toMutableMap().apply {
            ids.forEach { remove(it) }
        }
        _dhikrCounts.value = updatedMap
        repo.saveDailyDhikrCounts(updatedMap)
    }

    fun addCustomDhikr(text: String, targetCount: Int, virtue: String) {
        val trimmed = text.trim()
        if (trimmed.isEmpty()) return
        val newItem = DhikrItem(
            id = "custom-${System.currentTimeMillis()}",
            category = DhikrCategory.CUSTOM,
            text = trimmed,
            targetCount = targetCount.coerceIn(1, 999),
            reference = "ذكر خاص",
            virtue = virtue.trim().ifBlank { null },
            isCustom = true
        )
        val updated = listOf(newItem) + _customAdhkar.value
        _customAdhkar.value = updated
        repo.saveCustomAdhkar(updated)
    }

    fun deleteCustomDhikr(id: String) {
        val updated = _customAdhkar.value.filterNot { it.id == id }
        _customAdhkar.value = updated
        repo.saveCustomAdhkar(updated)
    }

    fun tapTasbih() {
        _tasbihState.update { prev ->
            val hasTarget = prev.target > 0
            val nextCount = if (hasTarget && prev.count >= prev.target) 1 else prev.count + 1
            val reached = hasTarget && nextCount == prev.target

            MihrabAudioEngine.playTasbihClick(reached, _settings.value.volume)
            if (_settings.value.hapticEnabled) {
                triggerHaptic(if (reached) 40L else 12L)
            }

            val updated = prev.copy(
                count = nextCount,
                lifetimeTotal = prev.lifetimeTotal + 1L
            )
            repo.saveTasbihState(updated)
            updated
        }
    }

    fun updateTasbihConfig(transform: (TasbihState) -> TasbihState) {
        val updated = transform(_tasbihState.value)
        _tasbihState.value = updated
        repo.saveTasbihState(updated)
    }

    fun toggleVolumeMute() {
        updateSettings {
            it.copy(volume = if (it.volume > 0f) 0f else 0.75f)
        }
    }

    fun testNotificationNow() {
        val currentSettings = _settings.value
        MihrabAudioEngine.playTone(currentSettings.adhanTone, currentSettings.volume)
        _activeAlert.value = ActiveAlertBanner(
            id = "test-${System.currentTimeMillis()}",
            title = "تجربة تنبيه مِحراب",
            message = "نغمة التنبيه المخصصة تعمل بنجاح وبجودة صوت نقية.",
            timestamp = AstronomicalPrayerCalculator.formatTimeArabic(System.currentTimeMillis())
        )
    }

    fun dismissAlert() {
        _activeAlert.value = null
    }

    fun resetDefaults() {
        updateSettings { AppSettings() }
    }

    fun totalAdhkarCount(): Int = AdhkarData.builtInAdhkar.size + _customAdhkar.value.size

    fun completedAdhkarCount(): Int {
        val all = AdhkarData.builtInAdhkar + _customAdhkar.value
        val counts = _dhikrCounts.value
        return all.count { (counts[it.id] ?: 0) >= it.targetCount }
    }

    @Suppress("DEPRECATION")
    private fun triggerHaptic(durationMs: Long) {
        val ctx = getApplication<Application>()
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = ctx.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                vm.defaultVibrator.vibrate(
                    VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE)
                )
            } else {
                val vibrator = ctx.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator.vibrate(
                        VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE)
                    )
                } else {
                    vibrator.vibrate(durationMs)
                }
            }
        } catch (_: Throwable) {
        }
    }

    override fun onCleared() {
        super.onCleared()
        compassManager.stop()
        MihrabAudioEngine.stop()
    }
}
