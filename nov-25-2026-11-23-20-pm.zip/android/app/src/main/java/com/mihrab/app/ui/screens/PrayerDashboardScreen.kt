package com.mihrab.app.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.LocationOn
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.NotificationsOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mihrab.app.R
import com.mihrab.app.audio.MihrabAudioEngine
import com.mihrab.app.model.ActiveTab
import com.mihrab.app.model.AppSettings
import com.mihrab.app.model.ComputedPrayerState
import com.mihrab.app.model.PrayerKey
import com.mihrab.app.ui.theme.mihrabPalette
import kotlin.math.abs

@Composable
fun PrayerDashboardScreen(
    prayerState: ComputedPrayerState,
    settings: AppSettings,
    compassAzimuth: Float,
    hasCompassSensor: Boolean,
    adhkarCompletedCount: Int,
    adhkarTotalCount: Int,
    onTogglePrayerAlert: (PrayerKey) -> Unit,
    onNavigate: (ActiveTab) -> Unit
) {
    val p = mihrabPalette(settings.isDarkTheme)

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(p.canvas),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        // 1. Hero Focal Card: Next Prayer & Live Countdown
        item {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = p.surface,
                border = BorderStroke(1.dp, p.border),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "مرحباً، ${settings.userName.ifBlank { "ضيف الكريم" }} · ${prayerState.hijriDate} · ${prayerState.gregorianDate}",
                        style = MaterialTheme.typography.labelMedium,
                        color = p.mutedInk
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "الصلاة القادمة",
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                        color = p.accentPrimary
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        Text(
                            text = prayerState.nextPrayerNameAr,
                            style = MaterialTheme.typography.displayLarge,
                            color = p.ink
                        )
                        Text(
                            text = prayerState.nextPrayerFormatted,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = p.accentGold
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    HorizontalDivider(color = p.border)
                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "الوقت المتبقي على الأذان",
                        style = MaterialTheme.typography.labelMedium,
                        color = p.mutedInk
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = prayerState.countdownHours,
                                fontSize = 38.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                color = p.ink
                            )
                            Text(
                                text = " : ",
                                fontSize = 32.sp,
                                fontWeight = FontWeight.Bold,
                                color = p.accentGold
                            )
                            Text(
                                text = prayerState.countdownMinutes,
                                fontSize = 38.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                color = p.ink
                            )
                            Text(
                                text = " : ",
                                fontSize = 32.sp,
                                fontWeight = FontWeight.Bold,
                                color = p.accentGold
                            )
                            Text(
                                text = prayerState.countdownSeconds,
                                fontSize = 38.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                color = p.accentPrimary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    TextButton(
                        onClick = { onNavigate(ActiveTab.SETTINGS) },
                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.LocationOn,
                            contentDescription = null,
                            tint = p.accentGold,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = prayerState.locationLabel,
                            style = MaterialTheme.typography.bodyMedium,
                            color = p.mutedInk
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                MihrabAudioEngine.playTone(settings.adhanTone, settings.volume)
                            },
                            shape = RoundedCornerShape(14.dp),
                            border = BorderStroke(1.dp, p.borderStrong),
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = p.canvas,
                                contentColor = p.ink
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .height(46.dp)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.VolumeUp,
                                contentDescription = null,
                                tint = p.accentPrimary,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = "نغمة الأذان", fontSize = 13.sp, maxLines = 1)
                        }

                        Button(
                            onClick = { onNavigate(ActiveTab.ADHKAR) },
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = p.accentPrimary,
                                contentColor = p.onAccentPrimary
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .height(46.dp)
                        ) {
                            Text(text = "أذكار اليوم", fontSize = 13.sp, maxLines = 1)
                            Spacer(modifier = Modifier.width(6.dp))
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.ArrowForward,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }

        // 2. Architectural Sanctuary Image Card
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(190.dp)
                    .clip(RoundedCornerShape(20.dp))
            ) {
                Image(
                    painter = painterResource(id = R.drawable.hero_mihrab_arch),
                    contentDescription = "فناء معماري إسلامي هادئ وقت الغروب",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    Color.Transparent,
                                    Color(0xFF081120).copy(alpha = 0.85f)
                                )
                            )
                        )
                )
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(18.dp)
                ) {
                    Text(
                        text = "حديث شريف",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFFE5CFA3)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "«أَحَبُّ الأَعْمَالِ إِلَى اللَّهِ الصَّلاَةُ عَلَى وَقْتِهَا»",
                        style = MaterialTheme.typography.titleLarge,
                        color = Color(0xFFFAF7F2)
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "متفق عليه",
                        fontSize = 11.sp,
                        color = Color(0xFFD5DCE6)
                    )
                }
            }
        }

        // 3. Daily Prayer Schedule (2-column grid of 6 prayers)
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom
                ) {
                    Text(
                        text = "مواقيت الصلوات اليوم",
                        style = MaterialTheme.typography.headlineMedium,
                        color = p.ink
                    )
                    Text(
                        text = "انقر على الجرس للتخصيص",
                        style = MaterialTheme.typography.labelMedium,
                        color = p.mutedInk
                    )
                }

                val rows = prayerState.schedule.chunked(2)
                rows.forEach { pair ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        pair.forEach { item ->
                            val isNext = item.isNext
                            val cardBg = if (isNext) {
                                if (p.isDark) Color(0xFF132542) else p.accentPrimary
                            } else {
                                p.surface
                            }
                            val cardText = if (isNext && !p.isDark) Color(0xFFFAF7F2) else p.ink
                            val subText = if (isNext) {
                                if (p.isDark) p.accentGold else Color(0xFFD6EAE3)
                            } else if (item.isCurrent) {
                                p.accentPrimary
                            } else {
                                p.mutedInk
                            }
                            val borderColor = if (isNext) p.accentPrimary else p.border
                            val alertEnabled = settings.notificationsEnabled &&
                                settings.isPrayerAlertEnabled(item.key)

                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = cardBg,
                                border = BorderStroke(1.dp, borderColor),
                                modifier = Modifier.weight(1f)
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = item.nameAr,
                                            fontWeight = FontWeight.SemiBold,
                                            fontSize = 15.sp,
                                            color = if (isNext && p.isDark) p.accentGold else cardText
                                        )

                                        if (item.key.isAlertable) {
                                            IconButton(
                                                onClick = { onTogglePrayerAlert(item.key) },
                                                modifier = Modifier.size(36.dp)
                                            ) {
                                                Icon(
                                                    imageVector = if (alertEnabled) {
                                                        Icons.Rounded.NotificationsActive
                                                    } else {
                                                        Icons.Rounded.NotificationsOff
                                                    },
                                                    contentDescription = "تبديل تنبيه ${item.nameAr}",
                                                    tint = if (isNext) {
                                                        Color(0xFFE5CFA3)
                                                    } else if (alertEnabled) {
                                                        p.accentPrimary
                                                    } else {
                                                        p.mutedInk.copy(alpha = 0.55f)
                                                    },
                                                    modifier = Modifier.size(18.dp)
                                                )
                                            }
                                        } else {
                                            Text(
                                                text = "شروق",
                                                fontSize = 11.sp,
                                                color = subText
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(10.dp))

                                    Text(
                                        text = item.formattedTime,
                                        fontSize = 19.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = cardText
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = when {
                                            item.isNext -> "الصلاة القادمة"
                                            item.isCurrent -> "الوقت الحالي"
                                            else -> "—"
                                        },
                                        fontSize = 11.sp,
                                        color = subText
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // 4. Live Sensor-Driven Qibla Compass Card
        item {
            val targetRotation = if (hasCompassSensor) {
                (prayerState.qiblaAngle - compassAzimuth + 360f) % 360f
            } else {
                prayerState.qiblaAngle.toFloat()
            }
            val animatedRotation by animateFloatAsState(
                targetValue = targetRotation,
                animationSpec = tween(durationMillis = 220),
                label = "qibla_needle_rotation"
            )
            val diff = abs(((prayerState.qiblaAngle - compassAzimuth + 540f) % 360f) - 180f)
            val isAligned = hasCompassSensor && diff <= 6f

            Surface(
                shape = RoundedCornerShape(20.dp),
                color = p.surface,
                border = BorderStroke(
                    width = 1.dp,
                    color = if (isAligned) p.accentPrimary else p.border
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "اتجاه القبلة المشرفة",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = p.accentGold
                        )
                        Text(
                            text = "${prayerState.qiblaAngle}° من الشمال الحقيقي",
                            style = MaterialTheme.typography.titleLarge,
                            color = p.ink
                        )
                        Text(
                            text = when {
                                isAligned -> "أنت تواجه اتجاه القبلة الآن بدقة."
                                hasCompassSensor -> "حرّك الهاتف أفقياً ليتطابق السهم الأخضر/الذهبي مع اتجاه القبلة."
                                else -> "محسوب بدقة فلكية لـ ${prayerState.locationLabel}."
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (isAligned) p.accentPrimary else p.mutedInk
                        )
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    // Compass Dial
                    Box(
                        modifier = Modifier
                            .size(108.dp)
                            .clip(CircleShape)
                            .background(p.canvas),
                        contentAlignment = Alignment.Center
                    ) {
                        val dialBorder = p.borderStrong
                        val primaryArrowColor = p.accentPrimary
                        val goldColor = p.accentGold
                        val mutedTail = p.mutedInk.copy(alpha = 0.35f)

                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val r = size.minDimension / 2f
                            drawCircle(
                                color = dialBorder,
                                radius = r - 2.dp.toPx(),
                                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.5.dp.toPx())
                            )

                            rotate(degrees = animatedRotation) {
                                val cx = center.x
                                val cy = center.y
                                val needlePath = Path().apply {
                                    moveTo(cx, cy - r * 0.72f)
                                    lineTo(cx + 9.dp.toPx(), cy)
                                    lineTo(cx, cy - 5.dp.toPx())
                                    lineTo(cx - 9.dp.toPx(), cy)
                                    close()
                                }
                                drawPath(needlePath, color = primaryArrowColor)

                                val tailPath = Path().apply {
                                    moveTo(cx, cy + r * 0.65f)
                                    lineTo(cx + 6.dp.toPx(), cy)
                                    lineTo(cx, cy + 5.dp.toPx())
                                    lineTo(cx - 6.dp.toPx(), cy)
                                    close()
                                }
                                drawPath(tailPath, color = mutedTail)
                            }
                            drawCircle(
                                color = goldColor,
                                radius = 5.dp.toPx(),
                                center = Offset(center.x, center.y)
                            )
                        }
                    }
                }
            }
        }

        // 5. Daily Adhkar Progress Card
        item {
            val progressFraction = if (adhkarTotalCount > 0) {
                (adhkarCompletedCount.toFloat() / adhkarTotalCount.toFloat()).coerceIn(0f, 1f)
            } else {
                0f
            }

            Surface(
                shape = RoundedCornerShape(20.dp),
                color = p.surface,
                border = BorderStroke(1.dp, p.border),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "ورد الأذكار اليومي",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                color = p.accentPrimary
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "أتممت $adhkarCompletedCount من $adhkarTotalCount ذكر اليوم",
                                style = MaterialTheme.typography.titleLarge,
                                color = p.ink
                            )
                        }

                        OutlinedButton(
                            onClick = { onNavigate(ActiveTab.TASBIH) },
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, p.borderStrong),
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = p.canvas,
                                contentColor = p.ink
                            )
                        ) {
                            Text(text = "المسبحة", fontSize = 12.sp)
                        }
                    }

                    LinearProgressIndicator(
                        progress = { progressFraction },
                        color = p.accentPrimary,
                        trackColor = p.border,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(7.dp)
                            .clip(RoundedCornerShape(4.dp))
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val morningLabel = if (settings.morningAdhkarEnabled) {
                            String.format("%02d:%02d", settings.morningAdhkarHour, settings.morningAdhkarMinute)
                        } else {
                            "متوقف"
                        }
                        val eveningLabel = if (settings.eveningAdhkarEnabled) {
                            String.format("%02d:%02d", settings.eveningAdhkarHour, settings.eveningAdhkarMinute)
                        } else {
                            "متوقف"
                        }
                        Text(
                            text = "الصباح: $morningLabel · المساء: $eveningLabel",
                            fontSize = 12.sp,
                            color = p.mutedInk
                        )
                        TextButton(onClick = { onNavigate(ActiveTab.ADHKAR) }) {
                            Text(
                                text = "متابعة القراءة",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = p.accentPrimary
                            )
                        }
                    }
                }
            }
        }
    }
}
