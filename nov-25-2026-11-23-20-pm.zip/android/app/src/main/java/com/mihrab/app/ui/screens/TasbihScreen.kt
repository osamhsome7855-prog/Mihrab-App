package com.mihrab.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.VolumeOff
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mihrab.app.model.AppSettings
import com.mihrab.app.model.TasbihState
import com.mihrab.app.ui.theme.mihrabPalette

private val PRESET_PHRASES = listOf(
    "سُبْحَانَ اللَّهِ",
    "الْحَمْدُ لِلَّهِ",
    "اللَّهُ أَكْبَرُ",
    "لَا إِلَهَ إِلَّا اللَّهُ",
    "أَسْتَغْفِرُ اللَّهَ الْعَظِيمَ",
    "اللَّهُمَّ صَلِّ وَسَلِّمْ عَلَى نَبِيِّنَا مُحَمَّدٍ"
)

private val TARGET_OPTIONS = listOf(
    33 to "٣٣",
    99 to "٩٩",
    100 to "١٠٠",
    0 to "مفتوح"
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TasbihScreen(
    tasbih: TasbihState,
    settings: AppSettings,
    onTapTasbih: () -> Unit,
    onUpdateTasbih: ((TasbihState) -> TasbihState) -> Unit,
    onToggleVolumeMute: () -> Unit
) {
    val p = mihrabPalette(settings.isDarkTheme)
    val activePhrase = if (tasbih.phraseIndex == -1 && tasbih.customPhrase.isNotBlank()) {
        tasbih.customPhrase
    } else {
        PRESET_PHRASES.getOrElse(tasbih.phraseIndex) { PRESET_PHRASES.first() }
    }

    val hasTarget = tasbih.target > 0
    val progress = if (hasTarget) (tasbih.count.toFloat() / tasbih.target.toFloat()).coerceIn(0f, 1f) else 0f

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(p.canvas),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = p.surface,
                border = BorderStroke(1.dp, p.border),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "المسبحة الإلكترونية",
                                style = MaterialTheme.typography.headlineMedium,
                                color = p.ink
                            )
                            Text(
                                text = "اختر الذكر والهدف العددي ثم انقر على الدائرة",
                                fontSize = 12.sp,
                                color = p.mutedInk
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "الإجمالي",
                                fontSize = 11.sp,
                                color = p.mutedInk
                            )
                            Text(
                                text = tasbih.lifetimeTotal.toString(),
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                color = p.accentPrimary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        PRESET_PHRASES.forEachIndexed { idx, phrase ->
                            val selected = tasbih.phraseIndex == idx
                            Surface(
                                onClick = {
                                    onUpdateTasbih {
                                        it.copy(phraseIndex = idx, count = 0)
                                    }
                                },
                                shape = RoundedCornerShape(12.dp),
                                color = if (selected) p.accentPrimary else p.canvas,
                                border = BorderStroke(1.dp, if (selected) p.accentPrimary else p.borderStrong)
                            ) {
                                Text(
                                    text = phrase,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = if (selected) p.onAccentPrimary else p.ink,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    HorizontalDivider(color = p.border)
                    Spacer(modifier = Modifier.height(14.dp))

                    OutlinedTextField(
                        value = tasbih.customPhrase,
                        onValueChange = { text ->
                            onUpdateTasbih {
                                it.copy(
                                    customPhrase = text,
                                    phraseIndex = if (text.isNotBlank()) -1 else 0
                                )
                            }
                        },
                        placeholder = { Text("أو اكتب ذكراً مخصصاً هنا...") },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        TARGET_OPTIONS.forEach { (value, label) ->
                            val selected = tasbih.target == value
                            Surface(
                                onClick = {
                                    onUpdateTasbih { it.copy(target = value, count = 0) }
                                },
                                shape = RoundedCornerShape(10.dp),
                                color = if (selected) p.accentPrimary else p.canvas,
                                border = BorderStroke(1.dp, if (selected) p.accentPrimary else p.borderStrong),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    text = label,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium,
                                    textAlign = TextAlign.Center,
                                    color = if (selected) p.onAccentPrimary else p.ink,
                                    modifier = Modifier.padding(vertical = 10.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Central Interactive Tasbih Ring
        item {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = p.surface,
                border = BorderStroke(1.dp, p.border),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 28.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = activePhrase,
                        style = MaterialTheme.typography.headlineMedium,
                        textAlign = TextAlign.Center,
                        color = p.ink
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    Box(
                        modifier = Modifier
                            .size(224.dp)
                            .clip(CircleShape)
                            .clickable(onClick = onTapTasbih),
                        contentAlignment = Alignment.Center
                    ) {
                        val trackColor = p.border
                        val ringColor = p.accentPrimary
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val strokeW = 10.dp.toPx()
                            drawCircle(
                                color = trackColor,
                                style = Stroke(width = strokeW)
                            )
                            if (hasTarget && progress > 0f) {
                                drawArc(
                                    color = ringColor,
                                    startAngle = -90f,
                                    sweepAngle = progress * 360f,
                                    useCenter = false,
                                    style = Stroke(width = strokeW, cap = StrokeCap.Round)
                                )
                            }
                        }

                        Surface(
                            shape = CircleShape,
                            color = p.canvas,
                            border = BorderStroke(1.dp, p.borderStrong),
                            modifier = Modifier.size(182.dp)
                        ) {
                            Column(
                                modifier = Modifier.fillMaxSize(),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Text(
                                    text = tasbih.count.toString(),
                                    fontSize = 48.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    color = p.ink
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = if (hasTarget) "من ${tasbih.target}" else "عدّ مفتوح",
                                    fontSize = 13.sp,
                                    color = p.mutedInk
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedButton(
                            onClick = { onUpdateTasbih { it.copy(count = 0) } },
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, p.borderStrong),
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = p.canvas,
                                contentColor = p.ink
                            )
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Refresh,
                                contentDescription = null,
                                tint = p.accentGold,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = "تصفير العداد", fontSize = 13.sp)
                        }

                        OutlinedButton(
                            onClick = onToggleVolumeMute,
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, p.borderStrong),
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = p.canvas,
                                contentColor = p.ink
                            )
                        ) {
                            Icon(
                                imageVector = if (settings.volume > 0f) {
                                    Icons.AutoMirrored.Rounded.VolumeUp
                                } else {
                                    Icons.AutoMirrored.Rounded.VolumeOff
                                },
                                contentDescription = null,
                                tint = if (settings.volume > 0f) p.accentPrimary else p.mutedInk,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (settings.volume > 0f) "الصوت مفعّل" else "الصوت مكتوم",
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
