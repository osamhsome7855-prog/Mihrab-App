package com.mihrab.app.notifications

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.mihrab.app.domain.AstronomicalPrayerCalculator
import com.mihrab.app.model.AppSettings
import com.mihrab.app.model.PrayerKey
import java.util.Calendar
import java.util.TimeZone

object PrayerAlarmScheduler {

    const val CHANNEL_PRAYERS = "mihrab_prayers_channel"
    const val CHANNEL_ADHKAR = "mihrab_adhkar_channel"

    const val EXTRA_TITLE = "extra_title"
    const val EXTRA_MESSAGE = "extra_message"
    const val EXTRA_TONE_ID = "extra_tone_id"
    const val EXTRA_VOLUME = "extra_volume"
    const val EXTRA_CHANNEL = "extra_channel"
    const val EXTRA_NOTIF_ID = "extra_notif_id"

    private const val REQ_BASE_PRAYER = 1000
    private const val REQ_BASE_PRE_PRAYER = 2000
    private const val REQ_MORNING_ADHKAR = 3001
    private const val REQ_EVENING_ADHKAR = 3002

    fun ensureNotificationChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val prayerChannel = NotificationChannel(
                CHANNEL_PRAYERS,
                "تنبيهات مواقيت الصلاة",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "تنبيهات الأذان والتذكير الاستباقي قبل الصلوات الخمس"
                enableVibration(true)
            }
            val adhkarChannel = NotificationChannel(
                CHANNEL_ADHKAR,
                "تذكيرات الأذكار اليومية",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "تنبيهات أذكار الصباح والمساء"
                enableVibration(true)
            }
            nm.createNotificationChannel(prayerChannel)
            nm.createNotificationChannel(adhkarChannel)
        }
    }

    fun rescheduleAll(context: Context, settings: AppSettings) {
        ensureNotificationChannels(context)
        cancelAll(context)
        if (!settings.notificationsEnabled) return

        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val now = System.currentTimeMillis()
        val tz = TimeZone.getDefault()
        val (lat, lng, locationLabel) = AstronomicalPrayerCalculator.resolveCoordinates(settings)

        val todayCal = Calendar.getInstance(tz).apply { timeInMillis = now }
        val tomorrowCal = (todayCal.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, 1) }

        val todayMap = AstronomicalPrayerCalculator.computeDailyPrayerTimestamps(
            todayCal, lat, lng, tz, settings.calculationMethod, settings.madhhab
        )
        val tomorrowMap = AstronomicalPrayerCalculator.computeDailyPrayerTimestamps(
            tomorrowCal, lat, lng, tz, settings.calculationMethod, settings.madhhab
        )

        val alertablePrayers = listOf(
            PrayerKey.FAJR,
            PrayerKey.DHUHR,
            PrayerKey.ASR,
            PrayerKey.MAGHRIB,
            PrayerKey.ISHA
        )

        alertablePrayers.forEachIndexed { idx, key ->
            if (!settings.isPrayerAlertEnabled(key)) return@forEachIndexed

            val todayTime = todayMap.getValue(key)
            val targetTime = if (todayTime > now + 5_000L) todayTime else tomorrowMap.getValue(key)

            scheduleOne(
                context = context,
                alarmManager = alarmManager,
                requestCode = REQ_BASE_PRAYER + idx,
                triggerAtMillis = targetTime,
                title = "حان الآن موعد صلاة ${key.labelAr}",
                message = "حسب التوقيت المحلي لـ $locationLabel (${AstronomicalPrayerCalculator.formatTimeArabic(targetTime)})",
                toneId = settings.adhanTone.name,
                volume = settings.volume,
                channelId = CHANNEL_PRAYERS
            )

            if (settings.prePrayerMinutes > 0) {
                val offsetMs = settings.prePrayerMinutes * 60_000L
                val todayPre = todayTime - offsetMs
                val targetPre = if (todayPre > now + 5_000L) todayPre else tomorrowMap.getValue(key) - offsetMs

                scheduleOne(
                    context = context,
                    alarmManager = alarmManager,
                    requestCode = REQ_BASE_PRE_PRAYER + idx,
                    triggerAtMillis = targetPre,
                    title = "اقترب موعد صلاة ${key.labelAr}",
                    message = "متبقي ${settings.prePrayerMinutes} دقائق على الأذان",
                    toneId = settings.prePrayerTone.name,
                    volume = settings.volume,
                    channelId = CHANNEL_PRAYERS
                )
            }
        }

        if (settings.morningAdhkarEnabled) {
            val trigger = nextTimeForHourMinute(settings.morningAdhkarHour, settings.morningAdhkarMinute, now)
            scheduleOne(
                context = context,
                alarmManager = alarmManager,
                requestCode = REQ_MORNING_ADHKAR,
                triggerAtMillis = trigger,
                title = "موعد أذكار الصباح",
                message = "ابدأ يومك بذكر الله وطمأنينة القلب.",
                toneId = settings.adhkarTone.name,
                volume = settings.volume,
                channelId = CHANNEL_ADHKAR
            )
        }

        if (settings.eveningAdhkarEnabled) {
            val trigger = nextTimeForHourMinute(settings.eveningAdhkarHour, settings.eveningAdhkarMinute, now)
            scheduleOne(
                context = context,
                alarmManager = alarmManager,
                requestCode = REQ_EVENING_ADHKAR,
                triggerAtMillis = trigger,
                title = "موعد أذكار المساء",
                message = "حصّن مساءك بالذكر والدعاء والسكينة.",
                toneId = settings.adhkarTone.name,
                volume = settings.volume,
                channelId = CHANNEL_ADHKAR
            )
        }
    }

    fun cancelAll(context: Context) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val codes = (0..4).flatMap { listOf(REQ_BASE_PRAYER + it, REQ_BASE_PRE_PRAYER + it) } +
            listOf(REQ_MORNING_ADHKAR, REQ_EVENING_ADHKAR)
        codes.forEach { code ->
            val intent = Intent(context, PrayerAlarmReceiver::class.java)
            val pi = PendingIntent.getBroadcast(
                context,
                code,
                intent,
                PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
            )
            if (pi != null) {
                alarmManager.cancel(pi)
                pi.cancel()
            }
        }
    }

    private fun nextTimeForHourMinute(hour: Int, minute: Int, nowMillis: Long): Long {
        val cal = Calendar.getInstance().apply {
            timeInMillis = nowMillis
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        if (cal.timeInMillis <= nowMillis + 5_000L) {
            cal.add(Calendar.DAY_OF_YEAR, 1)
        }
        return cal.timeInMillis
    }

    private fun scheduleOne(
        context: Context,
        alarmManager: AlarmManager,
        requestCode: Int,
        triggerAtMillis: Long,
        title: String,
        message: String,
        toneId: String,
        volume: Float,
        channelId: String
    ) {
        val intent = Intent(context, PrayerAlarmReceiver::class.java).apply {
            putExtra(EXTRA_TITLE, title)
            putExtra(EXTRA_MESSAGE, message)
            putExtra(EXTRA_TONE_ID, toneId)
            putExtra(EXTRA_VOLUME, volume)
            putExtra(EXTRA_CHANNEL, channelId)
            putExtra(EXTRA_NOTIF_ID, requestCode)
        }

        val pi = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val canExact = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            alarmManager.canScheduleExactAlarms()
        } else {
            true
        }

        if (canExact) {
            alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi)
        } else {
            alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi)
        }
    }
}
