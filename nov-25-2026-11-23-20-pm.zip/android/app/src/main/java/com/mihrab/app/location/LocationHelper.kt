package com.mihrab.app.location

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Looper
import androidx.core.content.ContextCompat
import java.util.Locale

object LocationHelper {

    fun hasLocationPermission(context: Context): Boolean {
        val fine = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        return fine || coarse
    }

    @SuppressLint("MissingPermission")
    fun fetchCurrentCoordinates(
        context: Context,
        onSuccess: (lat: Double, lng: Double, label: String) -> Unit,
        onError: (String) -> Unit
    ) {
        if (!hasLocationPermission(context)) {
            onError("يرجى منح صلاحية الوصول إلى الموقع الجغرافي أولاً.")
            return
        }

        val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val providers = listOf(
            LocationManager.GPS_PROVIDER,
            LocationManager.NETWORK_PROVIDER,
            LocationManager.PASSIVE_PROVIDER
        )

        var bestLastKnown: Location? = null
        for (provider in providers) {
            try {
                if (lm.isProviderEnabled(provider)) {
                    val loc = lm.getLastKnownLocation(provider)
                    if (loc != null && (bestLastKnown == null || loc.time > bestLastKnown.time)) {
                        bestLastKnown = loc
                    }
                }
            } catch (_: Throwable) {
            }
        }

        if (bestLastKnown != null) {
            val label = formatCoordinateLabel(bestLastKnown.latitude, bestLastKnown.longitude)
            onSuccess(bestLastKnown.latitude, bestLastKnown.longitude, label)
            return
        }

        val activeProvider = when {
            lm.isProviderEnabled(LocationManager.GPS_PROVIDER) -> LocationManager.GPS_PROVIDER
            lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER) -> LocationManager.NETWORK_PROVIDER
            else -> null
        }

        if (activeProvider == null) {
            onError("خدمة الموقع (GPS) غير مفعلة على الجهاز. يمكنك اختيار أقرب مدينة يدوياً.")
            return
        }

        val listener = object : LocationListener {
            override fun onLocationChanged(location: Location) {
                lm.removeUpdates(this)
                val label = formatCoordinateLabel(location.latitude, location.longitude)
                onSuccess(location.latitude, location.longitude, label)
            }

            override fun onProviderDisabled(provider: String) {
                lm.removeUpdates(this)
                onError("تم إيقاف خدمة الموقع قبل تحديد الإحداثيات.")
            }
        }

        try {
            lm.requestLocationUpdates(activeProvider, 0L, 0f, listener, Looper.getMainLooper())
        } catch (_: Throwable) {
            onError("تعذر قراءة الموقع من مستشعر الجهاز.")
        }
    }

    private fun formatCoordinateLabel(lat: Double, lng: Double): String {
        val latStr = String.format(Locale.US, "%.2f°", lat)
        val lngStr = String.format(Locale.US, "%.2f°", lng)
        return "موقعي الحالي ($latStr، $lngStr)"
    }
}
