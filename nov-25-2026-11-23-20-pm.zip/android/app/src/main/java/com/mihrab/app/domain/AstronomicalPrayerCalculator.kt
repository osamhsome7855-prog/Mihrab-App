package com.mihrab.app.domain

import android.icu.util.IslamicCalendar
import com.mihrab.app.data.CityPresets
import com.mihrab.app.model.AppSettings
import com.mihrab.app.model.CalculationMethodKey
import com.mihrab.app.model.ComputedPrayerState
import com.mihrab.app.model.MadhhabKey
import com.mihrab.app.model.PrayerKey
import com.mihrab.app.model.PrayerScheduleItem
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.math.PI
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.atan
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.tan

object AstronomicalPrayerCalculator {

    private const val KAABA_LAT = 21.4225
    private const val KAABA_LNG = 39.8262

    private val HIJRI_MONTHS_AR = arrayOf(
        "محرم", "صفر", "ربيع الأول", "ربيع الآخر",
        "جمادى الأولى", "جمادى الآخرة", "رجب", "شعبان",
        "رمضان", "شوال", "ذو القعدة", "ذو الحجة"
    )

    fun resolveCoordinates(settings: AppSettings): Triple<Double, Double, String> {
        return if (settings.useGpsLocation) {
            Triple(
                settings.customLat,
                settings.customLng,
                settings.customLocationName.ifBlank { "الموقع الجغرافي الحالي" }
            )
        } else {
            val city = CityPresets.findById(settings.selectedCityId)
            Triple(city.lat, city.lng, "${city.nameAr}، ${city.countryAr}")
        }
    }

    fun computeQiblaAngle(lat: Double, lng: Double): Int {
        val phiK = Math.toRadians(KAABA_LAT)
        val lambdaK = Math.toRadians(KAABA_LNG)
        val phi = Math.toRadians(lat)
        val lambda = Math.toRadians(lng)

        val psi = atan2(
            sin(lambdaK - lambda),
            cos(phi) * tan(phiK) - sin(phi) * cos(lambdaK - lambda)
        )
        val deg = (Math.toDegrees(psi) + 360.0) % 360.0
        return deg.roundToInt() % 360
    }

    fun computeState(settings: AppSettings, nowMillis: Long = System.currentTimeMillis()): ComputedPrayerState {
        val (lat, lng, locationLabel) = resolveCoordinates(settings)
        val tz = TimeZone.getDefault()

        val todayCal = Calendar.getInstance(tz).apply { timeInMillis = nowMillis }
        val tomorrowCal = (todayCal.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, 1) }

        val todayTimes = computeDailyPrayerTimestamps(
            todayCal, lat, lng, tz, settings.calculationMethod, settings.madhhab
        )
        val tomorrowTimes = computeDailyPrayerTimestamps(
            tomorrowCal, lat, lng, tz, settings.calculationMethod, settings.madhhab
        )

        val orderedKeys = listOf(
            PrayerKey.FAJR,
            PrayerKey.SUNRISE,
            PrayerKey.DHUHR,
            PrayerKey.ASR,
            PrayerKey.MAGHRIB,
            PrayerKey.ISHA
        )

        var currentKey: PrayerKey? = null
        var nextKey: PrayerKey? = null
        var nextTimeMillis = 0L

        for (key in orderedKeys) {
            val t = todayTimes.getValue(key)
            if (t <= nowMillis) {
                currentKey = key
            } else if (nextKey == null) {
                nextKey = key
                nextTimeMillis = t
            }
        }

        val isNextToday = nextKey != null
        val resolvedNextKey = nextKey ?: PrayerKey.FAJR
        val resolvedNextMillis = if (isNextToday) nextTimeMillis else tomorrowTimes.getValue(PrayerKey.FAJR)

        val schedule = orderedKeys.map { key ->
            val t = todayTimes.getValue(key)
            PrayerScheduleItem(
                key = key,
                nameAr = key.labelAr,
                timeMillis = t,
                formattedTime = formatTimeArabic(t),
                isNext = isNextToday && resolvedNextKey == key,
                isCurrent = currentKey == key
            )
        }

        val diffSec = ((resolvedNextMillis - nowMillis).coerceAtLeast(0L) / 1000L)
        val hrs = diffSec / 3600L
        val mins = (diffSec % 3600L) / 60L
        val secs = diffSec % 60L

        return ComputedPrayerState(
            schedule = schedule,
            nextPrayerKey = resolvedNextKey,
            nextPrayerNameAr = resolvedNextKey.labelAr,
            nextPrayerTimeMillis = resolvedNextMillis,
            nextPrayerFormatted = formatTimeArabic(resolvedNextMillis),
            countdownHours = hrs.toString().padStart(2, '0'),
            countdownMinutes = mins.toString().padStart(2, '0'),
            countdownSeconds = secs.toString().padStart(2, '0'),
            qiblaAngle = computeQiblaAngle(lat, lng),
            hijriDate = formatHijriDate(nowMillis),
            gregorianDate = formatGregorianDate(nowMillis),
            locationLabel = locationLabel
        )
    }

    fun computeDailyPrayerTimestamps(
        dayCal: Calendar,
        lat: Double,
        lng: Double,
        timeZone: TimeZone,
        method: CalculationMethodKey,
        madhhab: MadhhabKey
    ): Map<PrayerKey, Long> {
        val year = dayCal.get(Calendar.YEAR)
        val month = dayCal.get(Calendar.MONTH) + 1
        val day = dayCal.get(Calendar.DAY_OF_MONTH)

        val midnightCal = Calendar.getInstance(timeZone).apply {
            set(year, month - 1, day, 0, 0, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val tzOffsetHours = timeZone.getOffset(midnightCal.timeInMillis) / 3600000.0
        val julianDay = computeJulianDay(year, month, day) - lng / (15.0 * 24.0)

        val d = julianDay - 2451545.0
        val g = fixAngle(357.529 + 0.98560028 * d)
        val q = fixAngle(280.459 + 0.98564736 * d)
        val l = fixAngle(q + 1.915 * dsin(g) + 0.020 * dsin(2.0 * g))
        val e = 23.439 - 0.00000036 * d

        val ra = darctan2(dcos(e) * dsin(l), dcos(l)) / 15.0
        val eqTime = q / 15.0 - fixHour(ra)
        val decl = darcsin(dsin(e) * dsin(l))

        val noonHours = fixHour(12.0 + tzOffsetHours - lng / 15.0 - eqTime)
        val sunriseAngle = 0.833
        val sunsetAngle = 0.833

        val fajrHours = noonHours - sunAngleTime(method.fajrAngle, lat, decl)
        val sunriseHours = noonHours - sunAngleTime(sunriseAngle, lat, decl)
        val dhuhrHours = noonHours + (1.0 / 60.0)
        val asrHours = noonHours + asrTime(madhhab.shadowFactor, lat, decl)
        val maghribHours = noonHours + sunAngleTime(sunsetAngle, lat, decl)
        val ishaHours = if (method.ishaIntervalMinutes != null) {
            maghribHours + (method.ishaIntervalMinutes / 60.0)
        } else {
            noonHours + sunAngleTime(method.ishaAngle ?: 17.0, lat, decl)
        }

        val baseMs = midnightCal.timeInMillis
        fun hoursToMillis(h: Double): Long {
            val safeH = if (h.isNaN() || h.isInfinite()) 12.0 else h
            val totalSeconds = (safeH * 3600.0).roundToInt()
            return baseMs + totalSeconds * 1000L
        }

        return mapOf(
            PrayerKey.FAJR to hoursToMillis(fajrHours),
            PrayerKey.SUNRISE to hoursToMillis(sunriseHours),
            PrayerKey.DHUHR to hoursToMillis(dhuhrHours),
            PrayerKey.ASR to hoursToMillis(asrHours),
            PrayerKey.MAGHRIB to hoursToMillis(maghribHours),
            PrayerKey.ISHA to hoursToMillis(ishaHours)
        )
    }

    private fun sunAngleTime(angle: Double, lat: Double, decl: Double): Double {
        val numerator = -dsin(angle) - dsin(lat) * dsin(decl)
        val denominator = dcos(lat) * dcos(decl)
        val ratio = (numerator / denominator).coerceIn(-0.9999, 0.9999)
        return darccos(ratio) / 15.0
    }

    private fun asrTime(factor: Int, lat: Double, decl: Double): Double {
        val angle = -darccot(factor + dtan(kotlin.math.abs(lat - decl)))
        return sunAngleTime(angle, lat, decl)
    }

    private fun computeJulianDay(year: Int, month: Int, day: Int): Double {
        var y = year
        var m = month
        if (m <= 2) {
            y -= 1
            m += 12
        }
        val a = floor(y / 100.0)
        val b = 2.0 - a + floor(a / 4.0)
        return floor(365.25 * (y + 4716)) + floor(30.6001 * (m + 1)) + day + b - 1524.5
    }

    private fun dsin(d: Double) = sin(Math.toRadians(d))
    private fun dcos(d: Double) = cos(Math.toRadians(d))
    private fun dtan(d: Double) = tan(Math.toRadians(d))
    private fun darcsin(x: Double) = Math.toDegrees(asin(x.coerceIn(-1.0, 1.0)))
    private fun darccos(x: Double) = Math.toDegrees(acos(x.coerceIn(-1.0, 1.0)))
    private fun darctan2(y: Double, x: Double) = Math.toDegrees(atan2(y, x))
    private fun darccot(x: Double) = Math.toDegrees(atan(1.0 / x))

    private fun fixAngle(a: Double): Double {
        val res = a - 360.0 * floor(a / 360.0)
        return if (res < 0) res + 360.0 else res
    }

    private fun fixHour(a: Double): Double {
        val res = a - 24.0 * floor(a / 24.0)
        return if (res < 0) res + 24.0 else res
    }

    fun formatTimeArabic(timeMillis: Long): String {
        val locale = Locale("ar", "EG")
        val sdf = SimpleDateFormat("hh:mm a", locale)
        return sdf.format(Date(timeMillis))
    }

    fun formatGregorianDate(timeMillis: Long): String {
        val locale = Locale("ar", "EG")
        val sdf = SimpleDateFormat("EEEE، d MMMM yyyy", locale)
        return sdf.format(Date(timeMillis))
    }

    fun formatHijriDate(timeMillis: Long): String {
        return try {
            val hijri = IslamicCalendar().apply {
                calculationType = IslamicCalendar.CalculationType.ISLAMIC_UMALQURA
                time = Date(timeMillis)
            }
            val day = hijri.get(IslamicCalendar.DAY_OF_MONTH)
            val monthIdx = hijri.get(IslamicCalendar.MONTH).coerceIn(0, 11)
            val year = hijri.get(IslamicCalendar.YEAR)
            "$day ${HIJRI_MONTHS_AR[monthIdx]} $year هـ"
        } catch (_: Throwable) {
            ""
        }
    }
}
