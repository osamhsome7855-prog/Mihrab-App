package com.mihrab.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.sp

private val MihrabLightColorScheme = lightColorScheme(
    primary = LightEmerald,
    onPrimary = LightCanvas,
    secondary = LightGoldDeep,
    onSecondary = LightCanvas,
    background = LightCanvas,
    onBackground = LightInk,
    surface = LightSurface,
    onSurface = LightInk,
    surfaceVariant = LightSurfaceElevated,
    onSurfaceVariant = LightMutedInk,
    outline = LightBorder,
    outlineVariant = LightBorderStrong
)

private val MihrabDarkColorScheme = darkColorScheme(
    primary = DarkGold,
    onPrimary = DarkCanvas,
    secondary = DarkEmerald,
    onSecondary = DarkInk,
    background = DarkCanvas,
    onBackground = DarkInk,
    surface = DarkSurface,
    onSurface = DarkInk,
    surfaceVariant = DarkSurfaceElevated,
    onSurfaceVariant = DarkMutedInk,
    outline = DarkBorder,
    outlineVariant = DarkBorderStrong
)

data class MihrabPalette(
    val isDark: Boolean,
    val canvas: Color,
    val surface: Color,
    val surfaceElevated: Color,
    val border: Color,
    val borderStrong: Color,
    val ink: Color,
    val mutedInk: Color,
    val accentPrimary: Color,
    val onAccentPrimary: Color,
    val accentGold: Color,
    val doneSurface: Color,
    val doneInk: Color
)

fun mihrabPalette(isDark: Boolean): MihrabPalette = if (isDark) {
    MihrabPalette(
        isDark = true,
        canvas = DarkCanvas,
        surface = DarkSurface,
        surfaceElevated = DarkSurfaceElevated,
        border = DarkBorder,
        borderStrong = DarkBorderStrong,
        ink = DarkInk,
        mutedInk = DarkMutedInk,
        accentPrimary = DarkGold,
        onAccentPrimary = DarkCanvas,
        accentGold = DarkGold,
        doneSurface = DarkEmeraldSoft,
        doneInk = Color(0xFF6AC7B0)
    )
} else {
    MihrabPalette(
        isDark = false,
        canvas = LightCanvas,
        surface = LightSurface,
        surfaceElevated = LightSurfaceElevated,
        border = LightBorder,
        borderStrong = LightBorderStrong,
        ink = LightInk,
        mutedInk = LightMutedInk,
        accentPrimary = LightEmerald,
        onAccentPrimary = LightCanvas,
        accentGold = LightGoldDeep,
        doneSurface = LightEmeraldSoft,
        doneInk = LightEmerald
    )
}

private val MihrabTypography = Typography(
    displayLarge = TextStyle(
        fontFamily = FontFamily.Serif,
        fontWeight = FontWeight.Bold,
        fontSize = 36.sp,
        lineHeight = 46.sp
    ),
    headlineMedium = TextStyle(
        fontFamily = FontFamily.Serif,
        fontWeight = FontWeight.Bold,
        fontSize = 24.sp,
        lineHeight = 34.sp
    ),
    titleLarge = TextStyle(
        fontFamily = FontFamily.Serif,
        fontWeight = FontWeight.Bold,
        fontSize = 20.sp,
        lineHeight = 28.sp
    ),
    bodyLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 16.sp,
        lineHeight = 26.sp
    ),
    bodyMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 14.sp,
        lineHeight = 22.sp
    ),
    labelMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Medium,
        fontSize = 12.sp,
        lineHeight = 16.sp
    )
)

@Composable
fun MihrabTheme(
    isDark: Boolean,
    content: @Composable () -> Unit
) {
    val colorScheme = if (isDark) MihrabDarkColorScheme else MihrabLightColorScheme
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = MihrabTypography,
            content = content
        )
    }
}
