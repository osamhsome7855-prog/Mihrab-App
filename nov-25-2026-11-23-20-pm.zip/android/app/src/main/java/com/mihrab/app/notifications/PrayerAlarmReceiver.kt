package com.mihrab.app.notifications

import android.Manifest
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.mihrab.app.MainActivity
import com.mihrab.app.R
import com.mihrab.app.audio.MihrabAudioEngine
import com.mihrab.app.data.PreferencesRepository
import com.mihrab.app.model.ToneId

class PrayerAlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        PrayerAlarmScheduler.ensureNotificationChannels(context)

        val title = intent.getStringExtra(PrayerAlarmScheduler.EXTRA_TITLE) ?: "تنبيه مِحراب"
        val message = intent.getStringExtra(PrayerAlarmScheduler.EXTRA_MESSAGE) ?: ""
        val toneName = intent.getStringExtra(PrayerAlarmScheduler.EXTRA_TONE_ID) ?: ToneId.MAKKAH_CHIME.name
        val volume = intent.getFloatExtra(PrayerAlarmScheduler.EXTRA_VOLUME, 0.75f)
        val channelId = intent.getStringExtra(PrayerAlarmScheduler.EXTRA_CHANNEL) ?: PrayerAlarmScheduler.CHANNEL_PRAYERS
        val notifId = intent.getIntExtra(PrayerAlarmScheduler.EXTRA_NOTIF_ID, 1001)

        val tone = runCatching { ToneId.valueOf(toneName) }.getOrDefault(ToneId.MAKKAH_CHIME)
        MihrabAudioEngine.playTone(tone, volume)

        val canPost = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }

        if (canPost) {
            val openAppIntent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val contentPendingIntent = PendingIntent.getActivity(
                context,
                notifId,
                openAppIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val notification = NotificationCompat.Builder(context, channelId)
                .setSmallIcon(R.drawable.ic_launcher_foreground)
                .setContentTitle(title)
                .setContentText(message)
                .setStyle(NotificationCompat.BigTextStyle().bigText(message))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(contentPendingIntent)
                .build()

            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(notifId, notification)
        }

        // Schedule next day's occurrence automatically
        val repo = PreferencesRepository(context)
        PrayerAlarmScheduler.rescheduleAll(context, repo.loadSettings())
    }
}
