package com.mihrab.app.ui.theme

import androidx.compose.ui.graphics.Color

// Light Mode — Sand Ivory, Calm Emerald, Deep Navy Ink, Matte Gold
val LightCanvas = Color(0xFFFAF7F2)
val LightSurface = Color(0xFFF3EDE2)
val LightSurfaceElevated = Color(0xFFECE3D3)
val LightBorder = Color(0xFFE5DEC9)
val LightBorderStrong = Color(0xFFD4C9B0)
val LightInk = Color(0xFF0B162C)
val LightMutedInk = Color(0xFF525E70)
val LightEmerald = Color(0xFF0F5143)
val LightEmeraldSoft = Color(0xFFEBF3F0)
val LightGold = Color(0xFFB88B4A)
val LightGoldDeep = Color(0xFF9A7034)

// Dark Mode — Deep Midnight Navy, Matte Gold, Calm Emerald
val DarkCanvas = Color(0xFF081120)
val DarkSurface = Color(0xFF0F1C33)
val DarkSurfaceElevated = Color(0xFF152645)
val DarkBorder = Color(0xFF1B2C4A)
val DarkBorderStrong = Color(0xFF243B61)
val DarkInk = Color(0xFFF3EFE6)
val DarkMutedInk = Color(0xFF98A6BD)
val DarkGold = Color(0xFFD4AF6A)
val DarkEmerald = Color(0xFF2E8B74)
val DarkEmeraldSoft = Color(0xFF0D2426)
