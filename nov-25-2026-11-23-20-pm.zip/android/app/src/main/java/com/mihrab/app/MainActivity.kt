package com.mihrab.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Book
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.LightMode
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.viewmodel.compose.viewModel
import com.mihrab.app.location.LocationHelper
import com.mihrab.app.model.ActiveAlertBanner
import com.mihrab.app.model.ActiveTab
import com.mihrab.app.ui.screens.AdhkarScreen
import com.mihrab.app.ui.screens.PrayerDashboardScreen
import com.mihrab.app.ui.screens.SettingsScreen
import com.mihrab.app.ui.screens.TasbihScreen
import com.mihrab.app.ui.theme.MihrabTheme
import com.mihrab.app.ui.theme.mihrabPalette
import com.mihrab.app.viewmodel.MihrabViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MihrabApp()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MihrabApp(viewModel: MihrabViewModel = viewModel()) {
    val activeTab by viewModel.activeTab.collectAsState()
    val settings by viewModel.settings.collectAsState()
    val prayerState by viewModel.prayerState.collectAsState()
    val dhikrCounts by viewModel.dhikrCounts.collectAsState()
    val customAdhkar by viewModel.customAdhkar.collectAsState()
    val tasbihState by viewModel.tasbihState.collectAsState()
    val activeAlert by viewModel.activeAlert.collectAsState()
    val gpsMessage by viewModel.gpsMessage.collectAsState()
    val compassAzimuth by viewModel.compassAzimuth.collectAsState()
    val hasCompassSensor by viewModel.hasCompassSensor.collectAsState()

    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    var hasNotifPermission by remember {
        mutableStateOf(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.POST_NOTIFICATIONS
                ) == PackageManager.PERMISSION_GRANTED
            } else {
                true
            }
        )
    }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasNotifPermission = granted
        if (granted) {
            viewModel.updateSettings { it.copy(notificationsEnabled = true) }
        }
    }

    val locationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        val granted = result[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
            result[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        if (granted) {
            viewModel.fetchGpsLocation()
        }
    }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> viewModel.startCompass()
                Lifecycle.Event.ON_PAUSE -> viewModel.stopCompass()
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            viewModel.stopCompass()
        }
    }

    MihrabTheme(isDark = settings.isDarkTheme) {
        val p = mihrabPalette(settings.isDarkTheme)

        Scaffold(
            containerColor = p.canvas,
            topBar = {
                Column {
                    TopAppBar(
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = p.canvas,
                            titleContentColor = p.ink
                        ),
                        title = {
                            Text(
                                text = "مِحراب",
                                style = MaterialTheme.typography.headlineMedium,
                                fontWeight = FontWeight.Bold
                            )
                        },
                        actions = {
                            OutlinedButton(
                                onClick = { viewModel.toggleTheme() },
                                shape = RoundedCornerShape(10.dp),
                                border = BorderStroke(1.dp, p.borderStrong),
                                modifier = Modifier.padding(end = 12.dp)
                            ) {
                                Icon(
                                    imageVector = if (settings.isDarkTheme) {
                                        Icons.Rounded.LightMode
                                    } else {
                                        Icons.Rounded.DarkMode
                                    },
                                    contentDescription = null,
                                    tint = if (settings.isDarkTheme) p.accentGold else p.accentPrimary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (settings.isDarkTheme) "الوضع النهاري" else "الوضع الليلي",
                                    fontSize = 12.sp,
                                    color = p.ink
                                )
                            }
                        }
                    )
                    HorizontalDivider(color = p.border)
                }
            },
            bottomBar = {
                Column {
                    HorizontalDivider(color = p.border)
                    NavigationBar(
                        containerColor = p.canvas
                    ) {
                        ActiveTab.entries.forEach { tab ->
                            val selected = activeTab == tab
                            val icon = when (tab) {
                                ActiveTab.PRAYERS -> Icons.Rounded.Schedule
                                ActiveTab.ADHKAR -> Icons.Rounded.Book
                                ActiveTab.TASBIH -> Icons.Rounded.AutoAwesome
                                ActiveTab.SETTINGS -> Icons.Rounded.Settings
                            }
                            NavigationBarItem(
                                selected = selected,
                                onClick = { viewModel.setActiveTab(tab) },
                                icon = {
                                    Icon(
                                        imageVector = icon,
                                        contentDescription = tab.labelAr
                                    )
                                },
                                label = {
                                    Text(
                                        text = tab.labelAr,
                                        fontSize = 11.sp,
                                        fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal
                                    )
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = p.accentPrimary,
                                    selectedTextColor = p.accentPrimary,
                                    unselectedIconColor = p.mutedInk,
                                    unselectedTextColor = p.mutedInk,
                                    indicatorColor = p.surface
                                )
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                activeAlert?.let { alert ->
                    AlertBannerCard(
                        alert = alert,
                        palette = p,
                        onDismiss = { viewModel.dismissAlert() }
                    )
                }

                Box(modifier = Modifier.weight(1f)) {
                    when (activeTab) {
                        ActiveTab.PRAYERS -> PrayerDashboardScreen(
                            prayerState = prayerState,
                            settings = settings,
                            compassAzimuth = compassAzimuth,
                            hasCompassSensor = hasCompassSensor,
                            adhkarCompletedCount = viewModel.completedAdhkarCount(),
                            adhkarTotalCount = viewModel.totalAdhkarCount(),
                            onTogglePrayerAlert = { key -> viewModel.togglePrayerAlert(key) },
                            onNavigate = { tab -> viewModel.setActiveTab(tab) }
                        )

                        ActiveTab.ADHKAR -> AdhkarScreen(
                            settings = settings,
                            counts = dhikrCounts,
                            customAdhkar = customAdhkar,
                            onIncrementDhikr = { item -> viewModel.incrementDhikr(item) },
                            onResetCategory = { ids -> viewModel.resetDhikrCategory(ids) },
                            onAddCustomDhikr = { text, target, virtue ->
                                viewModel.addCustomDhikr(text, target, virtue)
                            },
                            onDeleteCustomDhikr = { id -> viewModel.deleteCustomDhikr(id) },
                            onToggleAutoAdvance = {
                                viewModel.updateSettings {
                                    it.copy(autoAdvanceDhikr = !it.autoAdvanceDhikr)
                                }
                            }
                        )

                        ActiveTab.TASBIH -> TasbihScreen(
                            tasbih = tasbihState,
                            settings = settings,
                            onTapTasbih = { viewModel.tapTasbih() },
                            onUpdateTasbih = { transform -> viewModel.updateTasbihConfig(transform) },
                            onToggleVolumeMute = { viewModel.toggleVolumeMute() }
                        )

                        ActiveTab.SETTINGS -> SettingsScreen(
                            settings = settings,
                            gpsMessage = gpsMessage,
                            hasNotificationPermission = hasNotifPermission,
                            onRequestLocation = {
                                if (LocationHelper.hasLocationPermission(context)) {
                                    viewModel.fetchGpsLocation()
                                } else {
                                    locationPermissionLauncher.launch(
                                        arrayOf(
                                            Manifest.permission.ACCESS_FINE_LOCATION,
                                            Manifest.permission.ACCESS_COARSE_LOCATION
                                        )
                                    )
                                }
                            },
                            onRequestNotificationPermission = {
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                    notificationPermissionLauncher.launch(
                                        Manifest.permission.POST_NOTIFICATIONS
                                    )
                                }
                            },
                            onUpdateSettings = { transform -> viewModel.updateSettings(transform) },
                            onTogglePrayerAlert = { key -> viewModel.togglePrayerAlert(key) },
                            onTestNotification = { viewModel.testNotificationNow() },
                            onResetDefaults = { viewModel.resetDefaults() }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AlertBannerCard(
    alert: ActiveAlertBanner,
    palette: com.mihrab.app.ui.theme.MihrabPalette,
    onDismiss: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = palette.surface,
        border = BorderStroke(1.dp, palette.accentGold.copy(alpha = 0.55f)),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Icon(
                    imageVector = Icons.Rounded.NotificationsActive,
                    contentDescription = null,
                    tint = palette.accentPrimary,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = alert.title,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = palette.ink
                    )
                    Text(
                        text = "${alert.message} · ${alert.timestamp}",
                        fontSize = 11.sp,
                        color = palette.mutedInk
                    )
                }
            }
            IconButton(onClick = onDismiss) {
                Icon(
                    imageVector = Icons.Rounded.Close,
                    contentDescription = "إغلاق التنبيه",
                    tint = palette.mutedInk
                )
            }
        }
    }
}
