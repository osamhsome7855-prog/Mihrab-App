package com.mihrab.app.data

import android.content.Context
import com.mihrab.app.model.AppSettings
import com.mihrab.app.model.CalculationMethodKey
import com.mihrab.app.model.DhikrCategory
import com.mihrab.app.model.DhikrItem
import com.mihrab.app.model.MadhhabKey
import com.mihrab.app.model.TasbihState
import com.mihrab.app.model.ToneId
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class PreferencesRepository(context: Context) {

    private val prefs = context.getSharedPreferences("mihrab_prefs_v1", Context.MODE_PRIVATE)

    fun todayKey(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    fun loadSettings(): AppSettings {
        val method = runCatching {
            CalculationMethodKey.valueOf(
                prefs.getString("calculationMethod", CalculationMethodKey.UMM_AL_QURA.name)!!
            )
        }.getOrDefault(CalculationMethodKey.UMM_AL_QURA)

        val madhhab = runCatching {
            MadhhabKey.valueOf(prefs.getString("madhhab", MadhhabKey.SHAFI.name)!!)
        }.getOrDefault(MadhhabKey.SHAFI)

        val adhanTone = runCatching {
            ToneId.valueOf(prefs.getString("adhanTone", ToneId.MAKKAH_CHIME.name)!!)
        }.getOrDefault(ToneId.MAKKAH_CHIME)

        val adhkarTone = runCatching {
            ToneId.valueOf(prefs.getString("adhkarTone", ToneId.MORNING_BREEZE.name)!!)
        }.getOrDefault(ToneId.MORNING_BREEZE)

        val prePrayerTone = runCatching {
            ToneId.valueOf(prefs.getString("prePrayerTone", ToneId.GENTLE_BELL.name)!!)
        }.getOrDefault(ToneId.GENTLE_BELL)

        return AppSettings(
            userName = prefs.getString("userName", "ضيف الكريم") ?: "ضيف الكريم",
            isDarkTheme = prefs.getBoolean("isDarkTheme", false),
            useGpsLocation = prefs.getBoolean("useGpsLocation", false),
            selectedCityId = prefs.getString("selectedCityId", "makkah") ?: "makkah",
            customLat = prefs.getString("customLat", "21.4225")?.toDoubleOrNull() ?: 21.4225,
            customLng = prefs.getString("customLng", "39.8262")?.toDoubleOrNull() ?: 39.8262,
            customLocationName = prefs.getString("customLocationName", "مكة المكرمة") ?: "مكة المكرمة",
            calculationMethod = method,
            madhhab = madhhab,
            notificationsEnabled = prefs.getBoolean("notificationsEnabled", true),
            fajrAlert = prefs.getBoolean("fajrAlert", true),
            dhuhrAlert = prefs.getBoolean("dhuhrAlert", true),
            asrAlert = prefs.getBoolean("asrAlert", true),
            maghribAlert = prefs.getBoolean("maghribAlert", true),
            ishaAlert = prefs.getBoolean("ishaAlert", true),
            prePrayerMinutes = prefs.getInt("prePrayerMinutes", 10),
            morningAdhkarHour = prefs.getInt("morningAdhkarHour", 6),
            morningAdhkarMinute = prefs.getInt("morningAdhkarMinute", 0),
            eveningAdhkarHour = prefs.getInt("eveningAdhkarHour", 17),
            eveningAdhkarMinute = prefs.getInt("eveningAdhkarMinute", 30),
            morningAdhkarEnabled = prefs.getBoolean("morningAdhkarEnabled", true),
            eveningAdhkarEnabled = prefs.getBoolean("eveningAdhkarEnabled", true),
            adhanTone = adhanTone,
            adhkarTone = adhkarTone,
            prePrayerTone = prePrayerTone,
            volume = prefs.getFloat("volume", 0.75f),
            autoAdvanceDhikr = prefs.getBoolean("autoAdvanceDhikr", true),
            hapticEnabled = prefs.getBoolean("hapticEnabled", true)
        )
    }

    fun saveSettings(settings: AppSettings) {
        prefs.edit()
            .putString("userName", settings.userName)
            .putBoolean("isDarkTheme", settings.isDarkTheme)
            .putBoolean("useGpsLocation", settings.useGpsLocation)
            .putString("selectedCityId", settings.selectedCityId)
            .putString("customLat", settings.customLat.toString())
            .putString("customLng", settings.customLng.toString())
            .putString("customLocationName", settings.customLocationName)
            .putString("calculationMethod", settings.calculationMethod.name)
            .putString("madhhab", settings.madhhab.name)
            .putBoolean("notificationsEnabled", settings.notificationsEnabled)
            .putBoolean("fajrAlert", settings.fajrAlert)
            .putBoolean("dhuhrAlert", settings.dhuhrAlert)
            .putBoolean("asrAlert", settings.asrAlert)
            .putBoolean("maghribAlert", settings.maghribAlert)
            .putBoolean("ishaAlert", settings.ishaAlert)
            .putInt("prePrayerMinutes", settings.prePrayerMinutes)
            .putInt("morningAdhkarHour", settings.morningAdhkarHour)
            .putInt("morningAdhkarMinute", settings.morningAdhkarMinute)
            .putInt("eveningAdhkarHour", settings.eveningAdhkarHour)
            .putInt("eveningAdhkarMinute", settings.eveningAdhkarMinute)
            .putBoolean("morningAdhkarEnabled", settings.morningAdhkarEnabled)
            .putBoolean("eveningAdhkarEnabled", settings.eveningAdhkarEnabled)
            .putString("adhanTone", settings.adhanTone.name)
            .putString("adhkarTone", settings.adhkarTone.name)
            .putString("prePrayerTone", settings.prePrayerTone.name)
            .putFloat("volume", settings.volume)
            .putBoolean("autoAdvanceDhikr", settings.autoAdvanceDhikr)
            .putBoolean("hapticEnabled", settings.hapticEnabled)
            .apply()
    }

    fun loadDailyDhikrCounts(): Map<String, Int> {
        val savedDate = prefs.getString("dhikr_date_key", "")
        if (savedDate != todayKey()) return emptyMap()
        val raw = prefs.getString("dhikr_counts_json", "{}") ?: "{}"
        return try {
            val obj = JSONObject(raw)
            val result = mutableMapOf<String, Int>()
            obj.keys().forEach { key ->
                result[key] = obj.optInt(key, 0)
            }
            result
        } catch (_: Throwable) {
            emptyMap()
        }
    }

    fun saveDailyDhikrCounts(counts: Map<String, Int>) {
        val obj = JSONObject()
        counts.forEach { (k, v) -> obj.put(k, v) }
        prefs.edit()
            .putString("dhikr_date_key", todayKey())
            .putString("dhikr_counts_json", obj.toString())
            .apply()
    }

    fun loadCustomAdhkar(): List<DhikrItem> {
        val raw = prefs.getString("custom_adhkar_json", "[]") ?: "[]"
        return try {
            val arr = JSONArray(raw)
            buildList {
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    add(
                        DhikrItem(
                            id = obj.getString("id"),
                            category = DhikrCategory.CUSTOM,
                            text = obj.getString("text"),
                            targetCount = obj.optInt("targetCount", 3),
                            reference = obj.optString("reference", "ذكر خاص"),
                            virtue = obj.optString("virtue", "").ifBlank { null },
                            isCustom = true
                        )
                    )
                }
            }
        } catch (_: Throwable) {
            emptyList()
        }
    }

    fun saveCustomAdhkar(items: List<DhikrItem>) {
        val arr = JSONArray()
        items.forEach { item ->
            val obj = JSONObject()
            obj.put("id", item.id)
            obj.put("text", item.text)
            obj.put("targetCount", item.targetCount)
            obj.put("reference", item.reference)
            obj.put("virtue", item.virtue ?: "")
            arr.put(obj)
        }
        prefs.edit().putString("custom_adhkar_json", arr.toString()).apply()
    }

    fun loadTasbihState(): TasbihState = TasbihState(
        phraseIndex = prefs.getInt("tasbih_phrase_idx", 0),
        customPhrase = prefs.getString("tasbih_custom_phrase", "") ?: "",
        target = prefs.getInt("tasbih_target", 33),
        count = prefs.getInt("tasbih_count", 0),
        lifetimeTotal = prefs.getLong("tasbih_lifetime", 0L)
    )

    fun saveTasbihState(state: TasbihState) {
        prefs.edit()
            .putInt("tasbih_phrase_idx", state.phraseIndex)
            .putString("tasbih_custom_phrase", state.customPhrase)
            .putInt("tasbih_target", state.target)
            .putInt("tasbih_count", state.count)
            .putLong("tasbih_lifetime", state.lifetimeTotal)
            .apply()
    }
}
